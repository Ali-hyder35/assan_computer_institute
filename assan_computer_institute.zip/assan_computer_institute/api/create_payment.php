<?php

header('Content-Type: application/json; charset=utf-8');

error_reporting(E_ALL);
ini_set('display_errors', '0');


/*
|--------------------------------------------------------------------------
| JSON Response
|--------------------------------------------------------------------------
*/

function json_response($success, $message, $data = array())
{
    echo json_encode(array_merge(
        array(
            'success' => $success,
            'message' => $message
        ),
        $data
    ));

    exit;
}


try {

    /*
    |--------------------------------------------------------------------------
    | Load Application
    |--------------------------------------------------------------------------
    */

    require_once dirname(__DIR__) . '/config/bootstrap.php';


    /*
    |--------------------------------------------------------------------------
    | Database
    |--------------------------------------------------------------------------
    */

    require_once dirname(__DIR__) . '/config/db.php';


    /*
    |--------------------------------------------------------------------------
    | Check Database
    |--------------------------------------------------------------------------
    */

    if (!isset($pdo)) {

        json_response(
            false,
            'Database connection is not available.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Read JSON
    |--------------------------------------------------------------------------
    */

    $rawInput = file_get_contents('php://input');

    if (!$rawInput) {

        json_response(
            false,
            'No payment data received.'
        );

    }


    $input = json_decode($rawInput, true);


    if (!is_array($input)) {

        json_response(
            false,
            'Invalid JSON data received.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Get Input
    |--------------------------------------------------------------------------
    */

    $name = isset($input['name'])
        ? trim($input['name'])
        : '';

    $mobile = isset($input['mobile'])
        ? trim($input['mobile'])
        : '';

    $email = isset($input['email'])
        ? strtolower(trim($input['email']))
        : '';

    $courseTitle = isset($input['course'])
        ? trim($input['course'])
        : '';

    $paymentMethod = isset($input['payment_method'])
        ? trim($input['payment_method'])
        : '';


    /*
    |--------------------------------------------------------------------------
    | Validate Name
    |--------------------------------------------------------------------------
    */

    if ($name === '') {

        json_response(
            false,
            'Please enter your full name.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Validate Mobile
    |--------------------------------------------------------------------------
    */

    if ($mobile === '') {

        json_response(
            false,
            'Please enter your mobile number.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Validate Email
    |--------------------------------------------------------------------------
    */

    if ($email === '') {

        json_response(
            false,
            'Please enter your email address. You must register as a student before enrollment.'
        );

    }


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        json_response(
            false,
            'Please enter a valid email address.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Validate Course
    |--------------------------------------------------------------------------
    */

    if ($courseTitle === '') {

        json_response(
            false,
            'Please select a course.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Validate Payment Method
    |--------------------------------------------------------------------------
    */

    if ($paymentMethod === '') {

        json_response(
            false,
            'Please select a payment method.'
        );

    }


    $allowedMethods = array(
        'jazzcash',
        'easypaisa',
        'bank_transfer'
    );


    if (!in_array($paymentMethod, $allowedMethods, true)) {

        json_response(
            false,
            'Invalid payment method selected.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Find Registered Student
    |--------------------------------------------------------------------------
    |
    | users.email is UNIQUE, so we can safely find the student.
    |
    */

    $userSql = "
        SELECT
            id,
            full_name,
            email,
            mobile,
            role,
            status
        FROM users
        WHERE email = :email
        LIMIT 1
    ";


    $userStmt = $pdo->prepare($userSql);


    $userStmt->execute(array(
        ':email' => $email
    ));


    $user = $userStmt->fetch(PDO::FETCH_ASSOC);


    /*
    |--------------------------------------------------------------------------
    | Student Not Registered
    |--------------------------------------------------------------------------
    */

    if (!$user) {

        json_response(
            false,
            'No student account was found with this email. Please register first.',
            array(
                'redirect' => '/assan_computer_institute_professional/student/register.php'
            )
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Check User Role
    |--------------------------------------------------------------------------
    */

    if ($user['role'] !== 'student') {

        json_response(
            false,
            'This email is not registered as a student account.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Check User Status
    |--------------------------------------------------------------------------
    */

    if ($user['status'] !== 'active') {

        json_response(
            false,
            'Your student account is currently blocked. Please contact the institute.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | User ID
    |--------------------------------------------------------------------------
    */

    $userId = (int) $user['id'];


    /*
    |--------------------------------------------------------------------------
    | Find Course
    |--------------------------------------------------------------------------
    |
    | Your courses table uses:
    |
    | id
    | title
    | price
    |
    */

    $courseSql = "
        SELECT
            id,
            title,
            price,
            active
        FROM courses
        WHERE title = :title
        LIMIT 1
    ";


    $courseStmt = $pdo->prepare($courseSql);


    $courseStmt->execute(array(
        ':title' => $courseTitle
    ));


    $course = $courseStmt->fetch(PDO::FETCH_ASSOC);


    /*
    |--------------------------------------------------------------------------
    | Course Not Found
    |--------------------------------------------------------------------------
    */

    if (!$course) {

        json_response(
            false,
            'Selected course was not found in the database.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Check Course Status
    |--------------------------------------------------------------------------
    */

    if (isset($course['active']) && (int) $course['active'] !== 1) {

        json_response(
            false,
            'This course is currently unavailable.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Course ID + Price
    |--------------------------------------------------------------------------
    */

    $courseId = (int) $course['id'];

    $amount = (float) $course['price'];


    if ($courseId <= 0) {

        json_response(
            false,
            'Invalid course ID.'
        );

    }


    if ($amount <= 0) {

        json_response(
            false,
            'Invalid course price.'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Check Existing Enrollment
    |--------------------------------------------------------------------------
    |
    | Prevent the same student from accidentally creating
    | duplicate enrollment for the same course.
    |
    */

    $existingSql = "
        SELECT id, payment_status, access_status
        FROM enrollments
        WHERE user_id = :user_id
        AND course_id = :course_id
        LIMIT 1
    ";


    $existingStmt = $pdo->prepare($existingSql);


    $existingStmt->execute(array(
        ':user_id' => $userId,
        ':course_id' => $courseId
    ));


    $existingEnrollment =
        $existingStmt->fetch(PDO::FETCH_ASSOC);


    if ($existingEnrollment) {

        json_response(
            false,
            'You are already enrolled in this course.',
            array(
                'enrollment_id' =>
                    (int) $existingEnrollment['id'],

                'payment_status' =>
                    $existingEnrollment['payment_status'],

                'access_status' =>
                    $existingEnrollment['access_status']
            )
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Generate Order Reference
    |--------------------------------------------------------------------------
    */

    $orderRef =
        'ACI-' .
        date('YmdHis') .
        '-' .
        strtoupper(
            substr(
                md5(uniqid('', true)),
                0,
                6
            )
        );


    /*
    |--------------------------------------------------------------------------
    | Insert Enrollment
    |--------------------------------------------------------------------------
    |
    | The important foreign keys are now:
    |
    | user_id   -> users.id
    | course_id -> courses.id
    |
    */

    $sql = "
        INSERT INTO enrollments
        (
            user_id,
            course_id,
            order_ref,
            amount,
            payment_method,
            payment_status,
            access_status,
            created_at
        )
        VALUES
        (
            :user_id,
            :course_id,
            :order_ref,
            :amount,
            :payment_method,
            'PENDING',
            'INACTIVE',
            NOW()
        )
    ";


    $stmt = $pdo->prepare($sql);


    $stmt->execute(array(
        ':user_id' => $userId,
        ':course_id' => $courseId,
        ':order_ref' => $orderRef,
        ':amount' => $amount,
        ':payment_method' => $paymentMethod
    ));


    /*
    |--------------------------------------------------------------------------
    | Enrollment ID
    |--------------------------------------------------------------------------
    */

    $enrollmentId = $pdo->lastInsertId();


    /*
    |--------------------------------------------------------------------------
    | Success
    |--------------------------------------------------------------------------
    */

    json_response(
        true,
        'Enrollment created successfully. Your payment is pending verification.',
        array(
            'enrollment_id' => $enrollmentId,
            'user_id' => $userId,
            'course_id' => $courseId,
            'order_ref' => $orderRef,
            'course' => $course['title'],
            'amount' => $amount,
            'payment_method' => $paymentMethod,
            'payment_status' => 'PENDING',
            'access_status' => 'INACTIVE'
        )
    );


} catch (PDOException $e) {

    error_log(
        'Payment API Database Error: ' .
        $e->getMessage()
    );


    json_response(
        false,
        'DATABASE ERROR: ' . $e->getMessage()
    );


} catch (Exception $e) {

    error_log(
        'Payment API Error: ' .
        $e->getMessage()
    );


    json_response(
        false,
        'Unable to process enrollment: ' .
        $e->getMessage()
    );

}
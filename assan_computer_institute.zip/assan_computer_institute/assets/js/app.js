document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('[data-auto-dismiss]').forEach(function(el){setTimeout(function(){el.remove()},5000)});
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var id=this.getAttribute('href');
      if(id && id.length>1){var target=document.querySelector(id);if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth'});}}
    });
  });
});

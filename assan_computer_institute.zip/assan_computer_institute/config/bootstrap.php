<?php
session_start();

function load_env_file($file) {
    if (!is_file($file)) return;
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        if (strlen($value) >= 2) {
            $first = $value[0];
            $last = $value[strlen($value)-1];
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $value = substr($value, 1, -1);
            }
        }
        $_ENV[$key] = $value;
        putenv($key . '=' . $value);
    }
}

load_env_file(dirname(__DIR__) . '/.env');

function env($key, $default = null) {
    $value = isset($_ENV[$key]) ? $_ENV[$key] : getenv($key);
    if ($value === false || $value === null || $value === '') return $default;
    return $value;
}

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/helpers.php';
require_once dirname(__DIR__) . '/app/auth.php';

$autoload = dirname(__DIR__) . '/vendor/autoload.php';
if (is_file($autoload)) require_once $autoload;

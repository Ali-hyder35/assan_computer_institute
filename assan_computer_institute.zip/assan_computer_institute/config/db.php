<?php
$dsn = 'mysql:host=' . env('DB_HOST', '127.0.0.1') .
       ';port=' . env('DB_PORT', '3306') .
       ';dbname=' . env('DB_NAME', 'assan_computer_institute') . ';charset=utf8mb4';

try {
    $pdo = new PDO($dsn, env('DB_USER', 'root'), env('DB_PASS', ''), array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ));
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check .env and make sure MySQL is running.');
}

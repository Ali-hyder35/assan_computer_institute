<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student Payment History
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];

$pageTitle = 'Payment History';

$payments = [];
$totalPayments = 0;
$paidPayments = 0;
$pendingPayments = 0;
$totalPaidAmount = 0.00;

$pageError = '';
$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$allowedStatuses = ['pending', 'paid', 'failed', 'cancelled', 'refunded'];

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

try {
    /*
    |--------------------------------------------------------------------------
    | Payment Summary
    |--------------------------------------------------------------------------
    */

    $summarySql = "
        SELECT
            COUNT(*) AS total_payments,
            COALESCE(SUM(payment_status = 'paid'), 0) AS paid_payments,
            COALESCE(SUM(payment_status = 'pending'), 0) AS pending_payments,
            COALESCE(
                SUM(
                    CASE
                        WHEN payment_status = 'paid' THEN amount
                        ELSE 0
                    END
                ),
                0
            ) AS total_paid_amount
        FROM enrollments
        WHERE user_id = :user_id
    ";

    $summaryStmt = $pdo->prepare($summarySql);
    $summaryStmt->execute(['user_id' => $userId]);

    $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);

    if ($summary) {
        $totalPayments = (int) $summary['total_payments'];
        $paidPayments = (int) $summary['paid_payments'];
        $pendingPayments = (int) $summary['pending_payments'];
        $totalPaidAmount = (float) $summary['total_paid_amount'];
    }

    /*
    |--------------------------------------------------------------------------
    | Payment History
    |--------------------------------------------------------------------------
    */

    $sql = "
        SELECT
            e.id,
            e.course_id,
            e.course_name,
            e.order_ref,
            e.amount,
            e.payment_method,
            e.payment_status,
            e.access_status,
            e.gateway_txn_id,
            e.payment_proof,
            e.paid_at,
            e.created_at,
            c.title AS current_course_title
        FROM enrollments e
        LEFT JOIN courses c ON c.id = e.course_id
        WHERE e.user_id = :user_id
    ";

    $params = ['user_id' => $userId];

    if ($statusFilter !== '') {
        $sql .= " AND e.payment_status = :payment_status";
        $params['payment_status'] = $statusFilter;
    }

    if ($search !== '') {
        $sql .= "
            AND (
                e.course_name LIKE :search_course_name
                OR c.title LIKE :search_course_title
                OR e.order_ref LIKE :search_order_ref
                OR e.gateway_txn_id LIKE :search_txn_id
            )
        ";

        $searchTerm = '%' . $search . '%';

        $params['search_course_name'] = $searchTerm;
        $params['search_course_title'] = $searchTerm;
        $params['search_order_ref'] = $searchTerm;
        $params['search_txn_id'] = $searchTerm;
    }

    $sql .= " ORDER BY e.created_at DESC, e.id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log('Student payments database error: ' . $exception->getMessage());

    $pageError = 'Unable to load payment history. Please check the application database configuration.';
}

require_once dirname(__DIR__) . '/partials/header.php';

function payment_status_class($status)
{
    switch (strtolower((string) $status)) {
        case 'paid':
            return 'status-paid';

        case 'pending':
            return 'status-pending';

        case 'failed':
        case 'cancelled':
        case 'refunded':
            return 'status-failed';

        default:
            return 'status-neutral';
    }
}

function payment_method_label($method)
{
    switch (strtolower((string) $method)) {
        case 'jazzcash':
            return 'JazzCash';

        case 'easypaisa':
            return 'Easypaisa';

        case 'bank':
            return 'Bank Transfer';

        default:
            return ucfirst((string) $method);
    }
}
?>

<style>
.payment-page {
    background: #f5f7fb;
    min-height: 75vh;
    padding: 30px 0 45px;
}

.payment-page .page-title {
    color: #0f2a5f;
    font-weight: 800;
}

.payment-page .page-subtitle {
    color: #64748b;
}

.payment-page .summary-card,
.payment-page .content-card {
    background: #fff;
    border: 1px solid #e8edf5;
    border-radius: 16px;
    box-shadow: 0 5px 18px rgba(15, 42, 95, .045);
}

.payment-page .summary-card {
    padding: 22px;
    height: 100%;
}

.payment-page .summary-label {
    color: #64748b;
    font-size: .88rem;
    font-weight: 600;
}

.payment-page .summary-value {
    color: #0f2a5f;
    font-size: 1.7rem;
    font-weight: 800;
    margin-top: 8px;
    overflow-wrap: anywhere;
}

.payment-page .summary-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 44px;
    height: 44px;
    border-radius: 12px;
    background: #eef2ff;
    color: #2563eb;
    font-size: 1.15rem;
}

.payment-page .content-card {
    overflow: hidden;
}

.payment-page .content-card-header {
    padding: 20px 22px;
    border-bottom: 1px solid #e8edf5;
}

.payment-page .content-card-header h5 {
    color: #0f2a5f;
    font-weight: 800;
    margin: 0;
}

.payment-page .filter-area {
    padding: 20px 22px;
}

.payment-page .form-control,
.payment-page .form-select {
    min-height: 44px;
    border-radius: 10px;
    border-color: #dce4ef;
}

.payment-page .form-control:focus,
.payment-page .form-select:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 .2rem rgba(37, 99, 235, .1);
}

.payment-page .table {
    margin-bottom: 0;
}

.payment-page .table thead th {
    background: #f8faff;
    color: #64748b;
    font-size: .77rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .035em;
    padding: 15px 18px;
    white-space: nowrap;
}

.payment-page .table tbody td {
    padding: 17px 18px;
    vertical-align: middle;
    border-color: #edf1f7;
}

.payment-page .course-name {
    color: #0f2a5f;
    font-weight: 750;
}

.payment-page .small-muted {
    color: #64748b;
    font-size: .82rem;
    overflow-wrap: anywhere;
}

.payment-page .status-badge {
    display: inline-block;
    border-radius: 30px;
    padding: 6px 11px;
    font-size: .76rem;
    font-weight: 800;
    white-space: nowrap;
}

.payment-page .status-paid {
    background: #dcfce7;
    color: #166534;
}

.payment-page .status-pending {
    background: #fef3c7;
    color: #92400e;
}

.payment-page .status-failed {
    background: #fee2e2;
    color: #991b1b;
}

.payment-page .status-neutral {
    background: #e2e8f0;
    color: #334155;
}

.payment-page .btn-primary {
    background: #1f3c88;
    border-color: #1f3c88;
}

.payment-page .btn-primary:hover {
    background: #0f2a5f;
    border-color: #0f2a5f;
}

.payment-page .empty-state {
    padding: 55px 20px;
    text-align: center;
}

.payment-page .empty-icon {
    font-size: 2.5rem;
    color: #94a3b8;
    margin-bottom: 15px;
}

.payment-page .table-responsive {
    border-radius: 0 0 16px 16px;
}

@media (max-width: 767px) {
    .payment-page {
        padding-top: 20px;
    }

    .payment-page .summary-card {
        padding: 17px;
    }

    .payment-page .summary-value {
        font-size: 1.4rem;
    }

    .payment-page .content-card-header,
    .payment-page .filter-area {
        padding: 16px;
    }
}
</style>

<div class="payment-page">
    <div class="container">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h2 class="page-title mb-2">
                    <i class="fas fa-receipt me-2"></i>Payment History
                </h2>

                <p class="page-subtitle mb-0">
                    View your course payments, transaction references and access status.
                </p>
            </div>

            <a
                href="<?= e(base_url('assan_computer_institute/student/dashboard.php')) ?>"
                class="btn btn-outline-primary rounded-pill px-4"
            >
                <i class="fas fa-arrow-left me-2"></i>Dashboard
            </a>
        </div>

        <?php if ($pageError !== ''): ?>

            <div class="alert alert-danger rounded-3">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?= e($pageError) ?>
            </div>

        <?php else: ?>

            <div class="row g-3 mb-4">

                <div class="col-6 col-lg-3">
                    <div class="summary-card">
                        <div class="d-flex justify-content-between align-items-center gap-2">
                            <span class="summary-label">Total Payments</span>
                            <span class="summary-icon">
                                <i class="fas fa-file-invoice-dollar"></i>
                            </span>
                        </div>
                        <div class="summary-value">
                            <?= number_format($totalPayments) ?>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="summary-card">
                        <div class="d-flex justify-content-between align-items-center gap-2">
                            <span class="summary-label">Paid Payments</span>
                            <span class="summary-icon">
                                <i class="fas fa-check-circle"></i>
                            </span>
                        </div>
                        <div class="summary-value">
                            <?= number_format($paidPayments) ?>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="summary-card">
                        <div class="d-flex justify-content-between align-items-center gap-2">
                            <span class="summary-label">Pending Payments</span>
                            <span class="summary-icon">
                                <i class="fas fa-clock"></i>
                            </span>
                        </div>
                        <div class="summary-value">
                            <?= number_format($pendingPayments) ?>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="summary-card">
                        <div class="d-flex justify-content-between align-items-center gap-2">
                            <span class="summary-label">Total Paid</span>
                            <span class="summary-icon">
                                <i class="fas fa-wallet"></i>
                            </span>
                        </div>
                        <div class="summary-value">
                            Rs. <?= number_format($totalPaidAmount, 2) ?>
                        </div>
                    </div>
                </div>

            </div>

            <div class="content-card">

                <div class="content-card-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
                    <h5>
                        <i class="fas fa-history me-2"></i>Transaction Records
                    </h5>

                    <span class="small-muted">
                        <?= number_format(count($payments)) ?> record(s) displayed
                    </span>
                </div>

                <form method="GET"
                      action="<?= e(base_url('assan_computer_institute/student/payments.php')) ?>"
                      class="filter-area">

                    <div class="row g-3">

                        <div class="col-md-7">
                            <label for="search" class="form-label fw-semibold">
                                Search payments
                            </label>

                            <input
                                type="search"
                                name="search"
                                id="search"
                                class="form-control"
                                placeholder="Course name, order reference or transaction ID"
                                value="<?= e($search) ?>"
                            >
                        </div>

                        <div class="col-md-3">
                            <label for="status" class="form-label fw-semibold">
                                Payment status
                            </label>

                            <select name="status" id="status" class="form-select">
                                <option value="">All statuses</option>
                                <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>
                                    Pending
                                </option>
                                <option value="paid" <?= $statusFilter === 'paid' ? 'selected' : '' ?>>
                                    Paid
                                </option>
                                <option value="failed" <?= $statusFilter === 'failed' ? 'selected' : '' ?>>
                                    Failed
                                </option>
                                <option value="cancelled" <?= $statusFilter === 'cancelled' ? 'selected' : '' ?>>
                                    Cancelled
                                </option>
                                <option value="refunded" <?= $statusFilter === 'refunded' ? 'selected' : '' ?>>
                                    Refunded
                                </option>
                            </select>
                        </div>

                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100 rounded-3">
                                <i class="fas fa-filter me-1"></i>Filter
                            </button>
                        </div>

                    </div>

                    <?php if ($search !== '' || $statusFilter !== ''): ?>
                        <div class="mt-3">
                            <a
                                href="<?= e(base_url('assan_computer_institute/student/payments.php')) ?>"
                                class="small text-decoration-none"
                            >
                                <i class="fas fa-times me-1"></i>Clear filters
                            </a>
                        </div>
                    <?php endif; ?>

                </form>

                <?php if (empty($payments)): ?>

                    <div class="empty-state">
                        <div class="empty-icon">
                            <i class="fas fa-receipt"></i>
                        </div>

                        <h5 class="fw-bold text-dark">No payment records found</h5>

                        <p class="text-muted mb-4">
                            Your course payment transactions will appear here.
                        </p>

                        <a
                            href="<?= e(base_url('assan_computer_institute/index.php')) ?>"
                            class="btn btn-primary rounded-pill px-4"
                        >
                            <i class="fas fa-book-open me-2"></i>Explore Courses
                        </a>
                    </div>

                <?php else: ?>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Course / Order</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Payment Status</th>
                                    <th>Access</th>
                                    <th>Date</th>
                                    <th>Details</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($payments as $payment): ?>

                                    <?php
                                    $courseName = !empty($payment['current_course_title'])
                                        ? $payment['current_course_title']
                                        : $payment['course_name'];

                                    $paymentStatus = (string) $payment['payment_status'];
                                    $accessStatus = (string) $payment['access_status'];

                                    $proofPath = trim((string) ($payment['payment_proof'] ?? ''));

                                    // Only allow relative paths inside the payment proof directory.
                                    $proofPath = str_replace('\\', '/', $proofPath);

                                    $proofIsSafe = $proofPath !== ''
                                        && strpos($proofPath, '..') === false
                                        && strpos($proofPath, '/') !== 0
                                        && preg_match('~^uploads/payment_proofs/[A-Za-z0-9._/-]+$~', $proofPath);

                                    $proofUrl = $proofIsSafe
                                        ? base_url('assan_computer_institute/' . $proofPath)
                                        : '';
                                    ?>

                                    <tr>
                                        <td>
                                            <div class="course-name">
                                                <?= e($courseName) ?>
                                            </div>

                                            <div class="small-muted mt-1">
                                                Order: <?= e($payment['order_ref']) ?>
                                            </div>

                                            <?php if (!empty($payment['gateway_txn_id'])): ?>
                                                <div class="small-muted mt-1">
                                                    Txn: <?= e($payment['gateway_txn_id']) ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <strong class="text-dark">
                                                Rs. <?= number_format((float) $payment['amount'], 2) ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <span class="fw-semibold">
                                                <?= e(payment_method_label($payment['payment_method'])) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <span class="status-badge <?= e(payment_status_class($paymentStatus)) ?>">
                                                <?= e(ucfirst($paymentStatus)) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <span class="status-badge <?= $accessStatus === 'active' ? 'status-paid' : ($accessStatus === 'pending' ? 'status-pending' : 'status-neutral') ?>">
                                                <?= e(ucfirst($accessStatus)) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <div class="small-muted">
                                                <?= e(date('d M Y', strtotime($payment['created_at']))) ?>
                                            </div>

                                            <?php if (!empty($payment['paid_at']) && $paymentStatus === 'paid'): ?>
                                                <div class="small-muted mt-1">
                                                    Paid: <?= e(date('d M Y', strtotime($payment['paid_at']))) ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if ($proofUrl !== ''): ?>
                                                <a
                                                    href="<?= e($proofUrl) ?>"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    class="btn btn-sm btn-outline-secondary rounded-pill mb-1"
                                                >
                                                    <i class="fas fa-file-image me-1"></i>Receipt
                                                </a>
                                            <?php endif; ?>

                                            <?php if ($paymentStatus === 'pending'): ?>
                                                <div class="small-muted mt-1">
                                                    Awaiting verification
                                                </div>
                                            <?php elseif ($paymentStatus === 'paid' && $accessStatus === 'active'): ?>
                                                <div class="small text-success mt-1">
                                                    <i class="fas fa-check-circle me-1"></i>Access granted
                                                </div>
                                            <?php elseif ($paymentStatus === 'paid' && $accessStatus !== 'active'): ?>
                                                <div class="small-muted mt-1">
                                                    Payment confirmed; access not active
                                                </div>
                                            <?php elseif (in_array($paymentStatus, ['failed', 'cancelled'], true)): ?>
                                                <div class="small text-danger mt-1">
                                                    <?= e(ucfirst($paymentStatus)) ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                <?php endif; ?>

            </div>

            <div class="alert alert-info border-0 rounded-3 mt-4">
                <i class="fas fa-info-circle me-2"></i>
                Payments submitted through JazzCash, Easypaisa or bank transfer remain pending until an administrator verifies them. Course access depends on the recorded payment and access statuses.
            </div>

        <?php endif; ?>

    </div>
</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>

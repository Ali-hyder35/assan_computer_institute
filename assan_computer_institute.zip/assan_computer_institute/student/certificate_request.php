
<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(base_url(
        'assan_computer_institute/student/certificates.php'
    ));
}

try {
    verify_csrf();

    $user = current_user();
    $userId = (int) $user['id'];
    $courseId = isset($_POST['course_id'])
        ? (int) $_POST['course_id']
        : 0;

    if ($courseId <= 0) {
        throw new Exception('Invalid course selected.');
    }

    // Student must have paid for and have active access to the course.
    $stmt = $pdo->prepare("
        SELECT c.id, c.title
        FROM courses c
        INNER JOIN enrollments en ON en.course_id = c.id
        WHERE c.id = ?
          AND en.user_id = ?
          AND en.payment_status = 'paid'
          AND en.access_status = 'active'
        LIMIT 1
    ");
    $stmt->execute(array($courseId, $userId));
    $course = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$course) {
        throw new Exception(
            'You need an active, paid enrollment to apply for this certificate.'
        );
    }

    // Verify all active videos have been completed.
    $stmt = $pdo->prepare("
        SELECT
            COUNT(cv.id) AS total_videos,
            COALESCE(SUM(
                CASE WHEN p.completed = 1 THEN 1 ELSE 0 END
            ), 0) AS completed_videos
        FROM course_videos cv
        LEFT JOIN student_video_progress p
          ON p.video_id = cv.id
         AND p.course_id = cv.course_id
         AND p.user_id = ?
        WHERE cv.course_id = ?
          AND cv.active = 1
    ");
    $stmt->execute(array($userId, $courseId));
    $videoStats = $stmt->fetch(PDO::FETCH_ASSOC);

    $totalVideos = (int) $videoStats['total_videos'];
    $completedVideos = (int) $videoStats['completed_videos'];

    if ($totalVideos === 0 || $completedVideos < $totalVideos) {
        throw new Exception(
            'You are not eligible yet. Complete all active course videos first.'
        );
    }

    // Verify at least one submitted exam has been passed.
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM exam_attempts ea
        INNER JOIN exams e ON e.id = ea.exam_id
        WHERE ea.user_id = ?
          AND e.course_id = ?
          AND e.active = 1
          AND ea.status = 'submitted'
          AND ea.result = 'passed'
    ");
    $stmt->execute(array($userId, $courseId));

    if ((int) $stmt->fetchColumn() < 1) {
        throw new Exception(
            'You are not eligible yet. Pass at least one exam for this course.'
        );
    }

    // Reuse the existing request if the admin previously rejected it.
    $stmt = $pdo->prepare("
        SELECT id, status
        FROM certificate_requests
        WHERE user_id = ? AND course_id = ?
        LIMIT 1
    ");
    $stmt->execute(array($userId, $courseId));
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing && $existing['status'] === 'approved') {
        throw new Exception(
            'Your certificate for this course has already been approved.'
        );
    }

    if ($existing && $existing['status'] === 'pending') {
        throw new Exception(
            'Your certificate request is already awaiting admin review.'
        );
    }

    if ($existing && $existing['status'] === 'rejected') {
        $stmt = $pdo->prepare("
            UPDATE certificate_requests
            SET status = 'pending',
                certificate_number = NULL,
                admin_note = NULL,
                requested_at = CURRENT_TIMESTAMP,
                reviewed_at = NULL,
                reviewed_by = NULL
            WHERE id = ? AND user_id = ? AND course_id = ?
        ");
        $stmt->execute(array(
            (int) $existing['id'],
            $userId,
            $courseId
        ));
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO certificate_requests
                (user_id, course_id, status)
            VALUES (?, ?, 'pending')
        ");
        $stmt->execute(array($userId, $courseId));
    }

    flash('success', 'Certificate request submitted successfully.');

} catch (Throwable $e) {
    if ($e instanceof PDOException) {
        error_log('Certificate request database error: ' . $e->getMessage());
        flash('error', 'A database error occurred while submitting your request.');
    } else {
        flash('error', $e->getMessage());
    }
}

redirect(base_url(
    'assan_computer_institute/student/certificates.php'
));


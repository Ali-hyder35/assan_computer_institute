<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student Registration
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| Selected Course
|--------------------------------------------------------------------------
|
| Course can come from:
|
| 1. ?course=ID
| 2. POST course_id
| 3. Session pending_course_id
|
*/

$courseId = isset($_GET['course'])
    ? (int) $_GET['course']
    : 0;


/*
|--------------------------------------------------------------------------
| Remember Course For Registration Flow
|--------------------------------------------------------------------------
*/

if ($courseId > 0) {

    $_SESSION['pending_course_id'] = $courseId;

} elseif (
    isset($_SESSION['pending_course_id'])
    && (int) $_SESSION['pending_course_id'] > 0
) {

    $courseId = (int) $_SESSION['pending_course_id'];
}


/*
|--------------------------------------------------------------------------
| If Already Logged In
|--------------------------------------------------------------------------
|
| A logged-in student does not need to register again.
| Send them directly to enrollment.
|
*/

$currentUser = current_user();

if ($currentUser) {

    if ($courseId > 0) {

        redirect(
            base_url(
                'assan_computer_institute/student/enroll.php?course_id=' . $courseId
            )
        );

        exit;
    }

    redirect(
        base_url('assan_computer_institute/student/register.php')
    );

    exit;
}


$course = null;


/*
|--------------------------------------------------------------------------
| Load Selected Course
|--------------------------------------------------------------------------
*/

if ($courseId > 0) {

    $courseStatement = $pdo->prepare(
        "SELECT *
         FROM courses
         WHERE id = ?
         AND active = 1
         LIMIT 1"
    );

    $courseStatement->execute(
        array($courseId)
    );

    $course = $courseStatement->fetch(
        PDO::FETCH_ASSOC
    );


    /*
    |--------------------------------------------------------------------------
    | If Course Does Not Exist
    |--------------------------------------------------------------------------
    */

    if (!$course) {

        $courseId = 0;

        unset($_SESSION['pending_course_id']);
    }
}


/*
|--------------------------------------------------------------------------
| Form Error
|--------------------------------------------------------------------------
*/

$error = '';


/*
|--------------------------------------------------------------------------
| Registration
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();


    /*
    |--------------------------------------------------------------------------
    | Form Values
    |--------------------------------------------------------------------------
    */

    $name = trim(
        isset($_POST['name'])
            ? $_POST['name']
            : ''
    );

    $email = trim(
        isset($_POST['email'])
            ? $_POST['email']
            : ''
    );

    $mobile = trim(
        isset($_POST['mobile'])
            ? $_POST['mobile']
            : ''
    );

    $password = isset($_POST['password'])
        ? $_POST['password']
        : '';

    $passwordConfirmation = isset($_POST['password_confirmation'])
        ? $_POST['password_confirmation']
        : '';

    $postedCourseId = isset($_POST['course_id'])
        ? (int) $_POST['course_id']
        : 0;


    /*
    |--------------------------------------------------------------------------
    | Use Posted Course ID
    |--------------------------------------------------------------------------
    */

    if ($postedCourseId > 0) {

        $courseId = $postedCourseId;

        $_SESSION['pending_course_id'] = $courseId;
    }


    /*
    |--------------------------------------------------------------------------
    | Validate Selected Course
    |--------------------------------------------------------------------------
    */

    if ($courseId > 0) {

        $courseStatement = $pdo->prepare(
            "SELECT *
             FROM courses
             WHERE id = ?
             AND active = 1
             LIMIT 1"
        );

        $courseStatement->execute(
            array($courseId)
        );

        $course = $courseStatement->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$course) {

            $courseId = 0;

            unset($_SESSION['pending_course_id']);

        }
    }


    /*
    |--------------------------------------------------------------------------
    | Validate Registration Data
    |--------------------------------------------------------------------------
    */

    if ($name === '') {

        $error = 'Please enter your full name.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = 'Please enter a valid email address.';

    } elseif ($mobile === '') {

        $error = 'Please enter your mobile number.';

    } elseif (strlen($password) < 8) {

        $error = 'Password must be at least 8 characters.';

    } elseif ($password !== $passwordConfirmation) {

        $error = 'Password and confirmation password do not match.';

    } else {


        /*
        |--------------------------------------------------------------------------
        | Check Existing Email
        |--------------------------------------------------------------------------
        */

        $checkStatement = $pdo->prepare(
            "SELECT id, role, status
             FROM users
             WHERE email = ?
             LIMIT 1"
        );

        $checkStatement->execute(
            array($email)
        );

        $existingUser = $checkStatement->fetch(
            PDO::FETCH_ASSOC
        );


        if ($existingUser) {

            /*
            |--------------------------------------------------------------------------
            | Existing Account
            |--------------------------------------------------------------------------
            |
            | Do NOT create another account.
            |
            | Send the student to login while preserving
            | the selected course.
            |
            */

            if ($courseId > 0) {

                $_SESSION['pending_course_id'] = $courseId;

                $error =
                    'This email address is already registered. Please login to continue your enrollment.';

            } else {

                $error =
                    'This email address is already registered. Please login instead.';
            }

        } else {

            try {

                /*
                |--------------------------------------------------------------------------
                | Password Hash
                |--------------------------------------------------------------------------
                */

                $passwordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


                /*
                |--------------------------------------------------------------------------
                | Create Student Account
                |--------------------------------------------------------------------------
                |
                | Explicitly set:
                |
                | role   = student
                | status = active
                |
                */

                $insertStatement = $pdo->prepare(
                    "INSERT INTO users
                    (
                        full_name,
                        email,
                        mobile,
                        password_hash,
                        role,
                        status
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        'student',
                        'active'
                    )"
                );


                $insertStatement->execute(
                    array(
                        $name,
                        $email,
                        $mobile,
                        $passwordHash
                    )
                );


                /*
                |--------------------------------------------------------------------------
                | Automatically Login New Student
                |--------------------------------------------------------------------------
                */

                $loginSuccessful = login_user(
                    $pdo,
                    $email,
                    $password
                );


                if (!$loginSuccessful) {

                    /*
                    |--------------------------------------------------------------------------
                    | If Automatic Login Fails
                    |--------------------------------------------------------------------------
                    */

                    if ($courseId > 0) {

                        $_SESSION['pending_course_id'] = $courseId;

                    }

                    redirect(
                        base_url('assan_computer_institute/student/login.php')
                    );

                    exit;
                }


                /*
                |--------------------------------------------------------------------------
                | Course Enrollment Flow
                |--------------------------------------------------------------------------
                |
                | If the student registered from a course page,
                | send them directly to enroll.php.
                |
                | enroll.php will create the enrollment and then
                | send the student to My Courses.
                |
                */

                if ($courseId > 0) {

                    $_SESSION['pending_course_id'] = $courseId;

                    redirect(
                        base_url(
                            'assan_computer_institute/student/enroll.php?course_id=' . $courseId
                        )
                    );

                    exit;
                }


                /*
                |--------------------------------------------------------------------------
                | No Course Selected
                |--------------------------------------------------------------------------
                */

                redirect(
                    base_url('assan_computer_institute/student/dashboard.php')
                );

                exit;


            } catch (PDOException $e) {

                /*
                |--------------------------------------------------------------------------
                | Duplicate Email Safety Check
                |--------------------------------------------------------------------------
                */

                if (
                    isset($e->errorInfo[1])
                    && (int) $e->errorInfo[1] === 1062
                ) {

                    if ($courseId > 0) {

                        $_SESSION['pending_course_id'] = $courseId;

                    }

                    $error =
                        'This email address is already registered. Please login instead.';

                } else {

                    $error =
                        'Unable to create your account right now. Please try again.';
                }
            }
        }
    }
}


$pageTitle = 'Student Registration';

include dirname(__DIR__) . '/partials/header.php';

?>


<!-- =========================================================
     REGISTRATION PAGE
========================================================= -->

<div class="auth-wrap">

    <div class="container">

        <div class="auth-card">

            <!-- =================================================
                 HEADER
            ================================================== -->

            <div class="text-center mb-4">

                <div class="icon-box mx-auto mb-3">

                    <i class="bi bi-person-plus"></i>

                </div>

                <h2 class="section-title">
                    Create Student Account
                </h2>

                <p class="text-secondary">
                    Start your learning journey with
                    Assan Computer Institute.
                </p>

            </div>


            <!-- =================================================
                 ERROR MESSAGE
            ================================================== -->

            <?php if ($error): ?>

                <div
                    class="alert alert-danger"
                    role="alert"
                >

                    <i class="bi bi-exclamation-triangle me-2"></i>

                    <?= e($error) ?>


                    <?php if ($courseId > 0): ?>

                        <div class="mt-2">

                            <a
                                href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/login.php?course=' .
                                        $courseId
                                    )
                                ) ?>"
                                class="alert-link"
                            >
                                Login to continue
                            </a>

                        </div>

                    <?php endif; ?>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 SELECTED COURSE
            ================================================== -->

            <?php if ($course): ?>

                <div class="alert alert-primary">

                    <div class="d-flex align-items-center">

                        <i class="bi bi-book me-3 fs-4"></i>

                        <div>

                            <strong>
                                Selected Course
                            </strong>

                            <div>

                                <?php
                                /*
                                |--------------------------------------------------------------------------
                                | Your existing course table uses title.
                                | Fallback to name only if an older record uses name.
                                |--------------------------------------------------------------------------
                                */

                                $courseTitle = isset($course['title'])
                                    ? $course['title']
                                    : (
                                        isset($course['name'])
                                            ? $course['name']
                                            : ''
                                    );
                                ?>

                                <?= e($courseTitle) ?>

                            </div>


                            <?php if (isset($course['price'])): ?>

                                <small>

                                    Course Fee:

                                    <strong>

                                        Rs.
                                        <?= number_format(
                                            (float) $course['price']
                                        ) ?>

                                    </strong>

                                </small>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 REGISTRATION FORM
            ================================================== -->

            <form
                method="post"
                action=""
                autocomplete="on"
            >

                <?= csrf_field() ?>


                <!-- =================================================
                     COURSE ID
                ================================================== -->

                <input
                    type="hidden"
                    name="course_id"
                    value="<?= e($courseId) ?>"
                >


                <!-- =================================================
                     FULL NAME
                ================================================== -->

                <div class="mb-3">

                    <label
                        for="name"
                        class="form-label fw-semibold"
                    >
                        Full Name
                    </label>

                    <input
                        class="form-control"
                        type="text"
                        id="name"
                        name="name"
                        value="<?= e(old('name')) ?>"
                        placeholder="Enter your full name"
                        autocomplete="name"
                        maxlength="120"
                        required
                    >

                </div>


                <!-- =================================================
                     EMAIL
                ================================================== -->

                <div class="mb-3">

                    <label
                        for="email"
                        class="form-label fw-semibold"
                    >
                        Email Address
                    </label>

                    <input
                        class="form-control"
                        type="email"
                        id="email"
                        name="email"
                        value="<?= e(old('email')) ?>"
                        placeholder="Enter your email address"
                        autocomplete="email"
                        maxlength="190"
                        required
                    >

                </div>


                <!-- =================================================
                     MOBILE
                ================================================== -->

                <div class="mb-3">

                    <label
                        for="mobile"
                        class="form-label fw-semibold"
                    >
                        Mobile Number
                    </label>

                    <input
                        class="form-control"
                        type="tel"
                        id="mobile"
                        name="mobile"
                        value="<?= e(old('mobile')) ?>"
                        placeholder="03XX XXXXXXX"
                        autocomplete="tel"
                        maxlength="30"
                        required
                    >

                </div>


                <!-- =================================================
                     PASSWORD
                ================================================== -->

                <div class="mb-3">

                    <label
                        for="password"
                        class="form-label fw-semibold"
                    >
                        Password
                    </label>

                    <input
                        class="form-control"
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Create a password"
                        autocomplete="new-password"
                        minlength="8"
                        required
                    >

                    <div class="form-text">

                        Password must contain at least
                        8 characters.

                    </div>

                </div>


                <!-- =================================================
                     CONFIRM PASSWORD
                ================================================== -->

                <div class="mb-4">

                    <label
                        for="password_confirmation"
                        class="form-label fw-semibold"
                    >
                        Confirm Password
                    </label>

                    <input
                        class="form-control"
                        type="password"
                        id="password_confirmation"
                        name="password_confirmation"
                        placeholder="Confirm your password"
                        autocomplete="new-password"
                        minlength="8"
                        required
                    >

                </div>


                <!-- =================================================
                     REGISTER BUTTON
                ================================================== -->

                <button
                    type="submit"
                    class="btn btn-primary w-100 py-2"
                >

                    <i class="bi bi-person-plus me-2"></i>

                    Create Student Account

                </button>

            </form>


            <!-- =================================================
                 LOGIN LINK
            ================================================== -->

            <p class="text-center mt-4 mb-0 text-secondary">

                Already registered?

                <a
                    href="<?= e(base_url('assan_computer_institute/student/login.php')) ?>"
                    class="fw-semibold"
                >
                    Login
                </a>

            </p>


            <!-- =================================================
                 SECURITY INFORMATION
            ================================================== -->

            <div class="mt-4">

                <div class="alert alert-light border mb-0">

                    <div class="small text-secondary">

                        <i class="bi bi-shield-check me-2"></i>

                        Your password is securely stored using
                        password hashing.

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<?php

include dirname(__DIR__) . '/partials/footer.php';

?>
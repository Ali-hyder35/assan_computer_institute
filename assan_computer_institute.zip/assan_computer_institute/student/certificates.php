<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];
$pageTitle = 'My Certificates';

$stmt = $pdo->prepare("
    SELECT DISTINCT c.id, c.title, c.description
    FROM enrollments en
    INNER JOIN courses c ON c.id = en.course_id
    WHERE en.user_id = ?
      AND en.payment_status = 'paid'
      AND en.access_status = 'active'
    ORDER BY c.title
");
$stmt->execute(array($userId));
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$certificateData = array();

foreach ($courses as $course) {
    $courseId = (int) $course['id'];

    // Count active course videos and completed videos.
    $stmt = $pdo->prepare("
        SELECT
            COUNT(cv.id) AS total_videos,
            COALESCE(SUM(
                CASE WHEN svp.completed = 1 THEN 1 ELSE 0 END
            ), 0) AS completed_videos
        FROM course_videos cv
        LEFT JOIN student_video_progress svp
          ON svp.video_id = cv.id
         AND svp.course_id = cv.course_id
         AND svp.user_id = ?
        WHERE cv.course_id = ?
          AND cv.active = 1
    ");
    $stmt->execute(array($userId, $courseId));
    $videoStats = $stmt->fetch(PDO::FETCH_ASSOC);

    $totalVideos = (int) $videoStats['total_videos'];
    $completedVideos = (int) $videoStats['completed_videos'];

    // Require at least one active video and all active videos completed.
    $courseComplete = (
        $totalVideos > 0 &&
        $completedVideos >= $totalVideos
    );

    // Require at least one passed, submitted exam for this course.
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM exam_attempts ea
        INNER JOIN exams e ON e.id = ea.exam_id
        WHERE ea.user_id = ?
          AND e.course_id = ?
          AND e.active = 1
          AND ea.status = 'submitted'
          AND ea.result = 'passed'
    ");
    $stmt->execute(array($userId, $courseId));
    $hasPassedExam = ((int) $stmt->fetchColumn() > 0);

    $eligible = ($courseComplete && $hasPassedExam);

    $stmt = $pdo->prepare("
        SELECT *
        FROM certificate_requests
        WHERE user_id = ? AND course_id = ?
        LIMIT 1
    ");
    $stmt->execute(array($userId, $courseId));
    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    $reasons = array();

    if (!$courseComplete) {
        if ($totalVideos === 0) {
            $reasons[] = 'This course has no active videos available for completion tracking.';
        } else {
            $reasons[] = 'Course incomplete: complete all course videos (' .
                $completedVideos . ' of ' . $totalVideos . ' completed).';
        }
    }

    if (!$hasPassedExam) {
        $reasons[] = 'Exam requirement not met: pass at least one exam for this course.';
    }

    $certificateData[] = array(
        'course' => $course,
        'total_videos' => $totalVideos,
        'completed_videos' => $completedVideos,
        'course_complete' => $courseComplete,
        'has_passed_exam' => $hasPassedExam,
        'eligible' => $eligible,
        'reasons' => $reasons,
        'request' => $request
    );
}

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
body { background: #f5f7fb; }
.certificate-page { padding: 30px 0 55px; }
.certificate-hero {
    background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
    color: #fff; padding: 28px; border-radius: 18px;
    margin-bottom: 24px;
}
.certificate-card {
    background: #fff; border: 1px solid #e2e8f0;
    border-radius: 16px; padding: 23px;
    margin-bottom: 18px;
    box-shadow: 0 8px 25px rgba(15,42,95,.06);
}
.muted { color: #64748b; }
.status-pill {
    display: inline-block; padding: 6px 12px;
    border-radius: 30px; font-size: 12px; font-weight: 700;
}
.status-approved { background: #dcfce7; color: #166534; }
.status-pending { background: #fef3c7; color: #92400e; }
.status-rejected { background: #fee2e2; color: #991b1b; }
.status-ineligible { background: #e2e8f0; color: #334155; }
</style>

<div class="container certificate-page">
    <div class="certificate-hero">
        <h2 class="mb-2">My Certificates</h2>
        <p class="mb-0">
            Complete your course and pass an exam to become eligible
            for a course completion certificate.
        </p>
    </div>

    <?php if (empty($certificateData)): ?>
        <div class="alert alert-info">
            No active, paid courses were found for your account.
            Enroll in a course and complete its requirements to apply
            for a certificate.
        </div>
    <?php endif; ?>

    <?php foreach ($certificateData as $item): ?>
        <?php
        $course = $item['course'];
        $request = $item['request'];
        $eligible = $item['eligible'];
        ?>
        <div class="certificate-card">
            <div class="d-flex flex-wrap justify-content-between
                        align-items-start gap-3">
                <div>
                    <h5 class="fw-bold mb-2">
                        <?= e($course['title']) ?>
                    </h5>

                    <div class="muted small mb-2">
                        Course videos completed:
                        <?= (int) $item['completed_videos'] ?>
                        /
                        <?= (int) $item['total_videos'] ?>
                    </div>

                    <div class="muted small">
                        Exam requirement:
                        <?php if ($item['has_passed_exam']): ?>
                            <span class="text-success fw-bold">Passed</span>
                        <?php else: ?>
                            <span class="text-danger fw-bold">Not passed</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div>
                    <?php if ($request && $request['status'] === 'approved'): ?>
                        <span class="status-pill status-approved">Approved</span>
                    <?php elseif ($request && $request['status'] === 'pending'): ?>
                        <span class="status-pill status-pending">Under Review</span>
                    <?php elseif ($request && $request['status'] === 'rejected'): ?>
                        <span class="status-pill status-rejected">Rejected</span>
                    <?php elseif ($eligible): ?>
                        <span class="status-pill status-approved">Eligible</span>
                    <?php else: ?>
                        <span class="status-pill status-ineligible">Not Eligible</span>
                    <?php endif; ?>
                </div>
            </div>

            <hr>

            <?php if ($request && $request['status'] === 'approved'): ?>
                <p class="text-success fw-semibold mb-2">
                    Your certificate has been approved.
                </p>

                <p class="muted small">
                    Certificate number:
                    <?= e($request['certificate_number']) ?>
                </p>

                <a class="btn btn-primary"
                   href="<?= e(base_url(
                       'assan_computer_institute/student/certificate_view.php?id=' .
                       (int) $request['id']
                   )) ?>">
                    View Certificate
                </a>

            <?php elseif ($request && $request['status'] === 'pending'): ?>
                <p class="text-warning-emphasis mb-0">
                    Your certificate request is awaiting admin review.
                </p>

            <?php else: ?>

                <?php if (!$eligible): ?>
                    <div class="alert alert-warning">
                        <strong>You are not eligible for a certificate yet.</strong>
                        <ul class="mb-0 mt-2">
                            <?php foreach ($item['reasons'] as $reason): ?>
                                <li><?= e($reason) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php else: ?>
                    <p class="text-success">
                        You have completed the course requirements and
                        passed an exam. You can apply for your certificate.
                    </p>
                <?php endif; ?>

                <?php if ($request && $request['status'] === 'rejected'): ?>
                    <div class="alert alert-danger">
                        <strong>Your previous request was rejected.</strong>
                        <?php if (!empty($request['admin_note'])): ?>
                            <p class="mb-0 mt-2">
                                Admin reason: <?= e($request['admin_note']) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ($eligible): ?>
                    <form method="post"
                          action="<?= e(base_url(
                              'assan_computer_institute/student/certificate_request.php'
                          )) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="course_id"
                               value="<?= (int) $course['id'] ?>">

                        <button type="submit" class="btn btn-primary">
                            <?= ($request && $request['status'] === 'rejected')
                                ? 'Apply Again'
                                : 'Apply for Certificate' ?>
                        </button>
                    </form>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>


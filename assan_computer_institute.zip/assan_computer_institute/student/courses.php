<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();

$userId = (int) $user['id'];

$pageTitle = 'Browse Courses';

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';


/*
|--------------------------------------------------------------------------
| Course Query
|--------------------------------------------------------------------------
|
| We check:
|
| 1. total lessons
| 2. whether the student has ANY enrollment
| 3. payment status
| 4. access status
|
| This is important because a newly enrolled student may still have
| payment_status = pending and access_status = pending.
|
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        c.*,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            WHERE cv.course_id = c.id
              AND cv.active = 1
        ) AS total_lessons,

        EXISTS (
            SELECT 1
            FROM enrollments e
            WHERE e.user_id = ?
              AND e.course_id = c.id
        ) AS is_enrolled,

        (
            SELECT e.payment_status
            FROM enrollments e
            WHERE e.user_id = ?
              AND e.course_id = c.id
            ORDER BY e.id DESC
            LIMIT 1
        ) AS enrollment_payment_status,

        (
            SELECT e.access_status
            FROM enrollments e
            WHERE e.user_id = ?
              AND e.course_id = c.id
            ORDER BY e.id DESC
            LIMIT 1
        ) AS enrollment_access_status,

        (
            SELECT e.id
            FROM enrollments e
            WHERE e.user_id = ?
              AND e.course_id = c.id
            ORDER BY e.id DESC
            LIMIT 1
        ) AS enrollment_id

    FROM courses c

    WHERE c.active = 1
";

$params = array(
    $userId,
    $userId,
    $userId,
    $userId
);


if ($search !== '') {

    $sql .= "
        AND (
            c.title LIKE ?
            OR c.description LIKE ?
            OR c.duration LIKE ?
        )
    ";

    $searchValue = '%' . $search . '%';

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;
}


$sql .= "
    ORDER BY c.created_at DESC
";


$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);


include dirname(__DIR__) . '/partials/header.php';

?>

<style>

    :root {
        --lms-primary: #0f2a5f;
        --lms-primary-light: #1e4b8f;
        --lms-accent: #2563eb;
        --lms-accent-hover: #1d4ed8;
        --lms-bg: #f5f7fb;
        --lms-card: #ffffff;
        --lms-text: #1e293b;
        --lms-muted: #64748b;
        --lms-border: #e2e8f0;
        --lms-success: #16a34a;
        --lms-warning: #d97706;
        --lms-danger: #dc2626;
        --lms-shadow: 0 8px 25px rgba(15, 42, 95, 0.08);
    }


    body {
        background: var(--lms-bg);
    }


    .courses-page {
        padding: 35px 0 60px;
    }


    /* Header */

    .page-header {
        background: linear-gradient(
            135deg,
            #0f2a5f,
            #1e4b8f
        );

        color: #fff;

        border-radius: 20px;

        padding: 30px;

        margin-bottom: 25px;

        box-shadow: var(--lms-shadow);
    }


    .page-header h1 {
        font-size: 28px;
        font-weight: 700;
    }


    /* Search */

    .search-card {
        background: #fff;

        border: 1px solid var(--lms-border);

        border-radius: 16px;

        padding: 18px;

        box-shadow: var(--lms-shadow);

        margin-bottom: 30px;
    }


    .search-card .form-control {
        border-color: var(--lms-border);
        min-height: 44px;
    }


    .search-card .input-group-text {
        border-color: var(--lms-border);
        color: var(--lms-muted);
    }


    /* Course Card */

    .course-card {
        background: #fff;

        border: 1px solid var(--lms-border);

        border-radius: 18px;

        padding: 24px;

        height: 100%;

        box-shadow: var(--lms-shadow);

        transition: .2s ease;

        position: relative;
    }


    .course-card:hover {
        transform: translateY(-3px);

        box-shadow:
            0 14px 35px rgba(15, 42, 95, .12);
    }


    .course-icon {
        width: 58px;
        height: 58px;

        background: #eff6ff;

        color: var(--lms-accent);

        border-radius: 15px;

        display: flex;

        align-items: center;
        justify-content: center;

        font-size: 24px;
    }


    .course-title {
        font-size: 20px;

        font-weight: 700;

        color: var(--lms-primary);

        line-height: 1.4;
    }


    .course-description {
        color: var(--lms-muted);

        font-size: 14px;

        line-height: 1.7;

        min-height: 70px;
    }


    .course-meta {
        color: var(--lms-muted);

        font-size: 13px;
    }


    .price {
        color: var(--lms-primary);

        font-size: 20px;

        font-weight: 700;
    }


    /* Status */

    .course-status {
        display: inline-flex;

        align-items: center;

        gap: 5px;

        font-size: 12px;

        font-weight: 600;

        padding: 6px 10px;

        border-radius: 50px;
    }


    .status-active {
        background: #dcfce7;

        color: #166534;
    }


    .status-pending {
        background: #fef3c7;

        color: #92400e;
    }


    .status-suspended {
        background: #fee2e2;

        color: #991b1b;
    }


    .status-enrolled {
        background: #dbeafe;

        color: #1e40af;
    }


    /* Buttons */

    .btn-primary {
        background: var(--lms-accent);

        border-color: var(--lms-accent);
    }


    .btn-primary:hover {
        background: var(--lms-accent-hover);

        border-color: var(--lms-accent-hover);
    }


    .btn-outline-primary {
        color: var(--lms-accent);

        border-color: var(--lms-accent);
    }


    .btn-outline-primary:hover {
        background: var(--lms-accent);

        border-color: var(--lms-accent);
    }


    /* Empty */

    .empty-box {
        background: #fff;

        border: 1px dashed #cbd5e1;

        border-radius: 18px;

        padding: 55px 20px;

        text-align: center;

        color: var(--lms-muted);
    }


    /* Enrollment info */

    .enrollment-info {
        font-size: 13px;

        color: var(--lms-muted);

        background: #f8fafc;

        border-radius: 10px;

        padding: 10px 12px;

        margin-bottom: 15px;
    }


    /* Responsive */

    @media (max-width: 767px) {

        .courses-page {
            padding: 20px 0 40px;
        }


        .page-header {
            padding: 22px;
        }


        .page-header h1 {
            font-size: 23px;
        }


        .course-card {
            padding: 20px;
        }

    }

</style>


<div class="courses-page">

    <div class="container">


        <!-- ==========================================================
             PAGE HEADER
        =========================================================== -->

        <div class="page-header">

            <div class="row align-items-center">

                <div class="col-lg-8">

                    <h1 class="mb-2">

                        <i class="fa-solid fa-book-open me-2"></i>

                        Browse Courses

                    </h1>


                    <p class="mb-0 text-white-50">

                        Choose practical computer courses and develop
                        professional skills.

                    </p>

                </div>


                <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/dashboard.php'
                            )
                        ) ?>"
                        class="btn btn-light"
                    >

                        <i class="fa-solid fa-gauge me-1"></i>

                        Dashboard

                    </a>

                </div>

            </div>

        </div>



        <!-- ==========================================================
             SEARCH
        =========================================================== -->

        <div class="search-card">

            <form method="get">

                <div class="row g-2">

                    <div class="col-md-10">

                        <div class="input-group">

                            <span class="input-group-text bg-white">

                                <i class="fa-solid fa-search"></i>

                            </span>


                            <input
                                type="text"
                                name="search"
                                class="form-control"
                                placeholder="Search courses..."
                                value="<?= e($search) ?>"
                            >

                        </div>

                    </div>


                    <div class="col-md-2">

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >

                            <i class="fa-solid fa-search me-1"></i>

                            Search

                        </button>

                    </div>

                </div>

            </form>

        </div>



        <!-- ==========================================================
             COURSE LIST
        =========================================================== -->

        <div class="row g-4">


            <?php if (empty($courses)): ?>

                <div class="col-12">

                    <div class="empty-box">

                        <i class="fa-solid fa-book-open fa-3x mb-3"></i>


                        <h4>

                            No courses found

                        </h4>


                        <p class="mb-0">

                            Try another search term or check back later.

                        </p>

                    </div>

                </div>

            <?php endif; ?>



            <?php foreach ($courses as $course): ?>


                <?php

                /*
                |--------------------------------------------------------------------------
                | Enrollment State
                |--------------------------------------------------------------------------
                */

                $isEnrolled = !empty($course['is_enrolled']);

                $paymentStatus = isset(
                    $course['enrollment_payment_status']
                )
                    ? strtolower(
                        (string) $course['enrollment_payment_status']
                    )
                    : '';

                $accessStatus = isset(
                    $course['enrollment_access_status']
                )
                    ? strtolower(
                        (string) $course['enrollment_access_status']
                    )
                    : '';

                $enrollmentId = isset(
                    $course['enrollment_id']
                )
                    ? (int) $course['enrollment_id']
                    : 0;


                $hasActiveAccess =
                    $isEnrolled
                    &&
                    $paymentStatus === 'paid'
                    &&
                    $accessStatus === 'active';


                $paymentPending =
                    $isEnrolled
                    &&
                    $paymentStatus === 'pending';


                $accessSuspended =
                    $isEnrolled
                    &&
                    $accessStatus === 'suspended';

                ?>


                <div class="col-md-6 col-xl-4">

                    <div class="course-card">


                        <!-- Course Icon -->

                        <div class="course-icon mb-3">

                            <i class="fa-solid fa-laptop-code"></i>

                        </div>



                        <!-- Course Title -->

                        <div class="course-title mb-2">

                            <?= e($course['title']) ?>

                        </div>



                        <!-- Description -->

                        <div class="course-description mb-3">

                            <?= e(
                                mb_strimwidth(
                                    (string) $course['description'],
                                    0,
                                    180,
                                    '...'
                                )
                            ) ?>

                        </div>



                        <!-- Course Meta -->

                        <div class="course-meta mb-3">

                            <i class="fa-regular fa-clock me-1"></i>

                            <?= e(
                                $course['duration']
                                    ? $course['duration']
                                    : 'Flexible'
                            ) ?>


                            <span class="mx-2">•</span>


                            <i class="fa-solid fa-play-circle me-1"></i>

                            <?= (int) $course['total_lessons'] ?>

                            lessons

                        </div>



                        <!-- Price -->

                        <div class="d-flex justify-content-between align-items-center mb-3">

                            <div class="price">

                                <?= money($course['price']) ?>

                            </div>


                            <?php if ($hasActiveAccess): ?>

                                <span class="course-status status-active">

                                    <i class="fa-solid fa-circle-check"></i>

                                    Enrolled

                                </span>


                            <?php elseif ($paymentPending): ?>

                                <span class="course-status status-pending">

                                    <i class="fa-solid fa-clock"></i>

                                    Payment Pending

                                </span>


                            <?php elseif ($accessSuspended): ?>

                                <span class="course-status status-suspended">

                                    <i class="fa-solid fa-ban"></i>

                                    Suspended

                                </span>

                            <?php endif; ?>

                        </div>



                        <!-- ==================================================
                             ENROLLED / NOT ENROLLED ACTIONS
                        =================================================== -->


                        <?php if ($hasActiveAccess): ?>


                            <!-- Already Paid + Active -->

                            <div class="enrollment-info">

                                <i class="fa-solid fa-circle-check text-success me-1"></i>

                                You are enrolled in this course.

                            </div>


                            <a
                                href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/course.php?id=' .
                                        (int) $course['id']
                                    )
                                ) ?>"
                                class="btn btn-primary w-100"
                            >

                                <i class="fa-solid fa-play me-1"></i>

                                Continue Learning

                            </a>



                        <?php elseif ($paymentPending): ?>


                            <!-- Enrollment Created but Payment Pending -->

                            <div class="enrollment-info">

                                <i class="fa-solid fa-clock text-warning me-1"></i>

                                Your enrollment has been created.
                                Payment verification is pending.

                            </div>


                            <a
                                href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/enrolled_courses.php'
                                    )
                                ) ?>"
                                class="btn btn-outline-primary w-100"
                            >

                                <i class="fa-solid fa-folder-open me-1"></i>

                                View Enrollment

                            </a>



                        <?php elseif ($accessSuspended): ?>


                            <!-- Suspended -->

                            <div class="enrollment-info">

                                <i class="fa-solid fa-ban text-danger me-1"></i>

                                Your access to this course is currently
                                suspended.

                            </div>


                            <a
                                href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/enrolled_courses.php'
                                    )
                                ) ?>"
                                class="btn btn-outline-danger w-100"
                            >

                                <i class="fa-solid fa-circle-info me-1"></i>

                                View Enrollment

                            </a>



                        <?php elseif ($isEnrolled): ?>


                            <!-- Other Enrollment State -->

                            <div class="enrollment-info">

                                <i class="fa-solid fa-clock me-1"></i>

                                Your enrollment is being processed.

                            </div>


                            <a
                                href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/enrolled_courses.php'
                                    )
                                ) ?>"
                                class="btn btn-outline-primary w-100"
                            >

                                <i class="fa-solid fa-folder-open me-1"></i>

                                View Enrollment

                            </a>



                        <?php else: ?>


                            <!-- ==================================================
                                 NOT ENROLLED
                                 REGISTERED + LOGGED-IN STUDENT
                            =================================================== -->

                            <div class="enrollment-info">

                                <i class="fa-solid fa-user-check text-primary me-1"></i>

                                You are logged in.
                                You can enroll directly in this course.

                            </div>


                            <a
                                href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/checkout.php?course=' .
                                        (int) $course['id']
                                    )
                                ) ?>"
                                class="btn btn-primary w-100"
                            >

                                <i class="fa-solid fa-user-plus me-1"></i>

                                Enroll Now

                            </a>

                        <?php endif; ?>


                    </div>

                </div>


            <?php endforeach; ?>


        </div>

    </div>

</div>


<?php

include dirname(__DIR__) . '/partials/footer.php';

?>
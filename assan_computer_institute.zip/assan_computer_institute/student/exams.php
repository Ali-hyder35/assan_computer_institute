<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student - Available Exams
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];

$pageTitle = 'My Exams';

try {

    /*
    |--------------------------------------------------------------------------
    | Get Exams Available To Student
    |--------------------------------------------------------------------------
    | Student must have:
    | payment_status = paid
    | access_status  = active
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            e.id,
            e.course_id,
            e.title,
            e.description,
            e.duration_minutes,
            e.total_marks,
            e.pass_marks,
            e.attempts_allowed,
            e.active,

            c.title AS course_title,

            COUNT(DISTINCT eq.id) AS question_count,

            COUNT(
                DISTINCT CASE
                    WHEN ea.status IN ('submitted', 'expired')
                    THEN ea.id
                END
            ) AS attempts_used,

            MAX(ea.id) AS latest_attempt_id,

            MAX(
                CASE
                    WHEN ea.status IN ('submitted', 'expired')
                    THEN ea.percentage
                    ELSE NULL
                END
            ) AS latest_percentage,

            MAX(
                CASE
                    WHEN ea.status IN ('submitted', 'expired')
                    THEN ea.result
                    ELSE NULL
                END
            ) AS latest_result

        FROM exams e

        INNER JOIN courses c
            ON c.id = e.course_id

        INNER JOIN enrollments en
            ON en.course_id = e.course_id
            AND en.user_id = ?
            AND en.payment_status = 'paid'
            AND en.access_status = 'active'

        LEFT JOIN exam_questions eq
            ON eq.exam_id = e.id
            AND eq.active = 1

        LEFT JOIN exam_attempts ea
            ON ea.exam_id = e.id
            AND ea.user_id = ?

        WHERE e.active = 1

        GROUP BY
            e.id,
            e.course_id,
            e.title,
            e.description,
            e.duration_minutes,
            e.total_marks,
            e.pass_marks,
            e.attempts_allowed,
            e.active,
            c.title

        ORDER BY
            c.title ASC,
            e.id DESC
    ");

    $stmt->execute(array($userId, $userId));

    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {

    $exams = array();

    flash(
        'error',
        'Unable to load exams. Please try again.'
    );
}

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
:root {
    --lms-primary: #0f2a5f;
    --lms-primary-light: #1e4b8f;
    --lms-accent: #2563eb;
    --lms-accent-hover: #1d4ed8;
    --lms-bg: #f5f7fb;
    --lms-card: #ffffff;
    --lms-text: #1e293b;
    --lms-muted: #64748b;
    --lms-border: #e2e8f0;
    --lms-success: #16a34a;
    --lms-danger: #dc2626;
    --lms-warning: #d97706;
    --lms-shadow: 0 8px 25px rgba(15, 42, 95, 0.08);
}

body {
    background: var(--lms-bg);
}

.exam-page {
    padding: 30px 0 50px;
}

.exam-header {
    background: linear-gradient(
        135deg,
        var(--lms-primary),
        var(--lms-primary-light)
    );
    color: #fff;
    border-radius: 18px;
    padding: 30px;
    margin-bottom: 28px;
    box-shadow: var(--lms-shadow);
}

.exam-header h2 {
    margin: 0 0 8px;
    font-weight: 700;
}

.exam-header p {
    margin: 0;
    color: rgba(255,255,255,.82);
}

.exam-result-link {
    color: #fff;
    text-decoration: none;
    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.2);
    padding: 10px 18px;
    border-radius: 10px;
    display: inline-block;
    margin-top: 18px;
}

.exam-result-link:hover {
    background: rgba(255,255,255,.2);
    color: #fff;
}

.exam-card {
    background: #fff;
    border: 1px solid var(--lms-border);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 20px;
    box-shadow: var(--lms-shadow);
    height: 100%;
}

.course-label {
    color: var(--lms-accent);
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
    margin-bottom: 8px;
}

.exam-title {
    color: var(--lms-text);
    font-size: 21px;
    font-weight: 700;
    margin-bottom: 10px;
}

.exam-description {
    color: var(--lms-muted);
    min-height: 45px;
    margin-bottom: 20px;
}

.exam-meta {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;
}

.meta-box {
    background: #f8fafc;
    border: 1px solid var(--lms-border);
    border-radius: 10px;
    padding: 12px;
}

.meta-box small {
    display: block;
    color: var(--lms-muted);
    font-size: 12px;
}

.meta-box strong {
    color: var(--lms-text);
    font-size: 15px;
}

.exam-footer {
    border-top: 1px solid var(--lms-border);
    padding-top: 18px;
}

.btn-start {
    background: var(--lms-accent);
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 11px 18px;
    font-weight: 600;
    text-decoration: none;
    display: inline-block;
}

.btn-start:hover {
    background: var(--lms-accent-hover);
    color: #fff;
}

.btn-disabled {
    background: #e2e8f0;
    color: #64748b;
    border-radius: 10px;
    padding: 11px 18px;
    display: inline-block;
    font-weight: 600;
}

.badge-passed {
    background: #dcfce7;
    color: #166534;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.badge-failed {
    background: #fee2e2;
    color: #991b1b;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.badge-pending {
    background: #fef3c7;
    color: #92400e;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.empty-exams {
    background: #fff;
    border: 1px solid var(--lms-border);
    border-radius: 16px;
    padding: 55px 25px;
    text-align: center;
    box-shadow: var(--lms-shadow);
}

.empty-exams h4 {
    color: var(--lms-text);
    margin-bottom: 8px;
}

.empty-exams p {
    color: var(--lms-muted);
}
</style>

<div class="container exam-page">

    <div class="exam-header">

        <div class="d-flex flex-wrap justify-content-between align-items-start">

            <div>
                <h2>
                    <i class="bi bi-clipboard-check me-2"></i>
                    My Exams
                </h2>

                <p>
                    Take your course examinations and check your academic results.
                </p>
            </div>

            <div>
                <a
                    href="<?= e(base_url('assan_computer_institute/student/exam_results.php')) ?>"
                    class="exam-result-link"
                >
                    <i class="bi bi-bar-chart-line me-1"></i>
                    My Exam Results
                </a>
            </div>

        </div>

    </div>

    <?php
    $flashSuccess = flash('success');
    $flashError = flash('error');
    ?>

    <?php if ($flashSuccess): ?>
        <div class="alert alert-success">
            <?= e($flashSuccess) ?>
        </div>
    <?php endif; ?>

    <?php if ($flashError): ?>
        <div class="alert alert-danger">
            <?= e($flashError) ?>
        </div>
    <?php endif; ?>

    <?php if (empty($exams)): ?>

        <div class="empty-exams">

            <div style="font-size:50px;color:#2563eb;margin-bottom:15px;">
                <i class="bi bi-journal-check"></i>
            </div>

            <h4>No Exams Available</h4>

            <p>
                You currently do not have any active exams.
                Exams become available after you have active access to a course.
            </p>

            <a
                href="<?= e(base_url('assan_computer_institute/student/courses.php')) ?>"
                class="btn-start"
            >
                Browse Courses
            </a>

        </div>

    <?php else: ?>

        <div class="row">

            <?php foreach ($exams as $exam): ?>

                <?php
                $attemptsUsed = (int) $exam['attempts_used'];
                $attemptsAllowed = (int) $exam['attempts_allowed'];

                if ($attemptsAllowed <= 0) {
                    $canAttempt = true;
                } else {
                    $canAttempt = $attemptsUsed < $attemptsAllowed;
                }

                $latestResult = $exam['latest_result'];
                ?>

                <div class="col-lg-6 mb-4">

                    <div class="exam-card">

                        <div class="course-label">
                            <?= e($exam['course_title']) ?>
                        </div>

                        <div class="exam-title">
                            <?= e($exam['title']) ?>
                        </div>

                        <div class="exam-description">
                            <?= e($exam['description'] ? $exam['description'] : 'Course examination.') ?>
                        </div>

                        <div class="exam-meta">

                            <div class="meta-box">
                                <small>Questions</small>
                                <strong>
                                    <?= (int) $exam['question_count'] ?>
                                </strong>
                            </div>

                            <div class="meta-box">
                                <small>Duration</small>
                                <strong>
                                    <?= (int) $exam['duration_minutes'] ?> Minutes
                                </strong>
                            </div>

                            <div class="meta-box">
                                <small>Total Marks</small>
                                <strong>
                                    <?= e($exam['total_marks']) ?>
                                </strong>
                            </div>

                            <div class="meta-box">
                                <small>Pass Marks</small>
                                <strong>
                                    <?= e($exam['pass_marks']) ?>
                                </strong>
                            </div>

                        </div>

                        <div class="exam-footer">

                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">

                                <div>

                                    <?php if ($latestResult === 'passed'): ?>

                                        <span class="badge-passed">
                                            Passed
                                        </span>

                                    <?php elseif ($latestResult === 'failed'): ?>

                                        <span class="badge-failed">
                                            Failed
                                        </span>

                                    <?php elseif ($attemptsUsed > 0): ?>

                                        <span class="badge-pending">
                                            Attempted
                                        </span>

                                    <?php else: ?>

                                        <span class="badge-pending">
                                            Not Attempted
                                        </span>

                                    <?php endif; ?>

                                    <div class="small text-muted mt-2">
                                        Attempts:
                                        <?= $attemptsUsed ?>
                                        /
                                        <?= $attemptsAllowed > 0 ? $attemptsAllowed : 'Unlimited' ?>
                                    </div>

                                </div>

                                <div>

                                    <?php if ($canAttempt): ?>

                                        <a
                                            href="<?= e(base_url('assan_computer_institute/student/exam.php?id=' . (int) $exam['id'])) ?>"
                                            class="btn-start"
                                        >
                                            <i class="bi bi-play-circle me-1"></i>
                                            Start Exam
                                        </a>

                                    <?php else: ?>

                                        <?php if (!empty($exam['latest_attempt_id'])): ?>

                                            <a
                                                href="<?= e(base_url('assan_computer_institute/student/exam_result.php?id=' . (int) $exam['latest_attempt_id'])) ?>"
                                                class="btn-start"
                                            >
                                                View Result
                                            </a>

                                        <?php else: ?>

                                            <span class="btn-disabled">
                                                Attempts Completed
                                            </span>

                                        <?php endif; ?>

                                    <?php endif; ?>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
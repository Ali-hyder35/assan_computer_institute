
<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student Video Progress API
|--------------------------------------------------------------------------
*/

error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once dirname(__DIR__) . '/config/bootstrap.php';


/*
|--------------------------------------------------------------------------
| JSON Response Helper
|--------------------------------------------------------------------------
*/

function video_progress_response($success, $message, $extra = array(), $statusCode = 200)
{
    http_response_code($statusCode);

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }

    $response = array(
        'success' => (bool) $success,
        'message' => $message
    );

    if (!empty($extra) && is_array($extra)) {
        $response = array_merge($response, $extra);
    }

    echo json_encode($response);
    exit;
}


/*
|--------------------------------------------------------------------------
| Require Login
|--------------------------------------------------------------------------
*/

try {

    require_login();

} catch (Throwable $e) {

    video_progress_response(
        false,
        'Your session has expired. Please login again.',
        array(),
        401
    );
}


/*
|--------------------------------------------------------------------------
| Only POST Requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    video_progress_response(
        false,
        'Invalid request method.',
        array(),
        405
    );
}


/*
|--------------------------------------------------------------------------
| Check Database
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {

    video_progress_response(
        false,
        'Database connection is not available.',
        array(),
        500
    );
}


/*
|--------------------------------------------------------------------------
| Main Processing
|--------------------------------------------------------------------------
*/

try {

    /*
    |--------------------------------------------------------------------------
    | CSRF TOKEN
    |--------------------------------------------------------------------------
    |
    | Accept token from:
    |
    | 1. POST csrf_token
    | 2. POST _token
    | 3. HTTP header X-CSRF-TOKEN
    | 4. HTTP header X-CSRF-Token
    |
    */

    $csrfToken = '';

    if (isset($_POST['csrf_token'])) {
        $csrfToken = trim((string) $_POST['csrf_token']);
    }

    if ($csrfToken === '' && isset($_POST['_token'])) {
        $csrfToken = trim((string) $_POST['_token']);
    }

    if ($csrfToken === '' && isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
        $csrfToken = trim((string) $_SERVER['HTTP_X_CSRF_TOKEN']);
    }

    if ($csrfToken === '') {

        video_progress_response(
            false,
            'CSRF token is missing. Please refresh the page and try again.',
            array(),
            419
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Verify CSRF
    |--------------------------------------------------------------------------
    |
    | Put the token into POST so the existing verify_csrf()
    | helper can use it.
    |
    */

    $_POST['csrf_token'] = $csrfToken;

    verify_csrf();


    /*
    |--------------------------------------------------------------------------
    | Current User
    |--------------------------------------------------------------------------
    */

    $user = current_user();

    if (!$user || !isset($user['id'])) {

        video_progress_response(
            false,
            'Your session has expired. Please login again.',
            array(),
            401
        );
    }

    $userId = (int) $user['id'];


    /*
    |--------------------------------------------------------------------------
    | Request Values
    |--------------------------------------------------------------------------
    */

    $videoId = isset($_POST['video_id'])
        ? (int) $_POST['video_id']
        : 0;

    $courseId = isset($_POST['course_id'])
        ? (int) $_POST['course_id']
        : 0;

    $watchedSeconds = isset($_POST['watched_seconds'])
        ? (int) $_POST['watched_seconds']
        : 0;

    $completed = isset($_POST['completed'])
        ? (int) $_POST['completed']
        : 0;


    /*
    |--------------------------------------------------------------------------
    | Validate IDs
    |--------------------------------------------------------------------------
    */

    if ($videoId <= 0) {

        video_progress_response(
            false,
            'Invalid video ID.',
            array(),
            400
        );
    }

    if ($courseId <= 0) {

        video_progress_response(
            false,
            'Invalid course ID.',
            array(),
            400
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Validate Watched Seconds
    |--------------------------------------------------------------------------
    */

    if ($watchedSeconds < 0) {
        $watchedSeconds = 0;
    }


    /*
    |--------------------------------------------------------------------------
    | Validate Completed
    |--------------------------------------------------------------------------
    */

    $completed = ($completed === 1) ? 1 : 0;


    /*
    |--------------------------------------------------------------------------
    | Verify Active Enrollment
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT e.id
        FROM enrollments e
        WHERE e.user_id = ?
          AND e.course_id = ?
          AND e.payment_status = 'paid'
          AND e.access_status = 'active'
        LIMIT 1
    ");

    $stmt->execute(array(
        $userId,
        $courseId
    ));

    $enrollmentId = $stmt->fetchColumn();

    if (!$enrollmentId) {

        video_progress_response(
            false,
            'You do not have active access to this course.',
            array(),
            403
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Verify Course
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id
        FROM courses
        WHERE id = ?
          AND active = 1
        LIMIT 1
    ");

    $stmt->execute(array($courseId));

    if (!$stmt->fetchColumn()) {

        video_progress_response(
            false,
            'Course not found or inactive.',
            array(),
            404
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Verify Video
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id
        FROM course_videos
        WHERE id = ?
          AND course_id = ?
          AND active = 1
        LIMIT 1
    ");

    $stmt->execute(array(
        $videoId,
        $courseId
    ));

    if (!$stmt->fetchColumn()) {

        video_progress_response(
            false,
            'Lesson not found or inactive.',
            array(),
            404
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Find Existing Progress
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            watched_seconds,
            completed,
            completed_at
        FROM student_video_progress
        WHERE user_id = ?
          AND video_id = ?
        LIMIT 1
    ");

    $stmt->execute(array(
        $userId,
        $videoId
    ));

    $existing = $stmt->fetch(PDO::FETCH_ASSOC);


    /*
    |--------------------------------------------------------------------------
    | INSERT
    |--------------------------------------------------------------------------
    */

    if (!$existing) {

        $completedAt = null;

        if ($completed === 1) {
            $completedAt = date('Y-m-d H:i:s');
        }

        $stmt = $pdo->prepare("
            INSERT INTO student_video_progress
            (
                user_id,
                course_id,
                video_id,
                watched_seconds,
                completed,
                completed_at
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ");

        $stmt->execute(array(
            $userId,
            $courseId,
            $videoId,
            $watchedSeconds,
            $completed,
            $completedAt
        ));

    } else {

        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $progressId = (int) $existing['id'];

        $oldWatchedSeconds = (int) $existing['watched_seconds'];
        $oldCompleted = (int) $existing['completed'];
        $oldCompletedAt = $existing['completed_at'];

        /*
        | Never reduce watched time.
        */

        $finalWatchedSeconds = max(
            $oldWatchedSeconds,
            $watchedSeconds
        );

        /*
        | Once completed, keep completed.
        */

        $finalCompleted = max(
            $oldCompleted,
            $completed
        );

        /*
        | Keep existing completion date.
        */

        $finalCompletedAt = $oldCompletedAt;

        if (
            $finalCompleted === 1 &&
            empty($finalCompletedAt)
        ) {
            $finalCompletedAt = date('Y-m-d H:i:s');
        }

        $stmt = $pdo->prepare("
            UPDATE student_video_progress
            SET
                watched_seconds = ?,
                completed = ?,
                completed_at = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
              AND user_id = ?
              AND video_id = ?
        ");

        $stmt->execute(array(
            $finalWatchedSeconds,
            $finalCompleted,
            $finalCompletedAt,
            $progressId,
            $userId,
            $videoId
        ));
    }


    /*
    |--------------------------------------------------------------------------
    | Calculate Course Progress
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            COUNT(cv.id) AS total_lessons,
            COALESCE(
                SUM(
                    CASE
                        WHEN svp.completed = 1 THEN 1
                        ELSE 0
                    END
                ),
                0
            ) AS completed_lessons
        FROM course_videos cv
        LEFT JOIN student_video_progress svp
            ON svp.video_id = cv.id
           AND svp.user_id = ?
        WHERE cv.course_id = ?
          AND cv.active = 1
    ");

    $stmt->execute(array(
        $userId,
        $courseId
    ));

    $progress = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$progress) {

        video_progress_response(
            false,
            'Unable to calculate course progress.',
            array(),
            500
        );
    }


    $totalLessons = (int) $progress['total_lessons'];
    $completedLessons = (int) $progress['completed_lessons'];

    $courseProgress = 0;

    if ($totalLessons > 0) {

        $courseProgress = (int) round(
            ($completedLessons / $totalLessons) * 100
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Success
    |--------------------------------------------------------------------------
    */

    video_progress_response(
        true,
        $completed === 1
            ? 'Lesson completed.'
            : 'Progress saved.',
        array(
            'course_progress' => $courseProgress,
            'completed_lessons' => $completedLessons,
            'total_lessons' => $totalLessons,
            'video_id' => $videoId,
            'course_id' => $courseId
        ),
        200
    );


} catch (PDOException $e) {

    error_log(
        'Assan Computer Institute video_progress PDO error: '
        . $e->getMessage()
    );

    video_progress_response(
        false,
        'Database error while saving video progress.',
        array(),
        500
    );


} catch (Exception $e) {

    error_log(
        'Assan Computer Institute video_progress error: '
        . $e->getMessage()
    );

    /*
    |--------------------------------------------------------------------------
    | Important:
    | If verify_csrf() throws "Invalid CSRF token.",
    | return that message to the browser.
    |--------------------------------------------------------------------------
    */

    video_progress_response(
        false,
        $e->getMessage(),
        array(),
        400
    );


} catch (Throwable $e) {

    error_log(
        'Assan Computer Institute video_progress fatal error: '
        . $e->getMessage()
    );

    video_progress_response(
        false,
        'Unable to save video progress.',
        array(),
        500
    );
}

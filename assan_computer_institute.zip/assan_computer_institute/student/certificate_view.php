
<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];

$requestId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($requestId <= 0) {
    flash('error', 'Invalid certificate selected.');
    redirect(base_url(
        'assan_computer_institute/student/certificates.php'
    ));
}

$stmt = $pdo->prepare("
    SELECT
        cr.id,
        cr.certificate_number,
        cr.reviewed_at,
        cr.status,
        u.full_name,
        c.title AS course_title
    FROM certificate_requests cr
    INNER JOIN users u ON u.id = cr.user_id
    INNER JOIN courses c ON c.id = cr.course_id
    WHERE cr.id = ?
      AND cr.user_id = ?
      AND cr.status = 'approved'
    LIMIT 1
");
$stmt->execute(array($requestId, $userId));
$certificate = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$certificate) {
    flash(
        'error',
        'This certificate is not available or has not been approved.'
    );
    redirect(base_url(
        'assan_computer_institute/student/certificates.php'
    ));
}

$pageTitle = 'Course Certificate';

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
body { background: #f5f7fb; }

.certificate-wrap {
    max-width: 1050px;
    margin: 35px auto 55px;
    padding: 0 15px;
}

.certificate-paper {
    position: relative;
    background: #fff;
    border: 10px double #1e4b8f;
    outline: 1px solid #c5a45b;
    outline-offset: -19px;
    padding: 65px 45px;
    text-align: center;
    box-shadow: 0 12px 35px rgba(15,42,95,.12);
}

.certificate-brand {
    color: #0f2a5f;
    font-weight: 800;
    font-size: 30px;
    letter-spacing: 1px;
}

.certificate-heading {
    color: #1e4b8f;
    font-size: 38px;
    font-weight: 800;
    margin: 35px 0 15px;
    text-transform: uppercase;
}

.certificate-student {
    font-family: Georgia, serif;
    font-size: 34px;
    color: #0f2a5f;
    border-bottom: 1px solid #c5a45b;
    display: inline-block;
    padding: 0 20px 10px;
    margin: 12px 0;
}

.certificate-course {
    font-size: 26px;
    font-weight: 700;
    color: #1e4b8f;
    margin: 15px 0;
}

.certificate-number {
    font-size: 13px;
    color: #64748b;
    overflow-wrap: anywhere;
}

.certificate-date {
    color: #475569;
    margin-top: 30px;
}

@media (max-width: 600px) {
    .certificate-paper { padding: 45px 22px; }
    .certificate-heading { font-size: 27px; }
    .certificate-student { font-size: 25px; }
    .certificate-course { font-size: 21px; }
    .certificate-brand { font-size: 23px; }
}

@media print {
    body { background: white !important; }
    header, footer, nav, .no-print {
        display: none !important;
    }
    .certificate-wrap {
        max-width: none;
        margin: 0;
        padding: 0;
    }
    .certificate-paper {
        box-shadow: none;
        min-height: 90vh;
        break-inside: avoid;
    }
    @page {
        size: landscape;
        margin: 12mm;
    }
}
</style>

<div class="certificate-wrap">
    <div class="d-flex justify-content-between align-items-center
                flex-wrap gap-2 mb-3 no-print">
        <a class="btn btn-outline-primary"
           href="<?= e(base_url(
               'assan_computer_institute/student/certificates.php'
           )) ?>">
            Back to My Certificates
        </a>

        <button type="button" class="btn btn-primary"
                onclick="window.print()">
            Print / Save as PDF
        </button>
    </div>

    <div class="certificate-paper">
        <div class="certificate-brand">
            ASSAN COMPUTER INSTITUTE
        </div>

        <div class="text-muted mt-2">
            CERTIFICATE OF ACHIEVEMENT
        </div>

        <h1 class="certificate-heading">
            Certificate of Completion
        </h1>

        <p class="mt-4 mb-1">
            This certificate is proudly presented to
        </p>

        <div class="certificate-student">
            <?= e($certificate['full_name']) ?>
        </div>

        <p class="mt-4 mb-2">
            for successfully completing the course
        </p>

        <div class="certificate-course">
            <?= e($certificate['course_title']) ?>
        </div>

        <p class="mt-3">
            and meeting the institute's course completion
            and examination requirements.
        </p>

        <div class="certificate-date">
            <strong>Issue date:</strong>
            <?= e(date(
                'd F Y',
                strtotime($certificate['reviewed_at'])
            )) ?>
        </div>

        <div class="certificate-number mt-4">
            Certificate Number:
            <?= e($certificate['certificate_number']) ?>
        </div>

        <div class="mt-5 fw-semibold">
            Assan Computer Institute
        </div>

        <div class="text-muted small">
            Practical computer education and professional skills
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>

<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

$error = '';
$selectedRole = 'student';

/*
|--------------------------------------------------------------------------
| Role-Based Login
|--------------------------------------------------------------------------
| Student -> Student Dashboard
| Admin   -> Admin Dashboard
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $email = trim(
        isset($_POST['email'])
            ? $_POST['email']
            : ''
    );

    $password = isset($_POST['password'])
        ? $_POST['password']
        : '';

    $selectedRole = isset($_POST['role'])
        ? strtolower(trim($_POST['role']))
        : 'student';


    /*
    |--------------------------------------------------------------------------
    | Validate Selected Role
    |--------------------------------------------------------------------------
    */

    if (!in_array($selectedRole, array('student', 'admin'), true)) {

        $error = 'Please select a valid login role.';

    } elseif ($email === '' || $password === '') {

        $error = 'Please enter your email and password.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | Authenticate User
        |--------------------------------------------------------------------------
        */

        $loggedIn = login_user(
            $pdo,
            $email,
            $password
        );


        if ($loggedIn) {

            $u = current_user();


            /*
            |--------------------------------------------------------------------------
            | Check Actual Database Role
            |--------------------------------------------------------------------------
            */

            $actualRole = isset($u['role'])
                ? strtolower(trim($u['role']))
                : '';


            /*
            |--------------------------------------------------------------------------
            | Prevent Role Mismatch
            |--------------------------------------------------------------------------
            |
            | Example:
            | User selects Admin but account is Student
            | => Login rejected.
            |
            */

            if ($actualRole !== $selectedRole) {

                /*
                | Logout the authenticated session because
                | selected role does not match account role.
                */

                if (function_exists('logout_user')) {
                    logout_user();
                } elseif (function_exists('logout')) {
                    logout();
                } else {
                    /*
                    | Fallback session cleanup.
                    */
                    $_SESSION = array();

                    if (ini_get('session.use_cookies')) {

                        $params = session_get_cookie_params();

                        setcookie(
                            session_name(),
                            '',
                            time() - 42000,
                            $params['path'],
                            $params['domain'],
                            $params['secure'],
                            $params['httponly']
                        );
                    }

                    session_destroy();
                }

                $error = 'The selected role does not match your account. Please select the correct role.';

            } else {

                /*
                |--------------------------------------------------------------------------
                | Role-Based Redirect
                |--------------------------------------------------------------------------
                */

                if ($actualRole === 'admin') {

                    redirect(
                        base_url('assan_computer_institute/admin/dashboard.php')
                    );

                } else {

                    redirect(
                        base_url('assan_computer_institute/student/dashboard.php')
                    );
                }

                exit;
            }

        } else {

            $error = 'Invalid email/password or your account is blocked.';
        }
    }
}


$pageTitle = 'Login';

include dirname(__DIR__) . '/partials/header.php';

?>

<div class="auth-wrap">

    <div class="container">

        <div class="auth-card">

            <!-- =====================================================
                 HEADER
            ====================================================== -->

            <div class="text-center mb-4">

                <div class="icon-box mx-auto mb-3">

                    <i class="bi bi-box-arrow-in-right"></i>

                </div>

                <h2 class="section-title">
                    Login
                </h2>

                <p class="text-secondary">
                    Login to access your Assan Computer Institute account.
                </p>

            </div>


            <!-- =====================================================
                 ERROR MESSAGE
            ====================================================== -->

            <?php if ($error): ?>

                <div
                    class="alert alert-danger"
                    role="alert"
                >

                    <i class="bi bi-exclamation-triangle me-2"></i>

                    <?= e($error) ?>

                </div>

            <?php endif; ?>


            <!-- =====================================================
                 LOGIN FORM
            ====================================================== -->

            <form
                method="post"
                action=""
                autocomplete="on"
            >

                <?= csrf_field() ?>


                <!-- =================================================
                     ROLE
                ================================================== -->

                <div class="mb-3">

                    <label
                        for="role"
                        class="form-label fw-semibold"
                    >
                        Login As
                    </label>

                    <select
                        class="form-select"
                        id="role"
                        name="role"
                        required
                    >

                        <option
                            value="student"
                            <?= $selectedRole === 'student' ? 'selected' : '' ?>
                        >
                            Student
                        </option>

                        <option
                            value="admin"
                            <?= $selectedRole === 'admin' ? 'selected' : '' ?>
                        >
                            Admin
                        </option>

                    </select>

                </div>


                <!-- =================================================
                     EMAIL
                ================================================== -->

                <div class="mb-3">

                    <label
                        for="email"
                        class="form-label fw-semibold"
                    >
                        Email
                    </label>

                    <input
                        class="form-control"
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        autocomplete="email"
                        required
                    >

                </div>


                <!-- =================================================
                     PASSWORD
                ================================================== -->

                <div class="mb-4">

                    <label
                        for="password"
                        class="form-label fw-semibold"
                    >
                        Password
                    </label>

                    <input
                        class="form-control"
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                        required
                    >

                </div>


                <!-- =================================================
                     LOGIN BUTTON
                ================================================== -->

                <button
                    type="submit"
                    class="btn btn-primary w-100 py-2"
                >

                    <i class="bi bi-box-arrow-in-right me-2"></i>

                    Login

                </button>

            </form>


            <!-- =====================================================
                 STUDENT REGISTRATION
            ====================================================== -->

            <p class="text-center mt-4 mb-0 text-secondary">

                New student?

                <a
                    href="<?= e(base_url('assan_computer_institute/student/register.php')) ?>"
                    class="fw-semibold"
                >
                    Create account
                </a>

            </p>
            <p class="text-center mt-4 mb-0 text-secondary">

                Back?

                <a
                    href="<?= e(base_url('assan_computer_institute/index.php')) ?>"
                    class="fw-semibold"
                >
                    Home Page
                </a>

            </p>

            <!-- =====================================================
                 ROLE INFORMATION
            ====================================================== -->

            <div class="mt-4">

                <div class="alert alert-light border mb-0">

                    <div class="small text-secondary">

                        <div class="mb-2">

                            <i class="bi bi-person me-2"></i>

                            <strong>Student:</strong>

                            Access your courses,
                            enrollment and student dashboard.

                        </div>

                        <div>

                            <i class="bi bi-shield-lock me-2"></i>

                            <strong>Admin:</strong>

                            Access administration,
                            courses, students and payments.

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<?php

include dirname(__DIR__) . '/partials/footer.php';

?>


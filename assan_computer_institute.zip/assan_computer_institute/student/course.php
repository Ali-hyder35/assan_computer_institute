<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student Course / Video Learning Page
|--------------------------------------------------------------------------
|
| YouTube-compatible LMS learning page.
|
| Database video_url examples:
|
| https://youtu.be/B4bgsPLZbzE?si=xxxx
| https://youtu.be/0yVDMcGp97g?si=xxxx
|
| These are automatically converted to:
|
| https://www.youtube.com/embed/VIDEO_ID
|
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();

$userId = (int) $user['id'];

$pageTitle = 'Course Learning';


/*
|--------------------------------------------------------------------------
| Course ID
|--------------------------------------------------------------------------
*/

$courseId = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

$selectedVideoId = isset($_GET['video'])
    ? (int) $_GET['video']
    : 0;


if ($courseId <= 0) {

    redirect(
        base_url('assan_computer_institute/student/courses.php')
    );
}


/*
|--------------------------------------------------------------------------
| Load Course
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        id,
        title,
        slug,
        description,
        price,
        duration,
        active
    FROM courses
    WHERE id = ?
      AND active = 1
    LIMIT 1
");

$stmt->execute(array($courseId));

$course = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$course) {

    flash(
        'error',
        'Course not found or inactive.'
    );

    redirect(
        base_url('assan_computer_institute/student/courses.php')
    );
}


/*
|--------------------------------------------------------------------------
| Verify Active Enrollment
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        e.id,
        e.payment_status,
        e.access_status
    FROM enrollments e
    WHERE e.user_id = ?
      AND e.course_id = ?
      AND e.payment_status = 'paid'
      AND e.access_status = 'active'
    ORDER BY e.id DESC
    LIMIT 1
");

$stmt->execute(array(
    $userId,
    $courseId
));

$enrollment = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$enrollment) {

    flash(
        'error',
        'You do not have active access to this course.'
    );

    redirect(
        base_url(
            'assan_computer_institute/student/enrolled_courses.php'
        )
    );
}


/*
|--------------------------------------------------------------------------
| Load Course Videos
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        id,
        course_id,
        title,
        description,
        video_url,
        lesson_no,
        duration,
        active
    FROM course_videos
    WHERE course_id = ?
      AND active = 1
    ORDER BY lesson_no ASC, id ASC
");

$stmt->execute(array($courseId));

$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Load Student Progress
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        video_id,
        watched_seconds,
        completed,
        completed_at
    FROM student_video_progress
    WHERE user_id = ?
      AND course_id = ?
");

$stmt->execute(array(
    $userId,
    $courseId
));

$progressRows = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Build Progress Array
|--------------------------------------------------------------------------
*/

$videoProgress = array();

foreach ($progressRows as $row) {

    $videoProgress[(int) $row['video_id']] = array(
        'watched_seconds' => (int) $row['watched_seconds'],
        'completed'       => (int) $row['completed'],
        'completed_at'    => $row['completed_at']
    );
}


/*
|--------------------------------------------------------------------------
| Select Video
|--------------------------------------------------------------------------
*/

$currentVideo = null;


/*
|--------------------------------------------------------------------------
| First Preference: Requested Video
|--------------------------------------------------------------------------
*/

if ($selectedVideoId > 0) {

    foreach ($videos as $video) {

        if ((int) $video['id'] === $selectedVideoId) {

            $currentVideo = $video;

            break;
        }
    }
}


/*
|--------------------------------------------------------------------------
| Second Preference: First Incomplete Video
|--------------------------------------------------------------------------
*/

if (!$currentVideo) {

    foreach ($videos as $video) {

        $videoId = (int) $video['id'];

        $isCompleted = isset($videoProgress[$videoId])
            ? (int) $videoProgress[$videoId]['completed']
            : 0;

        if ($isCompleted !== 1) {

            $currentVideo = $video;

            break;
        }
    }
}


/*
|--------------------------------------------------------------------------
| Third Preference: First Video
|--------------------------------------------------------------------------
*/

if (!$currentVideo && !empty($videos)) {

    $currentVideo = $videos[0];
}


/*
|--------------------------------------------------------------------------
| Calculate Course Progress
|--------------------------------------------------------------------------
*/

$totalLessons = count($videos);

$completedLessons = 0;

foreach ($videos as $video) {

    $videoId = (int) $video['id'];

    if (
        isset($videoProgress[$videoId]) &&
        (int) $videoProgress[$videoId]['completed'] === 1
    ) {

        $completedLessons++;
    }
}

$courseProgress = 0;

if ($totalLessons > 0) {

    $courseProgress = (int) round(
        ($completedLessons / $totalLessons) * 100
    );
}


/*
|--------------------------------------------------------------------------
| Current Video Data
|--------------------------------------------------------------------------
*/

$currentVideoId = 0;

$currentWatchedSeconds = 0;

$currentCompleted = 0;

$currentCompletedAt = null;

if ($currentVideo) {

    $currentVideoId = (int) $currentVideo['id'];

    if (isset($videoProgress[$currentVideoId])) {

        $currentWatchedSeconds =
            (int) $videoProgress[$currentVideoId]['watched_seconds'];

        $currentCompleted =
            (int) $videoProgress[$currentVideoId]['completed'];

        $currentCompletedAt =
            $videoProgress[$currentVideoId]['completed_at'];
    }
}


/*
|--------------------------------------------------------------------------
| Convert YouTube URL To Video ID
|--------------------------------------------------------------------------
*/

$youtubeVideoId = '';

if ($currentVideo) {

    $youtubeUrl = trim(
        (string) $currentVideo['video_url']
    );

    /*
    | Handles:
    |
    | https://youtu.be/VIDEO_ID
    | https://youtu.be/VIDEO_ID?si=xxxx
    | https://www.youtube.com/watch?v=VIDEO_ID
    | https://www.youtube.com/embed/VIDEO_ID
    | https://www.youtube.com/shorts/VIDEO_ID
    |
    */

    if (
        preg_match(
            '~(?:youtu\.be/|youtube\.com/(?:watch\?v=|embed/|shorts/))([A-Za-z0-9_-]{11})~i',
            $youtubeUrl,
            $matches
        )
    ) {

        $youtubeVideoId = $matches[1];

    } elseif (
        preg_match(
            '~^[A-Za-z0-9_-]{11}$~',
            $youtubeUrl
        )
    ) {

        $youtubeVideoId = $youtubeUrl;
    }
}


/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/partials/header.php';

?>

<style>

:root {
    --lms-primary: #0f2a5f;
    --lms-primary-light: #1e4b8f;
    --lms-accent: #2563eb;
    --lms-accent-hover: #1d4ed8;
    --lms-bg: #f5f7fb;
    --lms-card: #ffffff;
    --lms-text: #1e293b;
    --lms-muted: #64748b;
    --lms-border: #e2e8f0;
    --lms-success: #16a34a;
    --lms-danger: #dc2626;
    --lms-shadow: 0 8px 25px rgba(15, 42, 95, 0.08);
}

body {
    background: var(--lms-bg);
}

.course-learning-page {
    padding: 30px 0 50px;
}

.course-header {
    background: linear-gradient(
        135deg,
        var(--lms-primary),
        var(--lms-primary-light)
    );
    color: #fff;
    border-radius: 16px;
    padding: 28px;
    margin-bottom: 24px;
    box-shadow: var(--lms-shadow);
}

.course-header h1 {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 8px;
}

.course-header p {
    margin: 0;
    opacity: .9;
}

.learning-grid {
    display: grid;
    grid-template-columns: 320px minmax(0, 1fr);
    gap: 24px;
}

.lesson-sidebar,
.lesson-content {
    background: var(--lms-card);
    border: 1px solid var(--lms-border);
    border-radius: 16px;
    box-shadow: var(--lms-shadow);
}

.lesson-sidebar {
    overflow: hidden;
}

.sidebar-header {
    padding: 20px;
    border-bottom: 1px solid var(--lms-border);
}

.sidebar-header h3 {
    margin: 0 0 12px;
    font-size: 18px;
    color: var(--lms-text);
}

.progress-wrapper {
    margin-top: 10px;
}

.progress {
    height: 9px;
    border-radius: 20px;
    background: #e8edf5;
    overflow: hidden;
}

.progress-bar {
    background: var(--lms-accent);
    transition: width .3s ease;
}

.progress-label {
    margin-top: 7px;
    font-size: 13px;
    color: var(--lms-muted);
}

.lesson-list {
    padding: 10px;
}

.lesson-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 13px 14px;
    margin-bottom: 6px;
    border-radius: 10px;
    text-decoration: none;
    color: var(--lms-text);
    transition: .2s ease;
}

.lesson-item:hover {
    background: #f1f5f9;
    color: var(--lms-primary);
}

.lesson-item.active {
    background: #eaf1ff;
    color: var(--lms-primary);
    font-weight: 600;
}

.lesson-number {
    min-width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #eef2f7;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 600;
}

.lesson-item.active .lesson-number {
    background: var(--lms-accent);
    color: #fff;
}

.lesson-item.completed .lesson-number {
    background: var(--lms-success);
    color: #fff;
}

.lesson-info {
    flex: 1;
    min-width: 0;
}

.lesson-title {
    font-size: 14px;
    line-height: 1.35;
}

.lesson-status {
    font-size: 12px;
    margin-top: 3px;
    color: var(--lms-muted);
}

.lesson-complete-icon {
    color: var(--lms-success);
    font-size: 16px;
}

.lesson-content {
    padding: 24px;
}

.lesson-heading {
    margin-bottom: 20px;
}

.lesson-heading h2 {
    margin: 0 0 7px;
    color: var(--lms-text);
    font-size: 24px;
}

.lesson-heading p {
    margin: 0;
    color: var(--lms-muted);
}

.video-container {
    position: relative;
    width: 100%;
    background: #0b1220;
    border-radius: 14px;
    overflow: hidden;
    margin-bottom: 20px;
    aspect-ratio: 16 / 9;
    min-height: 420px;
}

.youtube-player {
    width: 100%;
    height: 100%;
    min-height: 420px;
    border: 0;
    display: block;
}

.video-error {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 420px;
    padding: 30px;
    text-align: center;
    color: #fff;
    background: #111827;
}

.video-error-box {
    max-width: 600px;
}

.video-error-box h4 {
    margin-bottom: 10px;
}

.video-error-box p {
    margin: 0;
    color: #cbd5e1;
    line-height: 1.6;
}

.video-status {
    padding: 14px 16px;
    border-radius: 10px;
    background: #f8fafc;
    border: 1px solid var(--lms-border);
    margin-bottom: 18px;
}

.video-status strong {
    color: var(--lms-text);
}

.video-status-value {
    color: var(--lms-muted);
}

.complete-button {
    min-width: 190px;
    border-radius: 9px;
    padding: 11px 20px;
    font-weight: 600;
}

.complete-button:disabled {
    cursor: not-allowed;
    opacity: .55;
}

.completed-message {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    color: var(--lms-success);
    font-weight: 600;
}

.lesson-description {
    margin-top: 25px;
    padding-top: 22px;
    border-top: 1px solid var(--lms-border);
    color: var(--lms-text);
    line-height: 1.7;
}

.empty-lessons {
    padding: 50px 20px;
    text-align: center;
    color: var(--lms-muted);
}

.youtube-help {
    margin-top: 10px;
    font-size: 12px;
    color: var(--lms-muted);
}

@media (max-width: 991px) {

    .learning-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 768px) {

    .video-container,
    .youtube-player,
    .video-error {
        min-height: 300px;
    }

}

@media (max-width: 576px) {

    .course-learning-page {
        padding: 18px 0 35px;
    }

    .course-header {
        padding: 22px;
    }

    .course-header h1 {
        font-size: 23px;
    }

    .lesson-content {
        padding: 16px;
    }

    .lesson-heading h2 {
        font-size: 20px;
    }

    .video-container,
    .youtube-player,
    .video-error {
        min-height: 230px;
    }

}

</style>


<div class="container course-learning-page">

    <!-- ==============================================================
         COURSE HEADER
         ============================================================== -->

    <div class="course-header">

        <h1>
            <?= e($course['title']) ?>
        </h1>

        <p>

            <?php if (!empty($course['duration'])): ?>

                <?= e($course['duration']) ?>

            <?php else: ?>

                Online Learning Course

            <?php endif; ?>

        </p>

    </div>


    <?php if (empty($videos)): ?>

        <div class="lesson-sidebar empty-lessons">

            <h4>
                No lessons available
            </h4>

            <p>
                Lessons for this course have not been added yet.
            </p>

        </div>

    <?php else: ?>

        <div class="learning-grid">

            <!-- ======================================================
                 LEFT: LESSON SIDEBAR
                 ====================================================== -->

            <aside class="lesson-sidebar">

                <div class="sidebar-header">

                    <h3>
                        Course Lessons
                    </h3>

                    <div class="progress-wrapper">

                        <div class="progress">

                            <div
                                id="courseProgressBar"
                                class="progress-bar"
                                role="progressbar"
                                style="width: <?= $courseProgress ?>%;"
                                aria-valuenow="<?= $courseProgress ?>"
                                aria-valuemin="0"
                                aria-valuemax="100"
                            ></div>

                        </div>

                        <div
                            id="courseProgressText"
                            class="progress-label"
                        >

                            <?= $courseProgress ?>%
                            Complete —
                            <?= $completedLessons ?>/<?= $totalLessons ?>
                            lessons

                        </div>

                    </div>

                </div>


                <div class="lesson-list">

                    <?php foreach ($videos as $index => $video): ?>

                        <?php

                        $videoId = (int) $video['id'];

                        $isCompleted =
                            isset($videoProgress[$videoId]) &&
                            (int) $videoProgress[$videoId]['completed'] === 1;

                        $isActive =
                            $currentVideoId === $videoId;

                        ?>

                        <a
                            href="<?= e(
                                base_url(
                                    'assan_computer_institute/student/course.php?id='
                                    . $courseId
                                    . '&video='
                                    . $videoId
                                )
                            ) ?>"
                            class="lesson-item
                                <?= $isActive ? 'active' : '' ?>
                                <?= $isCompleted ? 'completed' : '' ?>"
                        >

                            <div class="lesson-number">

                                <?php if ($isCompleted): ?>

                                    ✓

                                <?php else: ?>

                                    <?= (int) $index + 1 ?>

                                <?php endif; ?>

                            </div>


                            <div class="lesson-info">

                                <div class="lesson-title">

                                    <?= e($video['title']) ?>

                                </div>

                                <div class="lesson-status">

                                    <?php if ($isCompleted): ?>

                                        Completed

                                    <?php elseif (
                                        isset($videoProgress[$videoId]) &&
                                        (int) $videoProgress[$videoId]['watched_seconds'] > 0
                                    ): ?>

                                        In progress

                                    <?php else: ?>

                                        Not started

                                    <?php endif; ?>

                                </div>

                            </div>


                            <?php if ($isCompleted): ?>

                                <div class="lesson-complete-icon">
                                    ✓
                                </div>

                            <?php endif; ?>

                        </a>

                    <?php endforeach; ?>

                </div>

            </aside>


            <!-- ======================================================
                 RIGHT: VIDEO CONTENT
                 ====================================================== -->

            <main class="lesson-content">

                <?php if ($currentVideo): ?>

                    <div class="lesson-heading">

                        <h2>
                            <?= e($currentVideo['title']) ?>
                        </h2>

                        <?php if (!empty($currentVideo['duration'])): ?>

                            <p>
                                Duration:
                                <?= e($currentVideo['duration']) ?>
                            </p>

                        <?php endif; ?>

                    </div>


                    <!-- ==================================================
                         CSRF TOKEN
                         ================================================== -->

                    <div
                        id="csrfContainer"
                        style="display:none;"
                    >

                        <?= csrf_field() ?>

                    </div>


                    <!-- ==================================================
                         YOUTUBE PLAYER
                         ================================================== -->

                    <?php if ($youtubeVideoId !== ''): ?>

                        <div class="video-container">

                            <div
                                id="youtubePlayer"
                                class="youtube-player"
                            ></div>

                        </div>

                    <?php else: ?>

                        <div class="video-container">

                            <div class="video-error">

                                <div class="video-error-box">

                                    <h4>
                                        Video URL Error
                                    </h4>

                                    <p>
                                        This lesson does not contain a
                                        valid YouTube video URL.
                                        Please contact the administrator.
                                    </p>

                                </div>

                            </div>

                        </div>

                    <?php endif; ?>


                    <!-- ==================================================
                         VIDEO STATUS
                         ================================================== -->

                    <div class="video-status">

                        <strong>
                            Lesson status:
                        </strong>

                        <span
                            id="videoStatusText"
                            class="video-status-value"
                        >

                            <?php if ($currentCompleted === 1): ?>

                                Completed

                            <?php elseif ($currentWatchedSeconds > 0): ?>

                                In progress

                            <?php else: ?>

                                Not started

                            <?php endif; ?>

                        </span>

                    </div>


                    <!-- ==================================================
                         COMPLETE BUTTON
                         ================================================== -->

                    <div>

                        <?php if ($currentCompleted === 1): ?>

                            <div
                                id="completedMessage"
                                class="completed-message"
                            >

                                ✓ Lesson completed

                            </div>

                        <?php else: ?>

                            <button
                                type="button"
                                id="markCompleteBtn"
                                class="btn btn-success complete-button"
                                disabled
                            >
                                Mark as Complete
                            </button>

                            <div
                                id="completeHint"
                                class="text-muted mt-2"
                                style="font-size:13px;"
                            >
                                Start the video first. You must watch
                                at least 1 second before marking this
                                lesson complete.
                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- ==================================================
                         DESCRIPTION
                         ================================================== -->

                    <?php if (!empty($currentVideo['description'])): ?>

                        <div class="lesson-description">

                            <?= nl2br(
                                e($currentVideo['description'])
                            ) ?>

                        </div>

                    <?php endif; ?>


                <?php endif; ?>

            </main>

        </div>

    <?php endif; ?>

</div>


<?php if ($currentVideo && $youtubeVideoId !== ''): ?>

<!-- ==============================================================
     YOUTUBE IFRAME API
     ============================================================== -->

<script src="https://www.youtube.com/iframe_api"></script>


<script>

(function () {

    'use strict';


    /*
    |--------------------------------------------------------------------------
    | Current Course / Video
    |--------------------------------------------------------------------------
    */

    var courseId =
        <?= (int) $courseId ?>;

    var videoId =
        <?= (int) $currentVideoId ?>;


    /*
    |--------------------------------------------------------------------------
    | Saved Progress From Database
    |--------------------------------------------------------------------------
    */

    var savedWatchedSeconds =
        <?= (int) $currentWatchedSeconds ?>;


    /*
    |--------------------------------------------------------------------------
    | Existing Completion
    |--------------------------------------------------------------------------
    */

    var alreadyCompleted =
        <?= $currentCompleted === 1 ? 'true' : 'false' ?>;


    /*
    |--------------------------------------------------------------------------
    | YouTube Video ID
    |--------------------------------------------------------------------------
    */

    var youtubeVideoId =
        <?= json_encode($youtubeVideoId) ?>;


    /*
    |--------------------------------------------------------------------------
    | Player
    |--------------------------------------------------------------------------
    */

    var player = null;


    /*
    |--------------------------------------------------------------------------
    | Playback State
    |--------------------------------------------------------------------------
    */

    var hasActuallyPlayed = false;

    var isCurrentlyPlaying = false;

    var videoReady = false;


    /*
    |--------------------------------------------------------------------------
    | Watch Time
    |--------------------------------------------------------------------------
    */

    var currentWatchedSeconds =
        savedWatchedSeconds;


    /*
    |--------------------------------------------------------------------------
    | Minimum Watch Requirement
    |--------------------------------------------------------------------------
    */

    var minimumWatchSeconds = 1;


    /*
    |--------------------------------------------------------------------------
    | Request Protection
    |--------------------------------------------------------------------------
    */

    var savingProgress = false;

    var completingLesson = false;


    /*
    |--------------------------------------------------------------------------
    | DOM Elements
    |--------------------------------------------------------------------------
    */

    var completeButton =
        document.getElementById(
            'markCompleteBtn'
        );

    var videoStatusText =
        document.getElementById(
            'videoStatusText'
        );

    var completeHint =
        document.getElementById(
            'completeHint'
        );


    /*
    |--------------------------------------------------------------------------
    | Get CSRF Token
    |--------------------------------------------------------------------------
    |
    | We support both:
    |
    | csrf_token
    | _token
    |
    | This keeps this page compatible with the existing bootstrap helper.
    |
    */

    function getCsrfTokenData() {

        var input =
            document.querySelector(
                '#csrfContainer input[name="csrf_token"]'
            );

        if (input) {

            return {
                name: 'csrf_token',
                value: input.value || ''
            };
        }


        input =
            document.querySelector(
                '#csrfContainer input[name="_token"]'
            );

        if (input) {

            return {
                name: '_token',
                value: input.value || ''
            };
        }


        /*
        |--------------------------------------------------------------
        | Fallback: any hidden CSRF input
        |--------------------------------------------------------------
        */

        input =
            document.querySelector(
                '#csrfContainer input[type="hidden"]'
            );

        if (input) {

            return {
                name: input.name || 'csrf_token',
                value: input.value || ''
            };
        }


        return {
            name: 'csrf_token',
            value: ''
        };
    }


    /*
    |--------------------------------------------------------------------------
    | Update Status
    |--------------------------------------------------------------------------
    */

    function setStatus(text) {

        if (videoStatusText) {

            videoStatusText.textContent = text;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Update Complete Button
    |--------------------------------------------------------------------------
    */

    function updateCompleteButton() {

        if (!completeButton) {
            return;
        }


        if (alreadyCompleted) {

            completeButton.disabled = true;

            completeButton.textContent =
                'Lesson Completed';

            return;
        }


        if (
            hasActuallyPlayed &&
            currentWatchedSeconds >= minimumWatchSeconds
        ) {

            completeButton.disabled = false;

            completeButton.textContent =
                'Mark as Complete';

            if (completeHint) {

                completeHint.textContent =
                    'You can now mark this lesson as complete.';
            }

        } else {

            completeButton.disabled = true;

            completeButton.textContent =
                'Mark as Complete';

            if (completeHint) {

                completeHint.textContent =
                    'Start the video first. You must watch at least 1 second before marking this lesson complete.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Save Progress
    |--------------------------------------------------------------------------
    */

    function saveProgress(completed) {

        /*
        |--------------------------------------------------------------
        | Never allow completion unless the video actually played.
        |--------------------------------------------------------------
        */

        if (
            completed &&
            (
                !hasActuallyPlayed ||
                currentWatchedSeconds < minimumWatchSeconds
            )
        ) {

            return Promise.reject(
                new Error(
                    'Please play the video for at least 1 second first.'
                )
            );
        }


        var csrf =
            getCsrfTokenData();


        if (!csrf.value) {

            return Promise.reject(
                new Error(
                    'CSRF token is missing. Please refresh the page.'
                )
            );
        }


        var formData =
            new FormData();


        /*
        |--------------------------------------------------------------
        | Send the actual CSRF field name.
        |--------------------------------------------------------------
        */

        formData.append(
            csrf.name,
            csrf.value
        );


        /*
        |--------------------------------------------------------------
        | Also send csrf_token as compatibility fallback.
        |--------------------------------------------------------------
        */

        if (csrf.name !== 'csrf_token') {

            formData.append(
                'csrf_token',
                csrf.value
            );
        }


        /*
        |--------------------------------------------------------------
        | Course / Video
        |--------------------------------------------------------------
        */

        formData.append(
            'video_id',
            String(videoId)
        );

        formData.append(
            'course_id',
            String(courseId)
        );


        /*
        |--------------------------------------------------------------
        | Watched Seconds
        |--------------------------------------------------------------
        */

        formData.append(
            'watched_seconds',
            String(
                Math.max(
                    0,
                    Math.floor(
                        currentWatchedSeconds
                    )
                )
            )
        );


        /*
        |--------------------------------------------------------------
        | Completion
        |--------------------------------------------------------------
        */

        formData.append(
            'completed',
            completed ? '1' : '0'
        );


        return fetch(
            '<?= e(
                base_url(
                    'assan_computer_institute/student/video_progress.php'
                )
            ) ?>',
            {
                method: 'POST',

                body: formData,

                credentials: 'same-origin',

                headers: {
                    'X-Requested-With':
                        'XMLHttpRequest'
                }
            }
        )
        .then(function (response) {

            return response.text().then(
                function (text) {

                    var data;

                    try {

                        data =
                            JSON.parse(text);

                    } catch (error) {

                        console.error(
                            'Invalid server response:',
                            text
                        );

                        throw new Error(
                            'Invalid server response from video_progress.php.'
                        );
                    }


                    if (!response.ok) {

                        throw new Error(
                            data.message ||
                            'Unable to save video progress.'
                        );
                    }


                    if (!data.success) {

                        throw new Error(
                            data.message ||
                            'Unable to save video progress.'
                        );
                    }


                    return data;
                }
            );

        });
    }


    /*
    |--------------------------------------------------------------------------
    | Update Course Progress
    |--------------------------------------------------------------------------
    */

    function updateCourseProgress(data) {

        if (!data) {
            return;
        }


        var progress =
            parseInt(
                data.course_progress || 0,
                10
            );


        var completedLessons =
            parseInt(
                data.completed_lessons || 0,
                10
            );


        var totalLessons =
            parseInt(
                data.total_lessons || 0,
                10
            );


        var progressBar =
            document.getElementById(
                'courseProgressBar'
            );


        var progressText =
            document.getElementById(
                'courseProgressText'
            );


        if (progressBar) {

            progressBar.style.width =
                progress + '%';

            progressBar.setAttribute(
                'aria-valuenow',
                String(progress)
            );
        }


        if (progressText) {

            progressText.textContent =
                progress +
                '% Complete — ' +
                completedLessons +
                '/' +
                totalLessons +
                ' lessons';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | YouTube API Ready
    |--------------------------------------------------------------------------
    */

    window.onYouTubeIframeAPIReady =
        function () {

            createYouTubePlayer();

        };


    /*
    |--------------------------------------------------------------------------
    | Create YouTube Player
    |--------------------------------------------------------------------------
    */

    function createYouTubePlayer() {

        if (
            typeof YT === 'undefined' ||
            typeof YT.Player === 'undefined'
        ) {

            console.error(
                'YouTube IFrame API is not available.'
            );

            setStatus(
                'Unable to load YouTube player.'
            );

            return;
        }


        player =
            new YT.Player(
                'youtubePlayer',
                {
                    videoId:
                        youtubeVideoId,

                    playerVars: {
                        autoplay: 0,
                        controls: 1,
                        rel: 0,
                        modestbranding: 1,
                        playsinline: 1
                    },

                    events: {

                        onReady:
                            onPlayerReady,

                        onStateChange:
                            onPlayerStateChange,

                        onError:
                            onPlayerError
                    }
                }
            );
    }


    /*
    |--------------------------------------------------------------------------
    | Player Ready
    |--------------------------------------------------------------------------
    */

    function onPlayerReady(event) {

        videoReady = true;


        /*
        |--------------------------------------------------------------
        | Resume from previously saved position.
        |--------------------------------------------------------------
        |
        | Seeking does NOT count as watching.
        |
        */

        if (
            savedWatchedSeconds > 0 &&
            !alreadyCompleted
        ) {

            try {

                event.target.seekTo(
                    savedWatchedSeconds,
                    true
                );

            } catch (error) {

                console.warn(
                    'Unable to restore saved position.',
                    error
                );
            }
        }


        if (alreadyCompleted) {

            setStatus(
                'Completed'
            );

        } else if (
            savedWatchedSeconds > 0
        ) {

            setStatus(
                'In progress'
            );

        } else {

            setStatus(
                'Not started'
            );
        }


        updateCompleteButton();
    }


    /*
    |--------------------------------------------------------------------------
    | YouTube Player State Change
    |--------------------------------------------------------------------------
    */

    function onPlayerStateChange(event) {

        /*
        |--------------------------------------------------------------
        | PLAYING
        |--------------------------------------------------------------
        */

        if (
            event.data === YT.PlayerState.PLAYING
        ) {

            hasActuallyPlayed = true;

            isCurrentlyPlaying = true;

            setStatus(
                'Video is playing...'
            );

            updateCompleteButton();

            return;
        }


        /*
        |--------------------------------------------------------------
        | PAUSED
        |--------------------------------------------------------------
        */

        if (
            event.data === YT.PlayerState.PAUSED
        ) {

            isCurrentlyPlaying = false;


            /*
            | Save the latest position when paused.
            */

            updateCurrentWatchedTime();


            if (
                hasActuallyPlayed &&
                currentWatchedSeconds > 0
            ) {

                setStatus(
                    'Paused'
                );

                saveCurrentProgress();

            } else {

                setStatus(
                    'Not started'
                );
            }

            return;
        }


        /*
        |--------------------------------------------------------------
        | ENDED
        |--------------------------------------------------------------
        */

        if (
            event.data === YT.PlayerState.ENDED
        ) {

            isCurrentlyPlaying = false;

            hasActuallyPlayed = true;


            /*
            | Get the final video duration.
            */

            try {

                var duration =
                    Math.floor(
                        player.getDuration() || 0
                    );

                if (
                    duration >
                    currentWatchedSeconds
                ) {

                    currentWatchedSeconds =
                        duration;
                }

            } catch (error) {

                console.warn(
                    'Unable to get YouTube duration.',
                    error
                );
            }


            setStatus(
                'Video finished. You can mark this lesson complete.'
            );


            updateCompleteButton();


            /*
            | IMPORTANT:
            |
            | Ending the video does NOT automatically complete
            | the lesson.
            |
            */

            saveCurrentProgress();

            return;
        }


        /*
        |--------------------------------------------------------------
        | BUFFERING
        |--------------------------------------------------------------
        */

        if (
            event.data === YT.PlayerState.BUFFERING
        ) {

            isCurrentlyPlaying = false;

            setStatus(
                'Buffering...'
            );

            return;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | YouTube Error
    |--------------------------------------------------------------------------
    */

    function onPlayerError(event) {

        var message =
            'Unable to play this YouTube video.';

        /*
        |--------------------------------------------------------------
        | Common YouTube error codes:
        |
        | 2   = Invalid parameter
        | 5   = HTML5 player error
        | 100 = Video not found/private
        | 101 = Embedding not allowed
        | 150 = Embedding not allowed
        |--------------------------------------------------------------
        */

        if (
            event &&
            event.data
        ) {

            if (event.data === 2) {

                message =
                    'Invalid YouTube video URL.';

            } else if (event.data === 5) {

                message =
                    'YouTube HTML5 player error.';

            } else if (
                event.data === 100
            ) {

                message =
                    'This YouTube video was removed or is private.';

            } else if (
                event.data === 101 ||
                event.data === 150
            ) {

                message =
                    'This YouTube video does not allow embedding.';
            }
        }


        setStatus(
            'Video unavailable'
        );


        var container =
            document.querySelector(
                '.video-container'
            );


        if (container) {

            container.innerHTML =
                '<div class="video-error">' +
                    '<div class="video-error-box">' +
                        '<h4>Video Cannot Be Played</h4>' +
                        '<p>' +
                            message +
                            '<br><br>' +
                            'Please contact the administrator if the problem continues.' +
                        '</p>' +
                    '</div>' +
                '</div>';
        }


        console.error(
            'YouTube Player Error:',
            event ? event.data : ''
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Get Current YouTube Time
    |--------------------------------------------------------------------------
    */

    function updateCurrentWatchedTime() {

        if (
            !player ||
            !videoReady
        ) {

            return;
        }


        try {

            var currentTime =
                Math.floor(
                    player.getCurrentTime() || 0
                );


            /*
            | Never reduce saved progress.
            */

            if (
                currentTime >
                currentWatchedSeconds
            ) {

                currentWatchedSeconds =
                    currentTime;
            }

        } catch (error) {

            console.warn(
                'Unable to read YouTube current time.',
                error
            );
        }


        updateCompleteButton();
    }


    /*
    |--------------------------------------------------------------------------
    | Save Current Progress
    |--------------------------------------------------------------------------
    */

    function saveCurrentProgress() {

        if (
            !hasActuallyPlayed ||
            currentWatchedSeconds <= 0 ||
            savingProgress ||
            alreadyCompleted
        ) {

            return;
        }


        savingProgress = true;


        saveProgress(false)

            .then(function (data) {

                updateCourseProgress(
                    data
                );

            })

            .catch(function (error) {

                console.error(
                    'Progress save error:',
                    error.message
                );

            })

            .finally(function () {

                savingProgress = false;

            });
    }


    /*
    |--------------------------------------------------------------------------
    | Watch-Time Polling
    |--------------------------------------------------------------------------
    |
    | YouTube does not provide a normal HTML5 "timeupdate" event.
    |
    | Therefore we check the YouTube player every second while
    | the student is genuinely playing.
    |
    */

    var lastSavedSecond = 0;


    setInterval(
        function () {

            if (
                !player ||
                !videoReady ||
                !isCurrentlyPlaying ||
                alreadyCompleted
            ) {

                return;
            }


            updateCurrentWatchedTime();


            /*
            |----------------------------------------------------------
            | Enable completion after actual playback.
            |----------------------------------------------------------
            */

            if (
                hasActuallyPlayed &&
                currentWatchedSeconds >=
                minimumWatchSeconds
            ) {

                setStatus(
                    'In progress'
                );

                updateCompleteButton();
            }


            /*
            |----------------------------------------------------------
            | Save every 5 seconds.
            |----------------------------------------------------------
            */

            if (
                currentWatchedSeconds >=
                lastSavedSecond + 5
            ) {

                lastSavedSecond =
                    currentWatchedSeconds;

                saveCurrentProgress();
            }

        },
        1000
    );


    /*
    |--------------------------------------------------------------------------
    | Mark As Complete
    |--------------------------------------------------------------------------
    */

    if (completeButton) {

        completeButton.addEventListener(
            'click',
            function () {

                /*
                |------------------------------------------------------
                | Get latest player position before completion.
                |------------------------------------------------------
                */

                updateCurrentWatchedTime();


                /*
                |------------------------------------------------------
                | Absolute protection.
                |------------------------------------------------------
                */

                if (
                    !hasActuallyPlayed ||
                    currentWatchedSeconds <
                    minimumWatchSeconds
                ) {

                    alert(
                        'Please play the video for at least 1 second before marking this lesson complete.'
                    );

                    updateCompleteButton();

                    return;
                }


                if (completingLesson) {

                    return;
                }


                completingLesson = true;

                completeButton.disabled = true;

                completeButton.textContent =
                    'Saving...';


                saveProgress(true)

                    .then(function (data) {

                        /*
                        |----------------------------------------------
                        | Mark locally completed.
                        |----------------------------------------------
                        */

                        alreadyCompleted = true;


                        /*
                        |----------------------------------------------
                        | Update course progress.
                        |----------------------------------------------
                        */

                        updateCourseProgress(
                            data
                        );


                        /*
                        |----------------------------------------------
                        | Update status.
                        |----------------------------------------------
                        */

                        setStatus(
                            'Completed'
                        );


                        /*
                        |----------------------------------------------
                        | Hide button.
                        |----------------------------------------------
                        */

                        completeButton.style.display =
                            'none';


                        if (completeHint) {

                            completeHint.style.display =
                                'none';
                        }


                        /*
                        |----------------------------------------------
                        | Show completion message.
                        |----------------------------------------------
                        */

                        var existingMessage =
                            document.getElementById(
                                'completedMessage'
                            );


                        if (!existingMessage) {

                            var message =
                                document.createElement(
                                    'div'
                                );

                            message.id =
                                'completedMessage';

                            message.className =
                                'completed-message';

                            message.innerHTML =
                                '✓ Lesson completed';


                            completeButton
                                .parentNode
                                .appendChild(
                                    message
                                );
                        }


                        /*
                        |----------------------------------------------
                        | Reload so sidebar checkmark appears.
                        |----------------------------------------------
                        */

                        setTimeout(
                            function () {

                                window.location.reload();

                            },
                            700
                        );

                    })

                    .catch(function (error) {

                        console.error(
                            'Completion error:',
                            error.message
                        );


                        alert(
                            error.message ||
                            'Unable to mark lesson complete.'
                        );


                        completeButton.disabled =
                            false;

                        completeButton.textContent =
                            'Mark as Complete';


                        updateCompleteButton();

                    })

                    .finally(function () {

                        completingLesson =
                            false;

                    });

            }
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Initial Button State
    |--------------------------------------------------------------------------
    |
    | IMPORTANT:
    |
    | Saved watch time does NOT automatically count as "played" in
    | the current browser session.
    |
    | The student must press Play.
    |
    */

    updateCompleteButton();


})();

</script>

<?php endif; ?>


<?php

/*
|--------------------------------------------------------------------------
| Footer
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/partials/footer.php';

?>

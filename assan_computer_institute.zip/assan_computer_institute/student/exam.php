<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student - Take Exam
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];

$pageTitle = 'Take Exam';

$examId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($examId <= 0) {
    flash('error', 'Invalid exam selected.');
    redirect(
        base_url('assan_computer_institute/student/exams.php')
    );
}

/*
|--------------------------------------------------------------------------
| Load Exam
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        e.*,
        c.title AS course_title
    FROM exams e
    INNER JOIN courses c
        ON c.id = e.course_id
    WHERE e.id = ?
      AND e.active = 1
    LIMIT 1
");

$stmt->execute(array($examId));

$exam = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$exam) {

    flash('error', 'Exam not found or is no longer active.');

    redirect(
        base_url('assan_computer_institute/student/exams.php')
    );
}

$courseId = (int) $exam['course_id'];

/*
|--------------------------------------------------------------------------
| Verify Active Enrollment
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id
    FROM enrollments
    WHERE user_id = ?
      AND course_id = ?
      AND payment_status = 'paid'
      AND access_status = 'active'
    ORDER BY id DESC
    LIMIT 1
");

$stmt->execute(array($userId, $courseId));

$enrollment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$enrollment) {

    flash(
        'error',
        'You do not have active access to this course.'
    );

    redirect(
        base_url('assan_computer_institute/student/exams.php')
    );
}

/*
|--------------------------------------------------------------------------
| Load Questions
|--------------------------------------------------------------------------
|
| Correct answers are deliberately NOT selected here.
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        id,
        question_text,
        option_a,
        option_b,
        option_c,
        option_d,
        marks,
        question_order
    FROM exam_questions
    WHERE exam_id = ?
      AND active = 1
    ORDER BY question_order ASC, id ASC
");

$stmt->execute(array($examId));

$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($questions)) {

    flash(
        'error',
        'This exam does not contain any questions yet.'
    );

    redirect(
        base_url('assan_computer_institute/student/exams.php')
    );
}

/*
|--------------------------------------------------------------------------
| Calculate Actual Total Marks From Questions
|--------------------------------------------------------------------------
*/

$calculatedTotalMarks = 0;

foreach ($questions as $question) {
    $calculatedTotalMarks += (float) $question['marks'];
}

if ($calculatedTotalMarks <= 0) {
    $calculatedTotalMarks = (float) $exam['total_marks'];
}

/*
|--------------------------------------------------------------------------
| Find Existing In-Progress Attempt
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM exam_attempts
    WHERE exam_id = ?
      AND user_id = ?
      AND status = 'in_progress'
    ORDER BY id DESC
    LIMIT 1
");

$stmt->execute(array($examId, $userId));

$attempt = $stmt->fetch(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Create New Attempt If Necessary
|--------------------------------------------------------------------------
*/

if (!$attempt) {

    /*
    |--------------------------------------------------------------------------
    | Check Attempt Limit
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM exam_attempts
        WHERE exam_id = ?
          AND user_id = ?
          AND status IN ('submitted', 'expired')
    ");

    $stmt->execute(array($examId, $userId));

    $attemptsUsed = (int) $stmt->fetchColumn();

    $attemptsAllowed = (int) $exam['attempts_allowed'];

    if (
        $attemptsAllowed > 0 &&
        $attemptsUsed >= $attemptsAllowed
    ) {

        flash(
            'error',
            'You have used all allowed attempts for this exam.'
        );

        redirect(
            base_url('assan_computer_institute/student/exams.php')
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Create Attempt
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        INSERT INTO exam_attempts
        (
            exam_id,
            user_id,
            started_at,
            total_marks,
            status,
            result
        )
        VALUES
        (
            ?,
            ?,
            NOW(),
            ?,
            'in_progress',
            'pending'
        )
    ");

    $stmt->execute(array(
        $examId,
        $userId,
        $calculatedTotalMarks
    ));

    $attemptId = (int) $pdo->lastInsertId();

    $stmt = $pdo->prepare("
        SELECT *
        FROM exam_attempts
        WHERE id = ?
          AND user_id = ?
        LIMIT 1
    ");

    $stmt->execute(array($attemptId, $userId));

    $attempt = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$attempt) {

        flash(
            'error',
            'Unable to start the exam.'
        );

        redirect(
            base_url('assan_computer_institute/student/exams.php')
        );
    }
}

/*
|--------------------------------------------------------------------------
| Calculate Server-Side Expiry
|--------------------------------------------------------------------------
*/

$startedTimestamp = strtotime($attempt['started_at']);

$durationSeconds =
    ((int) $exam['duration_minutes']) * 60;

$expiryTimestamp =
    $startedTimestamp + $durationSeconds;

$currentTimestamp = time();

/*
|--------------------------------------------------------------------------
| If Existing Attempt Has Already Expired
|--------------------------------------------------------------------------
*/

if (
    $currentTimestamp >= $expiryTimestamp &&
    $attempt['status'] === 'in_progress'
) {

    $stmt = $pdo->prepare("
        UPDATE exam_attempts
        SET
            status = 'expired',
            submitted_at = NOW(),
            result = 'failed'
        WHERE id = ?
          AND user_id = ?
          AND status = 'in_progress'
    ");

    $stmt->execute(array(
        (int) $attempt['id'],
        $userId
    ));

    flash(
        'error',
        'Your exam time has expired.'
    );

    redirect(
        base_url(
            'assan_computer_institute/student/exam_result.php?id=' .
            (int) $attempt['id']
        )
    );
}

/*
|--------------------------------------------------------------------------
| Submit Exam
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $attemptId = (int) $attempt['id'];

        /*
        |--------------------------------------------------------------------------
        | Reload Attempt From Database
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM exam_attempts
            WHERE id = ?
              AND exam_id = ?
              AND user_id = ?
            LIMIT 1
        ");

        $stmt->execute(array(
            $attemptId,
            $examId,
            $userId
        ));

        $currentAttempt = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$currentAttempt) {
            throw new Exception('Invalid exam attempt.');
        }

        if ($currentAttempt['status'] !== 'in_progress') {
            throw new Exception('This exam attempt has already been submitted.');
        }

        /*
        |--------------------------------------------------------------------------
        | Server-Side Timer Check
        |--------------------------------------------------------------------------
        */

        $serverStarted = strtotime($currentAttempt['started_at']);

        $serverExpiry =
            $serverStarted +
            ((int) $exam['duration_minutes'] * 60);

        $now = time();

        $isExpired = ($now >= $serverExpiry);

        /*
        |--------------------------------------------------------------------------
        | Get Submitted Answers
        |--------------------------------------------------------------------------
        */

        $submittedAnswers = array();

        if (
            isset($_POST['answers']) &&
            is_array($_POST['answers'])
        ) {
            $submittedAnswers = $_POST['answers'];
        }

        /*
        |--------------------------------------------------------------------------
        | Get Correct Answers From Database
        |--------------------------------------------------------------------------
        */

        $questionIds = array();

        foreach ($questions as $question) {
            $questionIds[] = (int) $question['id'];
        }

        $placeholders = implode(
            ',',
            array_fill(0, count($questionIds), '?')
        );

        $stmt = $pdo->prepare("
            SELECT
                id,
                correct_option,
                marks
            FROM exam_questions
            WHERE exam_id = ?
              AND active = 1
              AND id IN ($placeholders)
        ");

        $params = array($examId);

        foreach ($questionIds as $questionId) {
            $params[] = $questionId;
        }

        $stmt->execute($params);

        $correctQuestions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        /*
        |--------------------------------------------------------------------------
        | Start Transaction
        |--------------------------------------------------------------------------
        */

        $pdo->beginTransaction();

        /*
        |--------------------------------------------------------------------------
        | Remove Previous Answers If Any
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            DELETE FROM exam_answers
            WHERE attempt_id = ?
        ");

        $stmt->execute(array($attemptId));

        $score = 0;

        foreach ($correctQuestions as $question) {

            $questionId = (int) $question['id'];

            $selected = null;

            if (
                isset($submittedAnswers[$questionId]) &&
                is_string($submittedAnswers[$questionId])
            ) {

                $selected = strtoupper(
                    trim($submittedAnswers[$questionId])
                );

                if (
                    !in_array(
                        $selected,
                        array('A', 'B', 'C', 'D'),
                        true
                    )
                ) {
                    $selected = null;
                }
            }

            $correctOption =
                strtoupper($question['correct_option']);

            $marks =
                (float) $question['marks'];

            $isCorrect =
                (
                    $selected !== null &&
                    $selected === $correctOption
                );

            $marksObtained =
                $isCorrect ? $marks : 0;

            if ($isCorrect) {
                $score += $marks;
            }

            $stmt = $pdo->prepare("
                INSERT INTO exam_answers
                (
                    attempt_id,
                    question_id,
                    selected_option,
                    is_correct,
                    marks_obtained
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?
                )
            ");

            $stmt->execute(array(
                $attemptId,
                $questionId,
                $selected,
                $isCorrect ? 1 : 0,
                $marksObtained
            ));
        }

        /*
        |--------------------------------------------------------------------------
        | Calculate Result
        |--------------------------------------------------------------------------
        */

        $totalMarks = $calculatedTotalMarks;

        if ($totalMarks <= 0) {
            $totalMarks = 1;
        }

        $percentage =
            ($score / $totalMarks) * 100;

        $passMarks =
            (float) $exam['pass_marks'];

        $result =
            ($score >= $passMarks)
                ? 'passed'
                : 'failed';

        /*
        |--------------------------------------------------------------------------
        | Expired Attempt
        |--------------------------------------------------------------------------
        */

        $status =
            $isExpired
                ? 'expired'
                : 'submitted';

        /*
        |--------------------------------------------------------------------------
        | Update Attempt
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            UPDATE exam_attempts
            SET
                submitted_at = NOW(),
                score = ?,
                total_marks = ?,
                percentage = ?,
                status = ?,
                result = ?,
                updated_at = NOW()
            WHERE id = ?
              AND user_id = ?
        ");

        $stmt->execute(array(
            $score,
            $totalMarks,
            $percentage,
            $status,
            $result,
            $attemptId,
            $userId
        ));

        $pdo->commit();

        redirect(
            base_url(
                'assan_computer_institute/student/exam_result.php?id=' .
                $attemptId
            )
        );

    } catch (Exception $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        flash(
            'error',
            $e->getMessage()
        );

        redirect(
            base_url(
                'assan_computer_institute/student/exam.php?id=' .
                $examId
            )
        );
    }
}

/*
|--------------------------------------------------------------------------
| Load Existing Answers For Resume
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        question_id,
        selected_option
    FROM exam_answers
    WHERE attempt_id = ?
");

$stmt->execute(array((int) $attempt['id']));

$existingAnswers = array();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    $existingAnswers[
        (int) $row['question_id']
    ] = $row['selected_option'];
}

$pageTitle = $exam['title'];

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
:root {
    --lms-primary: #0f2a5f;
    --lms-primary-light: #1e4b8f;
    --lms-accent: #2563eb;
    --lms-accent-hover: #1d4ed8;
    --lms-bg: #f5f7fb;
    --lms-card: #ffffff;
    --lms-text: #1e293b;
    --lms-muted: #64748b;
    --lms-border: #e2e8f0;
    --lms-success: #16a34a;
    --lms-danger: #dc2626;
    --lms-shadow: 0 8px 25px rgba(15,42,95,.08);
}

body {
    background: var(--lms-bg);
}

.exam-wrapper {
    padding: 30px 0 60px;
}

.exam-topbar {
    background: linear-gradient(
        135deg,
        var(--lms-primary),
        var(--lms-primary-light)
    );
    color: #fff;
    border-radius: 18px;
    padding: 24px 28px;
    margin-bottom: 25px;
    box-shadow: var(--lms-shadow);
}

.exam-topbar h2 {
    margin: 0 0 5px;
    font-size: 24px;
    font-weight: 700;
}

.exam-topbar p {
    margin: 0;
    color: rgba(255,255,255,.8);
}

.timer-box {
    background: #fff;
    color: var(--lms-primary);
    padding: 12px 18px;
    border-radius: 12px;
    min-width: 145px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,.1);
}

.timer-box small {
    display: block;
    color: var(--lms-muted);
    font-size: 11px;
    text-transform: uppercase;
    font-weight: 700;
}

.timer-value {
    font-size: 23px;
    font-weight: 800;
}

.timer-danger {
    color: var(--lms-danger);
}

.question-card {
    background: #fff;
    border: 1px solid var(--lms-border);
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: var(--lms-shadow);
}

.question-number {
    width: 38px;
    height: 38px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #eff6ff;
    color: var(--lms-accent);
    border-radius: 10px;
    font-weight: 800;
    margin-right: 10px;
}

.question-text {
    color: var(--lms-text);
    font-size: 17px;
    font-weight: 700;
    line-height: 1.6;
    margin-bottom: 20px;
}

.option-label {
    display: block;
    border: 1px solid var(--lms-border);
    border-radius: 12px;
    padding: 14px 16px;
    margin-bottom: 10px;
    cursor: pointer;
    transition: .2s ease;
    background: #fff;
}

.option-label:hover {
    border-color: var(--lms-accent);
    background: #f8fbff;
}

.option-label input {
    margin-right: 10px;
}

.option-label.selected {
    border-color: var(--lms-accent);
    background: #eff6ff;
}

.exam-sidebar {
    position: sticky;
    top: 20px;
}

.sidebar-card {
    background: #fff;
    border: 1px solid var(--lms-border);
    border-radius: 16px;
    padding: 20px;
    box-shadow: var(--lms-shadow);
    margin-bottom: 20px;
}

.sidebar-card h5 {
    color: var(--lms-text);
    font-weight: 700;
    margin-bottom: 15px;
}

.progress-box {
    height: 9px;
    background: #e2e8f0;
    border-radius: 20px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    width: 0;
    background: var(--lms-accent);
    transition: .2s;
}

.question-map {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 7px;
}

.question-map span {
    height: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f1f5f9;
    color: var(--lms-muted);
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
}

.submit-btn {
    width: 100%;
    background: var(--lms-accent);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 14px;
    font-weight: 700;
    font-size: 16px;
}

.submit-btn:hover {
    background: var(--lms-accent-hover);
}

.warning-box {
    background: #fff7ed;
    border: 1px solid #fed7aa;
    color: #9a3412;
    border-radius: 12px;
    padding: 13px;
    font-size: 13px;
    line-height: 1.5;
}
</style>

<div class="container exam-wrapper">

    <div class="exam-topbar">

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">

            <div>
                <h2>
                    <?= e($exam['title']) ?>
                </h2>

                <p>
                    <?= e($exam['course_title']) ?>
                    &nbsp;•&nbsp;
                    <?= count($questions) ?> Questions
                </p>
            </div>

            <div class="timer-box">

                <small>Time Remaining</small>

                <div
                    id="examTimer"
                    class="timer-value"
                >
                    --:--
                </div>

            </div>

        </div>

    </div>

    <form
        method="post"
        id="examForm"
        action="<?= e(base_url('assan_computer_institute/student/exam.php?id=' . $examId)) ?>"
    >

        <?= csrf_field() ?>

        <div class="row">

            <div class="col-lg-8">

                <?php foreach ($questions as $index => $question): ?>

                    <?php
                    $questionId = (int) $question['id'];

                    $savedAnswer =
                        isset($existingAnswers[$questionId])
                            ? $existingAnswers[$questionId]
                            : '';
                    ?>

                    <div
                        class="question-card"
                        id="question-<?= $questionId ?>"
                    >

                        <div class="question-text">

                            <span class="question-number">
                                <?= $index + 1 ?>
                            </span>

                            <?= nl2br(e($question['question_text'])) ?>

                        </div>

                        <label class="option-label">

                            <input
                                type="radio"
                                name="answers[<?= $questionId ?>]"
                                value="A"
                                <?= $savedAnswer === 'A' ? 'checked' : '' ?>
                            >

                            <strong>A.</strong>
                            <?= e($question['option_a']) ?>

                        </label>

                        <label class="option-label">

                            <input
                                type="radio"
                                name="answers[<?= $questionId ?>]"
                                value="B"
                                <?= $savedAnswer === 'B' ? 'checked' : '' ?>
                            >

                            <strong>B.</strong>
                            <?= e($question['option_b']) ?>

                        </label>

                        <?php if (!empty($question['option_c'])): ?>

                            <label class="option-label">

                                <input
                                    type="radio"
                                    name="answers[<?= $questionId ?>]"
                                    value="C"
                                    <?= $savedAnswer === 'C' ? 'checked' : '' ?>
                                >

                                <strong>C.</strong>
                                <?= e($question['option_c']) ?>

                            </label>

                        <?php endif; ?>

                        <?php if (!empty($question['option_d'])): ?>

                            <label class="option-label">

                                <input
                                    type="radio"
                                    name="answers[<?= $questionId ?>]"
                                    value="D"
                                    <?= $savedAnswer === 'D' ? 'checked' : '' ?>
                                >

                                <strong>D.</strong>
                                <?= e($question['option_d']) ?>

                            </label>

                        <?php endif; ?>

                        <div class="text-end mt-3">

                            <small class="text-muted">
                                Marks:
                                <?= e($question['marks']) ?>
                            </small>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

            <div class="col-lg-4">

                <div class="exam-sidebar">

                    <div class="sidebar-card">

                        <h5>
                            <i class="bi bi-info-circle me-1"></i>
                            Exam Information
                        </h5>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Questions</span>
                            <strong><?= count($questions) ?></strong>
                        </div>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Total Marks</span>
                            <strong><?= e($calculatedTotalMarks) ?></strong>
                        </div>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Pass Marks</span>
                            <strong><?= e($exam['pass_marks']) ?></strong>
                        </div>

                        <div class="d-flex justify-content-between">
                            <span class="text-muted">Duration</span>
                            <strong><?= (int) $exam['duration_minutes'] ?> min</strong>
                        </div>

                    </div>

                    <div class="sidebar-card">

                        <h5>Exam Progress</h5>

                        <div class="d-flex justify-content-between mb-2">

                            <small class="text-muted">
                                Answered
                            </small>

                            <strong id="answeredCount">
                                0 / <?= count($questions) ?>
                            </strong>

                        </div>

                        <div class="progress-box">
                            <div
                                id="progressFill"
                                class="progress-fill"
                            ></div>
                        </div>

                    </div>

                    <div class="sidebar-card">

                        <h5>Question Navigator</h5>

                        <div class="question-map">

                            <?php foreach ($questions as $index => $question): ?>

                                <span
                                    data-question="<?= (int) $question['id'] ?>"
                                    style="cursor:pointer;"
                                >
                                    <?= $index + 1 ?>
                                </span>

                            <?php endforeach; ?>

                        </div>

                    </div>

                    <div class="sidebar-card">

                        <div class="warning-box mb-3">

                            <strong>
                                Important:
                            </strong>

                            The exam timer is controlled by the server.
                            When time expires, your attempt will be submitted automatically.

                        </div>

                        <button
                            type="submit"
                            class="submit-btn"
                            id="submitExam"
                        >
                            <i class="bi bi-check-circle me-1"></i>
                            Submit Exam
                        </button>

                    </div>

                </div>

            </div>

        </div>

    </form>

</div>

<script>
(function () {

    var expiryTimestamp = <?= (int) $expiryTimestamp ?> * 1000;
    var timerElement = document.getElementById('examTimer');
    var examForm = document.getElementById('examForm');
    var submitted = false;

    function updateTimer() {

        var now = new Date().getTime();
        var remaining = expiryTimestamp - now;

        if (remaining <= 0) {

            timerElement.textContent = '00:00';
            timerElement.classList.add('timer-danger');

            if (!submitted) {
                submitted = true;
                examForm.submit();
            }

            return;
        }

        var totalSeconds =
            Math.floor(remaining / 1000);

        var minutes =
            Math.floor(totalSeconds / 60);

        var seconds =
            totalSeconds % 60;

        timerElement.textContent =
            String(minutes).padStart(2, '0') +
            ':' +
            String(seconds).padStart(2, '0');

        if (totalSeconds <= 60) {
            timerElement.classList.add('timer-danger');
        }
    }

    updateTimer();

    setInterval(updateTimer, 1000);

    /*
    |--------------------------------------------------------------------------
    | Answer Tracking
    |--------------------------------------------------------------------------
    */

    var radios =
        document.querySelectorAll(
            '#examForm input[type="radio"]'
        );

    function updateProgress() {

        var answered = {};

        radios.forEach(function (radio) {

            if (radio.checked) {
                answered[radio.name] = true;
            }

        });

        var count =
            Object.keys(answered).length;

        var total =
            <?= count($questions) ?>;

        var percentage =
            total > 0
                ? (count / total) * 100
                : 0;

        document.getElementById(
            'answeredCount'
        ).textContent =
            count + ' / ' + total;

        document.getElementById(
            'progressFill'
        ).style.width =
            percentage + '%';

        document.querySelectorAll(
            '.question-map span'
        ).forEach(function (item) {

            var questionId =
                item.getAttribute('data-question');

            var radio =
                document.querySelector(
                    'input[name="answers[' +
                    questionId +
                    ']"]:checked'
                );

            if (radio) {
                item.style.background = '#2563eb';
                item.style.color = '#fff';
            } else {
                item.style.background = '#f1f5f9';
                item.style.color = '#64748b';
            }

        });
    }

    radios.forEach(function (radio) {

        radio.addEventListener(
            'change',
            updateProgress
        );

    });

    document.querySelectorAll(
        '.question-map span'
    ).forEach(function (item) {

        item.addEventListener(
            'click',
            function () {

                var id =
                    this.getAttribute(
                        'data-question'
                    );

                var target =
                    document.getElementById(
                        'question-' + id
                    );

                if (target) {

                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });

                }

            }
        );

    });

    updateProgress();

    /*
    |--------------------------------------------------------------------------
    | Confirmation Before Submit
    |--------------------------------------------------------------------------
    */

    examForm.addEventListener(
        'submit',
        function (event) {

            if (submitted) {
                return;
            }

            var confirmed =
                confirm(
                    'Are you sure you want to submit your exam?'
                );

            if (!confirmed) {
                event.preventDefault();
            } else {
                submitted = true;
            }

        }
    );

})();
</script>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
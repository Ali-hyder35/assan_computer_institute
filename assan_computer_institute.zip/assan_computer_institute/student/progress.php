<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();

$userId = (int) $user['id'];

$pageTitle = 'Learning Progress';


$stmt = $pdo->prepare("
    SELECT
        e.course_id,
        c.title,
        c.duration,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            WHERE cv.course_id = c.id
              AND cv.active = 1
        ) AS total_lessons,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            INNER JOIN student_video_progress svp
                ON svp.video_id = cv.id
               AND svp.user_id = e.user_id
            WHERE cv.course_id = c.id
              AND cv.active = 1
              AND svp.completed = 1
        ) AS completed_lessons,

        (
            SELECT COALESCE(SUM(svp.watched_seconds), 0)
            FROM course_videos cv
            INNER JOIN student_video_progress svp
                ON svp.video_id = cv.id
               AND svp.user_id = e.user_id
            WHERE cv.course_id = c.id
              AND cv.active = 1
        ) AS watched_seconds

    FROM enrollments e

    INNER JOIN courses c
        ON c.id = e.course_id

    WHERE e.user_id = ?
      AND e.payment_status = 'paid'
      AND e.access_status = 'active'

    ORDER BY c.title ASC
");

$stmt->execute(array($userId));

$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);


$totalCourses = count($courses);

$totalLessons = 0;
$totalCompleted = 0;
$totalWatchedSeconds = 0;

foreach ($courses as $course) {

    $totalLessons += (int) $course['total_lessons'];

    $totalCompleted += (int) $course['completed_lessons'];

    $totalWatchedSeconds += (int) $course['watched_seconds'];
}


$overallProgress = 0;

if ($totalLessons > 0) {

    $overallProgress = (int) round(
        ($totalCompleted / $totalLessons) * 100
    );

}


function format_learning_time($seconds)
{
    $seconds = (int) $seconds;

    if ($seconds <= 0) {
        return '0 min';
    }

    $hours = floor($seconds / 3600);

    $minutes = floor(
        ($seconds % 3600) / 60
    );

    if ($hours > 0) {

        return $hours . 'h ' .
               $minutes . 'm';

    }

    return max(1, $minutes) . ' min';
}


include dirname(__DIR__) . '/partials/header.php';

?>

<style>

    :root {
        --lms-primary: #0f2a5f;
        --lms-accent: #2563eb;
        --lms-bg: #f5f7fb;
        --lms-muted: #64748b;
        --lms-border: #e2e8f0;
        --lms-shadow: 0 8px 25px rgba(15, 42, 95, 0.08);
    }

    body {
        background: var(--lms-bg);
    }

    .progress-page {
        padding: 35px 0 60px;
    }

    .page-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 20px;
        padding: 30px;
        margin-bottom: 30px;
        box-shadow: var(--lms-shadow);
    }

    .page-header h1 {
        font-weight: 700;
    }

    .summary-card {
        background: #fff;
        border: 1px solid var(--lms-border);
        border-radius: 16px;
        padding: 22px;
        height: 100%;
        box-shadow: var(--lms-shadow);
    }

    .summary-number {
        color: var(--lms-primary);
        font-size: 27px;
        font-weight: 700;
    }

    .summary-label {
        color: var(--lms-muted);
        font-size: 13px;
    }

    .course-progress-card {
        background: #fff;
        border: 1px solid var(--lms-border);
        border-radius: 18px;
        padding: 25px;
        box-shadow: var(--lms-shadow);
    }

    .course-title {
        color: var(--lms-primary);
        font-size: 19px;
        font-weight: 700;
    }

    .progress {
        height: 10px;
        background: #e5e7eb;
        border-radius: 20px;
    }

    .progress-bar {
        border-radius: 20px;
    }

    .progress-percent {
        font-size: 22px;
        font-weight: 700;
        color: var(--lms-primary);
    }

    .meta {
        color: var(--lms-muted);
        font-size: 13px;
    }

    .empty-box {
        background: #fff;
        border: 1px dashed #cbd5e1;
        border-radius: 18px;
        padding: 60px 20px;
        text-align: center;
        color: var(--lms-muted);
    }

</style>


<div class="progress-page">

    <div class="container">

        <!-- Header -->

        <div class="page-header">

            <div class="row align-items-center">

                <div class="col-lg-8">

                    <h1 class="mb-2">

                        <i class="fa-solid fa-chart-line me-2"></i>

                        Learning Progress

                    </h1>

                    <p class="mb-0 text-white-50">

                        Track your lesson completion and learning activity.

                    </p>

                </div>

                <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

                    <a href="<?= e(base_url('assan_computer_institute/student/dashboard.php')) ?>"
                       class="btn btn-light">

                        <i class="fa-solid fa-gauge me-1"></i>

                        Dashboard

                    </a>

                </div>

            </div>

        </div>


        <!-- Summary -->

        <div class="row g-4 mb-5">

            <div class="col-md-6 col-xl-3">

                <div class="summary-card">

                    <div class="summary-number">

                        <?= $totalCourses ?>

                    </div>

                    <div class="summary-label">

                        Active Courses

                    </div>

                </div>

            </div>


            <div class="col-md-6 col-xl-3">

                <div class="summary-card">

                    <div class="summary-number">

                        <?= $totalLessons ?>

                    </div>

                    <div class="summary-label">

                        Total Lessons

                    </div>

                </div>

            </div>


            <div class="col-md-6 col-xl-3">

                <div class="summary-card">

                    <div class="summary-number">

                        <?= $totalCompleted ?>

                    </div>

                    <div class="summary-label">

                        Lessons Completed

                    </div>

                </div>

            </div>


            <div class="col-md-6 col-xl-3">

                <div class="summary-card">

                    <div class="summary-number">

                        <?= format_learning_time(
                            $totalWatchedSeconds
                        ) ?>

                    </div>

                    <div class="summary-label">

                        Learning Time

                    </div>

                </div>

            </div>

        </div>


        <!-- Overall -->

        <div class="course-progress-card mb-4">

            <div class="d-flex justify-content-between
                        align-items-center mb-2">

                <div>

                    <div class="course-title">

                        Overall Learning Progress

                    </div>

                    <div class="meta">

                        Across all active courses

                    </div>

                </div>

                <div class="progress-percent">

                    <?= $overallProgress ?>%

                </div>

            </div>


            <div class="progress">

                <div class="progress-bar bg-primary"
                     style="width: <?= $overallProgress ?>%">
                </div>

            </div>

        </div>


        <!-- Individual Courses -->

        <div class="mb-3">

            <h3 class="course-title">

                Progress by Course

            </h3>

        </div>


        <div class="row g-4">

            <?php if (empty($courses)): ?>

                <div class="col-12">

                    <div class="empty-box">

                        <i class="fa-solid fa-chart-line fa-3x mb-3"></i>

                        <h4>No learning progress yet</h4>

                        <p>

                            Enroll in a course and start watching lessons.

                        </p>

                        <a href="<?= e(
                            base_url('assan_computer_institute/student/courses.php')
                        ) ?>"
                           class="btn btn-primary">

                            Browse Courses

                        </a>

                    </div>

                </div>

            <?php endif; ?>


            <?php foreach ($courses as $course): ?>

                <?php

                $lessons = (int) $course['total_lessons'];

                $completed = (int) $course['completed_lessons'];

                $progress = 0;

                if ($lessons > 0) {

                    $progress = (int) round(
                        ($completed / $lessons) * 100
                    );

                }

                ?>

                <div class="col-12">

                    <div class="course-progress-card">

                        <div class="row align-items-center">

                            <div class="col-lg-7">

                                <div class="course-title mb-1">

                                    <?= e($course['title']) ?>

                                </div>

                                <div class="meta mb-3">

                                    <i class="fa-solid fa-play-circle me-1"></i>

                                    <?= $completed ?>
                                    / <?= $lessons ?>
                                    lessons completed

                                    <span class="mx-2">•</span>

                                    <i class="fa-regular fa-clock me-1"></i>

                                    <?= format_learning_time(
                                        $course['watched_seconds']
                                    ) ?>

                                </div>

                                <div class="progress">

                                    <div class="progress-bar
                                                <?= $progress >= 100
                                                    ? 'bg-success'
                                                    : 'bg-primary' ?>"
                                         style="width: <?= $progress ?>%">
                                    </div>

                                </div>

                            </div>


                            <div class="col-lg-2 text-lg-center mt-3 mt-lg-0">

                                <div class="progress-percent">

                                    <?= $progress ?>%

                                </div>

                            </div>


                            <div class="col-lg-3 text-lg-end mt-3 mt-lg-0">

                                <a href="<?= e(
                                    base_url(
                                        'assan_computer_institute/student/course.php?id=' .
                                        (int) $course['course_id']
                                    )
                                ) ?>"
                                   class="btn btn-primary">

                                    <i class="fa-solid fa-play me-1"></i>

                                    Continue

                                </a>

                            </div>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</div>


<?php include dirname(__DIR__) . '/partials/footer.php'; ?>


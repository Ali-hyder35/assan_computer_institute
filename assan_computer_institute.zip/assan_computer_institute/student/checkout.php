<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();

$userId = (int) $user['id'];

$pageTitle = 'Course Checkout';


/*
|--------------------------------------------------------------------------
| Get Course
|--------------------------------------------------------------------------
*/

$courseId = isset($_GET['course'])
    ? (int) $_GET['course']
    : 0;


$stmt = $pdo->prepare("
    SELECT *
    FROM courses
    WHERE id = ?
      AND active = 1
    LIMIT 1
");

$stmt->execute(array($courseId));

$course = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$course) {

    flash('error', 'Course not found.');

    redirect(
        base_url(
            'assan_computer_institute/student/courses.php'
        )
    );

    exit;
}


$error = '';


/*
|--------------------------------------------------------------------------
| Check Existing Enrollment
|--------------------------------------------------------------------------
*/

$existingStmt = $pdo->prepare("
    SELECT *
    FROM enrollments
    WHERE user_id = ?
      AND course_id = ?
    ORDER BY id DESC
    LIMIT 1
");

$existingStmt->execute(array(
    $userId,
    $courseId
));

$existingEnrollment = $existingStmt->fetch(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Form Submit
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();


        /*
        |--------------------------------------------------------------------------
        | Payment Method
        |--------------------------------------------------------------------------
        */

        $method = isset($_POST['payment_method'])
            ? trim($_POST['payment_method'])
            : '';


        $allowedMethods = array(
            'bank',
            'jazzcash',
            'easypaisa'
        );


        if (!in_array($method, $allowedMethods, true)) {

            $error = 'Please select a valid payment method.';

        }


        /*
        |--------------------------------------------------------------------------
        | Payment Proof
        |--------------------------------------------------------------------------
        */

        $paymentProof = null;

        $file = null;

        $extension = '';


        if (!$error) {

            if (
                !isset($_FILES['payment_proof']) ||
                $_FILES['payment_proof']['error'] === UPLOAD_ERR_NO_FILE
            ) {

                $error =
                    'Please upload a screenshot or picture of your payment receipt.';

            } elseif (
                $_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK
            ) {

                $error =
                    'There was a problem uploading your payment proof.';

            }

        }


        /*
        |--------------------------------------------------------------------------
        | Validate Uploaded Image
        |--------------------------------------------------------------------------
        */

        if (!$error) {

            $file = $_FILES['payment_proof'];


            /*
            | Maximum 5 MB
            */

            if ((int) $file['size'] > (5 * 1024 * 1024)) {

                $error =
                    'Payment proof must not be larger than 5 MB.';

            }


            /*
            | Allowed extensions
            */

            $allowedExtensions = array(
                'jpg',
                'jpeg',
                'png',
                'webp'
            );


            $extension = strtolower(
                pathinfo(
                    $file['name'],
                    PATHINFO_EXTENSION
                )
            );


            if (
                !$error &&
                !in_array($extension, $allowedExtensions, true)
            ) {

                $error =
                    'Only JPG, JPEG, PNG and WEBP images are allowed.';

            }


            /*
            | Verify actual image
            */

            if (!$error) {

                $imageInfo = @getimagesize(
                    $file['tmp_name']
                );


                if ($imageInfo === false) {

                    $error =
                        'The uploaded payment proof is not a valid image.';

                }

            }

        }


        /*
        |--------------------------------------------------------------------------
        | Existing Enrollment
        |--------------------------------------------------------------------------
        */

        if (!$error && $existingEnrollment) {

            $existingPaymentStatus = strtolower(
                (string) $existingEnrollment['payment_status']
            );

            $existingAccessStatus = strtolower(
                (string) $existingEnrollment['access_status']
            );


            /*
            | Already fully enrolled
            */

            if (
                $existingPaymentStatus === 'paid' &&
                $existingAccessStatus === 'active'
            ) {

                flash(
                    'success',
                    'You are already enrolled in this course.'
                );


                redirect(
                    base_url(
                        'assan_computer_institute/student/course.php?id=' .
                        (int) $course['id']
                    )
                );

                exit;

            }


            /*
            | Existing pending enrollment
            */

            $enrollmentId = (int) $existingEnrollment['id'];

            $order = $existingEnrollment['order_ref'];

        }


        /*
        |--------------------------------------------------------------------------
        | Create Upload Directory
        |--------------------------------------------------------------------------
        */

        if (!$error) {

            $uploadDirectory =
                dirname(__DIR__) .
                '/uploads/payment_proofs/';


            if (!is_dir($uploadDirectory)) {

                if (!mkdir(
                    $uploadDirectory,
                    0755,
                    true
                )) {

                    $error =
                        'Unable to create payment proof upload directory.';

                }

            }

        }


        /*
        |--------------------------------------------------------------------------
        | Save Payment Proof
        |--------------------------------------------------------------------------
        */

        if (!$error) {

            $uniqueName =
                date('Ymd_His') .
                '_' .
                bin2hex(random_bytes(8)) .
                '.' .
                $extension;


            $destination =
                $uploadDirectory .
                $uniqueName;


            if (!move_uploaded_file(
                $file['tmp_name'],
                $destination
            )) {

                $error =
                    'Unable to save the payment proof. Please try again.';

            } else {

                $paymentProof =
                    'uploads/payment_proofs/' .
                    $uniqueName;

            }

        }


        /*
        |--------------------------------------------------------------------------
        | Create / Update Enrollment
        |--------------------------------------------------------------------------
        */

        if (!$error) {


            /*
            |--------------------------------------------------------------------------
            | Update Existing Pending Enrollment
            |--------------------------------------------------------------------------
            */

            if (
                !empty($existingEnrollment) &&
                strtolower(
                    (string) $existingEnrollment['payment_status']
                ) === 'pending'
            ) {

                $update = $pdo->prepare("
                    UPDATE enrollments

                    SET
                        payment_method = ?,
                        amount = ?,
                        payment_proof = ?,
                        payment_status = 'pending',
                        access_status = 'pending',
                        updated_at = CURRENT_TIMESTAMP

                    WHERE id = ?
                ");


                $update->execute(array(
                    $method,
                    $course['price'],
                    $paymentProof,
                    $enrollmentId
                ));

            }


            /*
            |--------------------------------------------------------------------------
            | Create New Enrollment
            |--------------------------------------------------------------------------
            */

            else {

                $order = order_ref();


                $insert = $pdo->prepare("
                    INSERT INTO enrollments
                    (
                        user_id,
                        student_name,
                        mobile,
                        email,
                        course_name,
                        course_id,
                        order_ref,
                        amount,
                        payment_method,
                        payment_status,
                        access_status,
                        payment_proof
                    )

                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        'pending',
                        'pending',
                        ?
                    )
                ");


                $insert->execute(array(
                    $userId,
                    $user['full_name'],
                    $user['mobile'],
                    $user['email'],
                    $course['title'],
                    $course['id'],
                    $order,
                    $course['price'],
                    $method,
                    $paymentProof
                ));


                $enrollmentId =
                    (int) $pdo->lastInsertId();

            }


            /*
            |--------------------------------------------------------------------------
            | Success
            |--------------------------------------------------------------------------
            */

            flash(
                'success',
                'Enrollment submitted successfully. Your payment proof has been uploaded and is waiting for verification.'
            );


            redirect(
                base_url(
                    'assan_computer_institute/student/enrolled_courses.php'
                )
            );

            exit;

        }

    } catch (Exception $e) {

        $error =
            'Unable to process your enrollment. Please try again.';

    }

}


include dirname(__DIR__) . '/partials/header.php';

?>


<style>

    :root {
        --lms-primary: #0f2a5f;
        --lms-primary-light: #1e4b8f;
        --lms-accent: #2563eb;
        --lms-accent-hover: #1d4ed8;
        --lms-bg: #f5f7fb;
        --lms-card: #ffffff;
        --lms-text: #1e293b;
        --lms-muted: #64748b;
        --lms-border: #e2e8f0;
        --lms-success: #16a34a;
        --lms-warning: #d97706;
        --lms-shadow: 0 8px 25px rgba(15, 42, 95, 0.08);
    }


    body {
        background: var(--lms-bg);
    }


    .checkout-page {
        padding: 40px 0 60px;
    }


    .checkout-card {
        background: #fff;

        border: 1px solid var(--lms-border);

        border-radius: 20px;

        padding: 30px;

        box-shadow: var(--lms-shadow);
    }


    .course-header {
        background: linear-gradient(
            135deg,
            #0f2a5f,
            #1e4b8f
        );

        color: #fff;

        border-radius: 16px;

        padding: 25px;

        margin-bottom: 25px;
    }


    .course-header h1 {
        font-size: 25px;

        font-weight: 700;
    }


    .price-box {
        display: flex;

        justify-content: space-between;

        align-items: center;

        border-top: 1px solid var(--lms-border);

        border-bottom: 1px solid var(--lms-border);

        padding: 18px 0;

        margin: 20px 0;
    }


    .price-label {
        color: var(--lms-muted);
    }


    .price-value {
        color: var(--lms-primary);

        font-size: 24px;

        font-weight: 700;
    }


    .payment-method {
        border: 1px solid var(--lms-border);

        border-radius: 14px;

        padding: 18px;

        cursor: pointer;

        height: 100%;

        transition: .2s ease;

        background: #fff;
    }


    .payment-method:hover {
        border-color: var(--lms-accent);

        background: #f8fbff;
    }


    .payment-method input {
        margin-right: 8px;
    }


    .payment-method-title {
        font-weight: 700;

        color: var(--lms-primary);

        margin-bottom: 5px;
    }


    .payment-method-description {
        color: var(--lms-muted);

        font-size: 13px;
    }


    .payment-info {
        background: #eff6ff;

        border: 1px solid #bfdbfe;

        border-radius: 14px;

        padding: 18px;

        color: #1e3a8a;

        font-size: 14px;
    }


    .payment-proof-box {
        border: 2px dashed #cbd5e1;

        border-radius: 15px;

        padding: 25px;

        background: #f8fafc;

        text-align: center;
    }


    .payment-proof-box i {
        font-size: 35px;

        color: var(--lms-accent);

        margin-bottom: 10px;
    }


    .payment-proof-box .form-control {
        background: #fff;

        border: 1px solid var(--lms-border);

        margin-top: 15px;
    }


    .upload-note {
        color: var(--lms-muted);

        font-size: 12px;

        margin-top: 8px;
    }


    .btn-primary {
        background: var(--lms-accent);

        border-color: var(--lms-accent);
    }


    .btn-primary:hover {
        background: var(--lms-accent-hover);

        border-color: var(--lms-accent-hover);
    }

</style>


<div class="checkout-page">

    <div class="container">

        <div class="row justify-content-center">

            <div class="col-lg-8">

                <div class="checkout-card">


                    <!-- Course Header -->

                    <div class="course-header">

                        <span class="small text-white-50 fw-bold">

                            COURSE ENROLLMENT

                        </span>


                        <h1 class="mt-2 mb-2">

                            <?= e($course['title']) ?>

                        </h1>


                        <p class="mb-0 text-white-50">

                            <?= e($course['description']) ?>

                        </p>

                    </div>



                    <!-- Course Fee -->

                    <div class="price-box">

                        <span class="price-label">

                            Course Fee

                        </span>


                        <span class="price-value">

                            <?= money($course['price']) ?>

                        </span>

                    </div>



                    <?php if ($error): ?>

                        <div class="alert alert-danger">

                            <i class="fa-solid fa-circle-exclamation me-2"></i>

                            <?= e($error) ?>

                        </div>

                    <?php endif; ?>



                    <!-- Payment Form -->

                    <form
                        method="post"
                        enctype="multipart/form-data"
                    >

                        <?= csrf_field() ?>


                        <!-- Payment Method -->

                        <div class="mb-4">

                            <label class="form-label fw-bold">

                                <i class="fa-solid fa-credit-card me-1"></i>

                                Select Payment Method

                            </label>


                            <div class="row g-3">


                                <!-- Bank -->

                                <div class="col-md-4">

                                    <label class="payment-method d-block">

                                        <input
                                            type="radio"
                                            name="payment_method"
                                            value="bank"
                                            checked
                                            required
                                        >

                                        <span class="payment-method-title">

                                            Bank Transfer

                                        </span>


                                        <div class="payment-method-description">

                                            Upload your bank transfer receipt.

                                        </div>

                                    </label>

                                </div>



                                <!-- JazzCash -->

                                <div class="col-md-4">

                                    <label class="payment-method d-block">

                                        <input
                                            type="radio"
                                            name="payment_method"
                                            value="jazzcash"
                                            required
                                        >

                                        <span class="payment-method-title">

                                            JazzCash

                                        </span>


                                        <div class="payment-method-description">

                                            Send payment through JazzCash.

                                        </div>

                                    </label>

                                </div>



                                <!-- Easypaisa -->

                                <div class="col-md-4">

                                    <label class="payment-method d-block">

                                        <input
                                            type="radio"
                                            name="payment_method"
                                            value="easypaisa"
                                            required
                                        >

                                        <span class="payment-method-title">

                                            Easypaisa

                                        </span>


                                        <div class="payment-method-description">

                                            Send payment through Easypaisa.

                                        </div>

                                    </label>

                                </div>

                            </div>

                        </div>



                        <!-- Payment Information -->

                        <div class="payment-info mb-4">

                            <div class="fw-bold mb-3">

                                <i class="fa-solid fa-circle-info me-1"></i>

                                Payment Instructions

                            </div>


                            <div class="mb-2">

                                <strong>JazzCash:</strong>

                                Dummy Account Name

                            </div>


                            <div class="mb-2">

                                <strong>JazzCash Account Number:</strong>

                                Dummy Account Number

                            </div>


                            <div class="mb-2">

                                <strong>Easypaisa:</strong>

                                Dummy Account Name

                            </div>


                            <div class="mb-2">

                                <strong>Easypaisa Account Number:</strong>

                                Dummy Account Number

                            </div>


                            <div>

                                <strong>Bank Transfer:</strong>

                                Transfer the course fee to the
                                institute's bank account and upload
                                your payment receipt below.

                            </div>

                        </div>



                        <!-- Payment Proof -->

                        <div class="mb-4">

                            <label class="form-label fw-bold">

                                <i class="fa-solid fa-image me-1"></i>

                                Upload Payment Proof

                                <span class="text-danger">*</span>

                            </label>


                            <div class="payment-proof-box">

                                <i class="fa-solid fa-cloud-arrow-up d-block"></i>


                                <div class="fw-bold">

                                    Upload Payment Screenshot / Receipt

                                </div>


                                <div class="text-muted small">

                                    Take a screenshot or photo of your
                                    payment confirmation and upload it here.

                                </div>


                                <input
                                    type="file"
                                    name="payment_proof"
                                    id="payment_proof"
                                    class="form-control"
                                    accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                                    required
                                >


                                <div class="upload-note">

                                    Allowed formats:
                                    JPG, JPEG, PNG, WEBP

                                    <br>

                                    Maximum size: 5 MB

                                </div>

                            </div>

                        </div>



                        <!-- Verification Notice -->

                        <div class="alert alert-warning small">

                            <i class="fa-solid fa-shield-halved me-2"></i>

                            <strong>Important:</strong>

                            After submitting your enrollment, the
                            institute administrator will verify your
                            payment proof.

                            Your course access will be activated after
                            the payment has been verified.

                        </div>



                        <!-- Buttons -->

                        <div class="row g-2">

                            <div class="col-md-5">

                                <a
                                    href="<?= e(
                                        base_url(
                                            'assan_computer_institute/student/courses.php'
                                        )
                                    ) ?>"
                                    class="btn btn-outline-secondary w-100 py-2"
                                >

                                    <i class="fa-solid fa-arrow-left me-1"></i>

                                    Back to Courses

                                </a>

                            </div>


                            <div class="col-md-7">

                                <button
                                    type="submit"
                                    class="btn btn-primary w-100 py-2"
                                >

                                    <i class="fa-solid fa-paper-plane me-1"></i>

                                    Submit Enrollment & Payment Proof

                                </button>

                            </div>

                        </div>


                    </form>

                </div>

            </div>

        </div>

    </div>

</div>


<?php

include dirname(__DIR__) . '/partials/footer.php';

?>
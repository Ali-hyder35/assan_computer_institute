<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();

$userId = (int) $user['id'];

$pageTitle = 'My Courses';


$stmt = $pdo->prepare("
    SELECT
        e.id AS enrollment_id,
        e.course_id,
        e.course_name,
        e.amount,
        e.payment_status,
        e.access_status,
        e.created_at,

        c.title,
        c.description,
        c.duration,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            WHERE cv.course_id = c.id
              AND cv.active = 1
        ) AS total_lessons,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            INNER JOIN student_video_progress svp
                ON svp.video_id = cv.id
               AND svp.user_id = e.user_id
            WHERE cv.course_id = c.id
              AND cv.active = 1
              AND svp.completed = 1
        ) AS completed_lessons

    FROM enrollments e

    INNER JOIN courses c
        ON c.id = e.course_id

    WHERE e.user_id = ?

    ORDER BY e.created_at DESC
");

$stmt->execute(array($userId));

$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);


include dirname(__DIR__) . '/partials/header.php';

?>

<style>

    :root {
        --lms-primary: #0f2a5f;
        --lms-accent: #2563eb;
        --lms-bg: #f5f7fb;
        --lms-muted: #64748b;
        --lms-border: #e2e8f0;
        --lms-shadow: 0 8px 25px rgba(15, 42, 95, 0.08);
    }

    body {
        background: var(--lms-bg);
    }

    .enrolled-page {
        padding: 35px 0 60px;
    }

    .page-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 20px;
        padding: 30px;
        margin-bottom: 30px;
        box-shadow: var(--lms-shadow);
    }

    .page-header h1 {
        font-weight: 700;
    }

    .course-card {
        background: #fff;
        border: 1px solid var(--lms-border);
        border-radius: 18px;
        padding: 25px;
        height: 100%;
        box-shadow: var(--lms-shadow);
    }

    .course-icon {
        width: 58px;
        height: 58px;
        border-radius: 15px;
        background: #eff6ff;
        color: var(--lms-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 23px;
    }

    .course-title {
        color: var(--lms-primary);
        font-weight: 700;
        font-size: 20px;
    }

    .course-description {
        color: var(--lms-muted);
        font-size: 14px;
        min-height: 45px;
    }

    .progress {
        height: 9px;
        background: #e5e7eb;
        border-radius: 20px;
    }

    .progress-bar {
        border-radius: 20px;
    }

    .course-meta {
        font-size: 13px;
        color: var(--lms-muted);
    }

    .status-badge {
        font-size: 11px;
        padding: 6px 10px;
        border-radius: 30px;
        font-weight: 600;
    }

    .status-active {
        background: #dcfce7;
        color: #166534;
    }

    .status-pending {
        background: #fef3c7;
        color: #92400e;
    }

    .status-suspended {
        background: #fee2e2;
        color: #991b1b;
    }

    .empty-box {
        background: #fff;
        border: 1px dashed #cbd5e1;
        border-radius: 18px;
        padding: 60px 20px;
        text-align: center;
        color: var(--lms-muted);
    }

</style>


<div class="enrolled-page">

    <div class="container">

        <div class="page-header">

            <div class="row align-items-center">

                <div class="col-lg-8">

                    <h1 class="mb-2">

                        <i class="fa-solid fa-graduation-cap me-2"></i>

                        My Courses

                    </h1>

                    <p class="mb-0 text-white-50">

                        Access your enrolled courses and continue learning.

                    </p>

                </div>

                <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

                    <a href="<?= e(base_url('assan_computer_institute/student/courses.php')) ?>"
                       class="btn btn-light">

                        <i class="fa-solid fa-plus me-1"></i>

                        Browse Courses

                    </a>

                </div>

            </div>

        </div>


        <div class="row g-4">

            <?php if (empty($courses)): ?>

                <div class="col-12">

                    <div class="empty-box">

                        <i class="fa-solid fa-graduation-cap fa-3x mb-3"></i>

                        <h4>You have no enrolled courses</h4>

                        <p>

                            Choose a course and start your learning journey.

                        </p>

                        <a href="<?= e(base_url('assan_computer_institute/student/courses.php')) ?>"
                           class="btn btn-primary">

                            Browse Courses

                        </a>

                    </div>

                </div>

            <?php endif; ?>


            <?php foreach ($courses as $course): ?>

                <?php

                $totalLessons = (int) $course['total_lessons'];
                $completedLessons = (int) $course['completed_lessons'];

                $progress = 0;

                if ($totalLessons > 0) {

                    $progress = (int) round(
                        ($completedLessons / $totalLessons) * 100
                    );

                }

                ?>

                <div class="col-md-6 col-xl-4">

                    <div class="course-card">

                        <div class="d-flex align-items-start gap-3 mb-3">

                            <div class="course-icon">

                                <i class="fa-solid fa-laptop-code"></i>

                            </div>

                            <div class="flex-grow-1">

                                <div class="course-title">

                                    <?= e($course['title']) ?>

                                </div>

                                <div class="course-meta">

                                    <?= $totalLessons ?> lessons

                                </div>

                            </div>

                        </div>


                        <div class="course-description mb-3">

                            <?= e(
                                mb_strimwidth(
                                    (string) $course['description'],
                                    0,
                                    130,
                                    '...'
                                )
                            ) ?>

                        </div>


                        <div class="d-flex justify-content-between
                                    align-items-center mb-2">

                            <small class="text-muted">
                                Progress
                            </small>

                            <strong>
                                <?= $progress ?>%
                            </strong>

                        </div>


                        <div class="progress mb-3">

                            <div class="progress-bar
                                        <?= $progress >= 100
                                            ? 'bg-success'
                                            : 'bg-primary' ?>"
                                 style="width: <?= $progress ?>%">
                            </div>

                        </div>


                        <div class="course-meta mb-3">

                            <i class="fa-regular fa-clock me-1"></i>

                            <?= e(
                                $course['duration']
                                ?: 'Flexible learning'
                            ) ?>

                            <span class="mx-1">•</span>

                            <?= $completedLessons ?>
                            / <?= $totalLessons ?> completed

                        </div>


                        <?php

                        $accessStatus = $course['access_status'];

                        $statusClass = 'status-pending';

                        if ($accessStatus === 'active') {
                            $statusClass = 'status-active';
                        } elseif ($accessStatus === 'suspended') {
                            $statusClass = 'status-suspended';
                        }

                        ?>


                        <div class="mb-3">

                            <span class="status-badge <?= $statusClass ?>">

                                <?= e(ucfirst($accessStatus)) ?>

                            </span>

                        </div>


                        <?php if (
                            $course['payment_status'] === 'paid'
                            && $course['access_status'] === 'active'
                        ): ?>

                            <a href="<?= e(
                                base_url(
                                    'assan_computer_institute/student/course.php?id=' .
                                    (int) $course['course_id']
                                )
                            ) ?>"
                               class="btn btn-primary w-100">

                                <?php if ($progress >= 100): ?>

                                    <i class="fa-solid fa-circle-check me-1"></i>

                                    Course Completed

                                <?php else: ?>

                                    <i class="fa-solid fa-play me-1"></i>

                                    Continue Learning

                                <?php endif; ?>

                            </a>

                        <?php else: ?>

                            <button class="btn btn-secondary w-100"
                                    disabled>

                                <i class="fa-solid fa-lock me-1"></i>

                                Access Pending

                            </button>

                        <?php endif; ?>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</div>


<?php include dirname(__DIR__) . '/partials/footer.php'; ?>


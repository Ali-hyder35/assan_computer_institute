
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();

$userId = (int) $user['id'];

$pageTitle = 'Student Dashboard';


/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student Dashboard
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| Total Enrolled Courses
|--------------------------------------------------------------------------
|
| Count ALL enrollments, including pending payment.
|
*/

$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT course_id)
    FROM enrollments
    WHERE user_id = ?
");

$stmt->execute(
    array($userId)
);

$totalCourses = (int) $stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| Active / In Progress Courses
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT e.course_id)
    FROM enrollments e

    WHERE e.user_id = ?

      AND e.payment_status = 'paid'

      AND e.access_status = 'active'

      AND EXISTS (

          SELECT 1

          FROM course_videos cv

          INNER JOIN student_video_progress svp
              ON svp.video_id = cv.id

             AND svp.user_id = e.user_id

          WHERE cv.course_id = e.course_id

            AND cv.active = 1

            AND svp.completed = 1

      )

      AND EXISTS (

          SELECT 1

          FROM course_videos cv2

          WHERE cv2.course_id = e.course_id

            AND cv2.active = 1

      )

      AND NOT EXISTS (

          SELECT 1

          FROM course_videos cv3

          LEFT JOIN student_video_progress svp3
              ON svp3.video_id = cv3.id

             AND svp3.user_id = e.user_id

          WHERE cv3.course_id = e.course_id

            AND cv3.active = 1

          GROUP BY cv3.course_id

          HAVING COUNT(cv3.id) =
                 COUNT(
                     CASE
                         WHEN svp3.completed = 1
                         THEN cv3.id
                     END
                 )

      )
");

$stmt->execute(
    array($userId)
);

$startedCourses = (int) $stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| Completed Courses
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT COUNT(*)

    FROM (

        SELECT
            e.course_id,

            COUNT(DISTINCT cv.id)
                AS total_lessons,

            COUNT(
                DISTINCT CASE
                    WHEN svp.completed = 1
                    THEN cv.id
                END
            ) AS completed_lessons

        FROM enrollments e

        INNER JOIN course_videos cv

            ON cv.course_id = e.course_id

           AND cv.active = 1

        LEFT JOIN student_video_progress svp

            ON svp.video_id = cv.id

           AND svp.user_id = e.user_id

        WHERE e.user_id = ?

          AND e.payment_status = 'paid'

          AND e.access_status = 'active'

        GROUP BY e.course_id

        HAVING total_lessons > 0

           AND completed_lessons >= total_lessons

    ) completed_courses
");

$stmt->execute(
    array($userId)
);

$completedCourses = (int) $stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| Overall Progress
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT

        COUNT(cv.id) AS total_lessons,

        COUNT(
            CASE
                WHEN svp.completed = 1
                THEN 1
            END
        ) AS completed_lessons

    FROM enrollments e

    INNER JOIN course_videos cv

        ON cv.course_id = e.course_id

       AND cv.active = 1

    LEFT JOIN student_video_progress svp

        ON svp.video_id = cv.id

       AND svp.user_id = e.user_id

    WHERE e.user_id = ?

      AND e.payment_status = 'paid'

      AND e.access_status = 'active'
");

$stmt->execute(
    array($userId)
);

$progressStats =
    $stmt->fetch(PDO::FETCH_ASSOC);


$totalLessons = (int) (
    isset($progressStats['total_lessons'])
        ? $progressStats['total_lessons']
        : 0
);

$completedLessons = (int) (
    isset($progressStats['completed_lessons'])
        ? $progressStats['completed_lessons']
        : 0
);


$overallProgress = 0;

if ($totalLessons > 0) {

    $overallProgress = (int) round(
        ($completedLessons / $totalLessons) * 100
    );
}


/*
|--------------------------------------------------------------------------
| Pending Payments
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT COUNT(*)

    FROM enrollments

    WHERE user_id = ?

      AND payment_status = 'pending'
");

$stmt->execute(
    array($userId)
);

$pendingPayments = (int) $stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| Recent / Current Courses
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT

        e.id AS enrollment_id,

        e.course_id,

        e.course_name,

        e.amount,

        e.payment_method,

        e.payment_status,

        e.access_status,

        e.order_ref,

        e.created_at,

        c.title,

        c.slug,

        c.description,

        c.duration,

        (

            SELECT COUNT(*)

            FROM course_videos cv

            WHERE cv.course_id = c.id

              AND cv.active = 1

        ) AS total_lessons,

        (

            SELECT COUNT(*)

            FROM course_videos cv

            INNER JOIN student_video_progress svp

                ON svp.video_id = cv.id

               AND svp.user_id = e.user_id

            WHERE cv.course_id = c.id

              AND cv.active = 1

              AND svp.completed = 1

        ) AS completed_lessons

    FROM enrollments e

    INNER JOIN courses c

        ON c.id = e.course_id

    WHERE e.user_id = ?

    ORDER BY e.created_at DESC

    LIMIT 6
");

$stmt->execute(
    array($userId)
);

$myCourses =
    $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Available Courses
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| is_enrolled checks ANY enrollment, not only paid/active.
|
*/

$stmt = $pdo->prepare("
    SELECT

        c.*,

        (

            SELECT COUNT(*)

            FROM course_videos cv

            WHERE cv.course_id = c.id

              AND cv.active = 1

        ) AS total_lessons,

        EXISTS (

            SELECT 1

            FROM enrollments e

            WHERE e.user_id = ?

              AND e.course_id = c.id

        ) AS is_enrolled,

        (

            SELECT e.payment_status

            FROM enrollments e

            WHERE e.user_id = ?

              AND e.course_id = c.id

            ORDER BY e.id DESC

            LIMIT 1

        ) AS enrollment_payment_status,

        (

            SELECT e.access_status

            FROM enrollments e

            WHERE e.user_id = ?

              AND e.course_id = c.id

            ORDER BY e.id DESC

            LIMIT 1

        ) AS enrollment_access_status

    FROM courses c

    WHERE c.active = 1

    ORDER BY c.created_at DESC

    LIMIT 6
");

$stmt->execute(
    array(
        $userId,
        $userId,
        $userId
    )
);

$availableCourses =
    $stmt->fetchAll(PDO::FETCH_ASSOC);


include dirname(__DIR__) . '/partials/header.php';

?>


<style>

    :root {

        --lms-primary: #0f2a5f;
        --lms-primary-light: #1e4b8f;
        --lms-accent: #2563eb;
        --lms-accent-hover: #1d4ed8;

        --lms-bg: #f5f7fb;
        --lms-card: #ffffff;

        --lms-text: #1e293b;
        --lms-muted: #64748b;

        --lms-border: #e2e8f0;

        --lms-success: #16a34a;
        --lms-warning: #d97706;
        --lms-danger: #dc2626;

        --lms-shadow:
            0 8px 25px rgba(15, 42, 95, 0.08);

    }


    body {

        background: var(--lms-bg);
        color: var(--lms-text);

    }


    /* =========================================================
       STUDENT NAVBAR
    ========================================================= */

    .student-navbar {

        background: #ffffff;

        border-bottom:
            1px solid var(--lms-border);

        box-shadow:
            0 3px 15px rgba(15, 42, 95, 0.06);

        position: sticky;

        top: 0;

        z-index: 1020;

    }


    .student-navbar-inner {

        min-height: 68px;

    }


    .student-brand {

        color: var(--lms-primary);

        font-size: 18px;

        font-weight: 700;

        text-decoration: none;

        white-space: nowrap;

    }


    .student-brand:hover {

        color: var(--lms-accent);

    }


    .student-nav-link {

        color: #475569;

        text-decoration: none;

        font-size: 14px;

        font-weight: 600;

        padding: 10px 12px;

        border-radius: 8px;

        transition: .2s ease;

        display: inline-flex;

        align-items: center;

        gap: 6px;

    }


    .student-nav-link:hover {

        color: var(--lms-accent);

        background: #eff6ff;

    }


    .student-nav-link.active {

        color: var(--lms-accent);

        background: #eff6ff;

    }


    .student-logout {

        color: #dc2626;

        text-decoration: none;

        font-size: 14px;

        font-weight: 600;

        padding: 9px 13px;

        border:
            1px solid #fecaca;

        border-radius: 8px;

        background: #fffafa;

    }


    .student-logout:hover {

        color: #b91c1c;

        background: #fef2f2;

    }


    .student-user {

        display: flex;

        align-items: center;

        gap: 8px;

        color: var(--lms-muted);

        font-size: 13px;

        font-weight: 600;

    }


    .student-user-icon {

        width: 34px;

        height: 34px;

        border-radius: 50%;

        background: #eff6ff;

        color: var(--lms-accent);

        display: flex;

        align-items: center;

        justify-content: center;

    }


    /* =========================================================
       MOBILE NAV
    ========================================================= */

    .student-mobile-nav {

        border-top:
            1px solid var(--lms-border);

        padding: 10px 0;

        background: #ffffff;

    }


    .student-mobile-nav .student-nav-link {

        width: 100%;

    }


    /* =========================================================
       PAGE
    ========================================================= */

    .student-page {

        padding: 35px 0 60px;

    }


    /* =========================================================
       WELCOME
    ========================================================= */

    .welcome-card {

        background:
            linear-gradient(
                135deg,
                #0f2a5f,
                #1e4b8f
            );

        color: #fff;

        border-radius: 20px;

        padding: 32px;

        box-shadow: var(--lms-shadow);

        position: relative;

        overflow: hidden;

    }


    .welcome-card::after {

        content: "";

        position: absolute;

        width: 220px;

        height: 220px;

        border-radius: 50%;

        background:
            rgba(255, 255, 255, 0.06);

        right: -70px;

        top: -70px;

    }


    .welcome-card h1 {

        font-size: 30px;

        font-weight: 700;

    }


    .welcome-card p {

        color:
            rgba(255,255,255,.78);

        margin-bottom: 0;

    }


    /* =========================================================
       STAT CARDS
    ========================================================= */

    .stat-card {

        background: #fff;

        border:
            1px solid var(--lms-border);

        border-radius: 16px;

        padding: 22px;

        height: 100%;

        box-shadow: var(--lms-shadow);

    }


    .stat-icon {

        width: 48px;

        height: 48px;

        border-radius: 13px;

        background: #eff6ff;

        color: var(--lms-accent);

        display: flex;

        align-items: center;

        justify-content: center;

        font-size: 20px;

    }


    .stat-number {

        font-size: 28px;

        font-weight: 700;

        color: var(--lms-primary);

    }


    .stat-label {

        color: var(--lms-muted);

        font-size: 13px;

    }


    /* =========================================================
       SECTIONS
    ========================================================= */

    .section-title {

        font-size: 22px;

        font-weight: 700;

        color: var(--lms-primary);

    }


    /* =========================================================
       COURSE CARD
    ========================================================= */

    .course-card {

        background: #fff;

        border:
            1px solid var(--lms-border);

        border-radius: 17px;

        padding: 22px;

        height: 100%;

        box-shadow: var(--lms-shadow);

    }


    .course-icon {

        width: 52px;

        height: 52px;

        border-radius: 14px;

        background: #eff6ff;

        color: var(--lms-accent);

        display: flex;

        align-items: center;

        justify-content: center;

        font-size: 22px;

    }


    .course-title {

        font-size: 18px;

        font-weight: 700;

        color: var(--lms-primary);

    }


    .course-description {

        color: var(--lms-muted);

        font-size: 14px;

        min-height: 45px;

    }


    .progress {

        height: 8px;

        border-radius: 20px;

        background: #e5e7eb;

    }


    .progress-bar {

        border-radius: 20px;

    }


    .dashboard-link {

        color: var(--lms-accent);

        text-decoration: none;

        font-weight: 600;

    }


    .dashboard-link:hover {

        color: var(--lms-accent-hover);

    }


    /* =========================================================
       STATUS
    ========================================================= */

    .course-status {

        display: inline-flex;

        align-items: center;

        gap: 5px;

        font-size: 12px;

        font-weight: 700;

        padding: 5px 9px;

        border-radius: 20px;

    }


    .status-paid {

        color: #166534;

        background: #dcfce7;

    }


    .status-pending {

        color: #92400e;

        background: #fef3c7;

    }


    .status-suspended {

        color: #991b1b;

        background: #fee2e2;

    }


    .status-access-pending {

        color: #1e40af;

        background: #dbeafe;

    }


    /* =========================================================
       EMPTY
    ========================================================= */

    .empty-box {

        background: #fff;

        border:
            1px dashed #cbd5e1;

        border-radius: 16px;

        padding: 40px 20px;

        text-align: center;

        color: var(--lms-muted);

    }


    /* =========================================================
       QUICK ACTIONS
    ========================================================= */

    .quick-card {

        background: #fff;

        border:
            1px solid var(--lms-border);

        border-radius: 15px;

        padding: 18px;

        height: 100%;

        text-decoration: none;

        display: block;

        box-shadow: var(--lms-shadow);

        transition: .2s ease;

    }


    .quick-card:hover {

        transform: translateY(-3px);

        border-color: #bfdbfe;

    }


    .quick-icon {

        width: 44px;

        height: 44px;

        border-radius: 12px;

        background: #eff6ff;

        color: var(--lms-accent);

        display: flex;

        align-items: center;

        justify-content: center;

        margin-bottom: 12px;

    }


    .quick-title {

        color: var(--lms-primary);

        font-weight: 700;

        margin-bottom: 4px;

    }


    .quick-text {

        color: var(--lms-muted);

        font-size: 13px;

    }


    @media (max-width: 991px) {

        .desktop-student-nav {

            display: none !important;

        }

    }


    @media (min-width: 992px) {

        .mobile-student-nav {

            display: none !important;

        }

    }

</style>


<!-- =========================================================
     STUDENT NAVBAR
========================================================= -->

<nav class="student-navbar">

    <div class="container">

        <div
            class="student-navbar-inner
                   d-flex
                   align-items-center
                   justify-content-between"
        >

            <!-- BRAND -->

            <a
                href="<?= e(
                    base_url(
                        'assan_computer_institute/student/dashboard.php'
                    )
                ) ?>"
                class="student-brand"
            >

                <i class="fa-solid fa-graduation-cap me-2"></i>

                Assan Computer Institute

            </a>


            <!-- DESKTOP NAV -->

            <div
                class="desktop-student-nav
                       d-none
                       d-lg-flex
                       align-items-center
                       gap-1"
            >

                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/dashboard.php'
                        )
                    ) ?>"
                    class="student-nav-link active"
                >

                    <i class="fa-solid fa-gauge-high"></i>

                    Dashboard

                </a>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/enrolled_courses.php'
                        )
                    ) ?>"
                    class="student-nav-link"
                >

                    <i class="fa-solid fa-book-open"></i>

                    My Courses

                </a>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/courses.php'
                        )
                    ) ?>"
                    class="student-nav-link"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Browse Courses

                </a>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/exams.php'
                        )
                    ) ?>"
                    class="student-nav-link"
                >

                    <i class="fa-solid fa-file-pen"></i>

                    Give Exam

                </a>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/exam_results.php'
                        )
                    ) ?>"
                    class="student-nav-link"
                >

                    <i class="fa-solid fa-square-poll-vertical"></i>

                    Marks

                </a>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/certificates.php'
                        )
                    ) ?>"
                    class="student-nav-link"
                >

                    <i class="fa-solid fa-certificate"></i>

                    Certificates

                </a>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/profile.php'
                        )
                    ) ?>"
                    class="student-nav-link"
                >

                    <i class="fa-solid fa-user"></i>

                    Profile

                </a>

            </div>


            <!-- USER + LOGOUT -->

            <div
                class="d-none
                       d-lg-flex
                       align-items-center
                       gap-3"
            >

                <div class="student-user">

                    <span class="student-user-icon">

                        <i class="fa-solid fa-user"></i>

                    </span>

                    <span>

                        <?= e($user['full_name']) ?>

                    </span>

                </div>


                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/index.php'
                        )
                    ) ?>"
                    class="student-logout"
                >

                    <i class="fa-solid fa-right-from-bracket me-1"></i>

                    Logout

                </a>

            </div>

        </div>


        <!-- =====================================================
             MOBILE NAV
        ====================================================== -->

        <div class="mobile-student-nav student-mobile-nav">

            <div class="row g-2">

                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/dashboard.php'
                            )
                        ) ?>"
                        class="student-nav-link active"
                    >

                        <i class="fa-solid fa-gauge-high"></i>

                        Dashboard

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/enrolled_courses.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                    >

                        <i class="fa-solid fa-book-open"></i>

                        My Courses

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/courses.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                    >

                        <i class="fa-solid fa-layer-group"></i>

                        Browse Courses

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/exams.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                    >

                        <i class="fa-solid fa-file-pen"></i>

                        Give Exam

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/exam_results.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                    >

                        <i class="fa-solid fa-square-poll-vertical"></i>

                        Marks

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/certificates.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                    >

                        <i class="fa-solid fa-certificate"></i>

                        Certificates

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/profile.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                    >

                        <i class="fa-solid fa-user"></i>

                        Profile

                    </a>

                </div>


                <div class="col-6">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/logout.php'
                            )
                        ) ?>"
                        class="student-nav-link"
                        style="color:#dc2626;"
                    >

                        <i class="fa-solid fa-right-from-bracket"></i>

                        Logout

                    </a>

                </div>

            </div>

        </div>

    </div>

</nav>


<!-- =========================================================
     STUDENT PAGE
========================================================= -->

<div class="student-page">

    <div class="container">


        <!-- =====================================================
             WELCOME
        ====================================================== -->

        <div class="welcome-card mb-4">

            <div class="row align-items-center">

                <div class="col-lg-8">

                    <h1 class="mb-2">

                        Welcome back,
                        <?= e($user['full_name']) ?>!

                    </h1>

                    <p>

                        Continue your learning journey and build
                        practical professional skills.

                    </p>

                </div>


                <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/courses.php'
                            )
                        ) ?>"
                        class="btn btn-light px-4"
                    >

                        <i class="fa-solid fa-book-open me-2"></i>

                        Browse Courses

                    </a>

                </div>

            </div>

        </div>


        <!-- =====================================================
             STATISTICS
        ====================================================== -->

        <div class="row g-4 mb-5">


            <!-- ENROLLED -->

            <div class="col-md-6 col-xl-3">

                <div class="stat-card">

                    <div
                        class="d-flex
                               justify-content-between"
                    >

                        <div>

                            <div class="stat-label mb-1">

                                Enrolled Courses

                            </div>

                            <div class="stat-number">

                                <?= $totalCourses ?>

                            </div>

                        </div>

                        <div class="stat-icon">

                            <i class="fa-solid fa-book"></i>

                        </div>

                    </div>

                </div>

            </div>


            <!-- IN PROGRESS -->

            <div class="col-md-6 col-xl-3">

                <div class="stat-card">

                    <div
                        class="d-flex
                               justify-content-between"
                    >

                        <div>

                            <div class="stat-label mb-1">

                                In Progress

                            </div>

                            <div class="stat-number">

                                <?= $startedCourses ?>

                            </div>

                        </div>

                        <div class="stat-icon">

                            <i class="fa-solid fa-spinner"></i>

                        </div>

                    </div>

                </div>

            </div>


            <!-- COMPLETED -->

            <div class="col-md-6 col-xl-3">

                <div class="stat-card">

                    <div
                        class="d-flex
                               justify-content-between"
                    >

                        <div>

                            <div class="stat-label mb-1">

                                Completed

                            </div>

                            <div class="stat-number">

                                <?= $completedCourses ?>

                            </div>

                        </div>

                        <div class="stat-icon">

                            <i class="fa-solid fa-circle-check"></i>

                        </div>

                    </div>

                </div>

            </div>


            <!-- PROGRESS -->

            <div class="col-md-6 col-xl-3">

                <div class="stat-card">

                    <div
                        class="d-flex
                               justify-content-between"
                    >

                        <div>

                            <div class="stat-label mb-1">

                                Overall Progress

                            </div>

                            <div class="stat-number">

                                <?= $overallProgress ?>%

                            </div>

                        </div>

                        <div class="stat-icon">

                            <i class="fa-solid fa-chart-line"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =====================================================
             QUICK ACTIONS
        ====================================================== -->

        <div class="section-title mb-3">

            Student Portal

        </div>

        <div class="row g-3 mb-5">


            <!-- MY COURSES -->

            <div class="col-md-6 col-lg-3">

                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/enrolled_courses.php'
                        )
                    ) ?>"
                    class="quick-card"
                >

                    <div class="quick-icon">

                        <i class="fa-solid fa-book-open"></i>

                    </div>

                    <div class="quick-title">

                        My Courses

                    </div>

                    <div class="quick-text">

                        View all your enrolled courses
                        and learning progress.

                    </div>

                </a>

            </div>


            <!-- EXAMS -->

            <div class="col-md-6 col-lg-3">

                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/exams.php'
                        )
                    ) ?>"
                    class="quick-card"
                >

                    <div class="quick-icon">

                        <i class="fa-solid fa-file-pen"></i>

                    </div>

                    <div class="quick-title">

                        Give Exam

                    </div>

                    <div class="quick-text">

                        View available exams and
                        start your examination.

                    </div>

                </a>

            </div>


            <!-- MARKS -->

            <div class="col-md-6 col-lg-3">

                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/exam_results.php'
                        )
                    ) ?>"
                    class="quick-card"
                >

                    <div class="quick-icon">

                        <i class="fa-solid fa-square-poll-vertical"></i>

                    </div>

                    <div class="quick-title">

                        Check Marks

                    </div>

                    <div class="quick-text">

                        Check your exam results,
                        scores and performance.

                    </div>

                </a>

            </div>


            <!-- CERTIFICATES -->

            <div class="col-md-6 col-lg-3">

                <a
                    href="<?= e(
                        base_url(
                            'assan_computer_institute/student/certificates.php'
                        )
                    ) ?>"
                    class="quick-card"
                >

                    <div class="quick-icon">

                        <i class="fa-solid fa-certificate"></i>

                    </div>

                    <div class="quick-title">

                        Earned Certificates

                    </div>

                    <div class="quick-text">

                        View and access your earned
                        course certificates.

                    </div>

                </a>

            </div>

        </div>


        <!-- =====================================================
             MY LEARNING
        ====================================================== -->

        <div
            class="d-flex
                   justify-content-between
                   align-items-center
                   mb-3"
        >

            <div>

                <div class="section-title">

                    My Learning

                </div>

                <div class="text-muted small">

                    Continue where you left off.

                </div>

            </div>


            <a
                href="<?= e(
                    base_url(
                        'assan_computer_institute/student/enrolled_courses.php'
                    )
                ) ?>"
                class="dashboard-link"
            >

                View All

                <i class="fa-solid fa-arrow-right ms-1"></i>

            </a>

        </div>


        <div class="row g-4 mb-5">


            <?php if (empty($myCourses)): ?>


                <div class="col-12">

                    <div class="empty-box">

                        <i
                            class="fa-solid fa-book-open fa-2x mb-3"
                        ></i>

                        <h5>

                            No enrolled courses yet

                        </h5>

                        <p class="mb-3">

                            Start learning by choosing a
                            course from our catalog.

                        </p>

                        <a
                            href="<?= e(
                                base_url(
                                    'assan_computer_institute/student/courses.php'
                                )
                            ) ?>"
                            class="btn btn-primary"
                        >

                            Browse Courses

                        </a>

                    </div>

                </div>


            <?php else: ?>


                <?php foreach ($myCourses as $course): ?>


                    <?php

                    $total =
                        (int) $course['total_lessons'];

                    $completed =
                        (int) $course['completed_lessons'];

                    $courseProgress = 0;

                    if ($total > 0) {

                        $courseProgress =
                            (int) round(
                                ($completed / $total) * 100
                            );
                    }


                    $paymentStatus =
                        isset($course['payment_status'])
                            ? $course['payment_status']
                            : 'pending';

                    $accessStatus =
                        isset($course['access_status'])
                            ? $course['access_status']
                            : 'pending';

                    ?>


                    <div class="col-md-6 col-xl-4">

                        <div class="course-card">


                            <!-- COURSE HEADER -->

                            <div
                                class="d-flex
                                       align-items-start
                                       gap-3
                                       mb-3"
                            >

                                <div class="course-icon">

                                    <i
                                        class="fa-solid
                                               fa-laptop-code"
                                    ></i>

                                </div>


                                <div class="flex-grow-1">

                                    <div class="course-title">

                                        <?= e($course['title']) ?>

                                    </div>

                                    <div class="text-muted small">

                                        <?= $total ?>

                                        lessons

                                    </div>

                                </div>

                            </div>


                            <!-- STATUS -->

                            <div class="mb-3">


                                <?php if (
                                    $paymentStatus === 'paid'
                                    && $accessStatus === 'active'
                                ): ?>


                                    <span
                                        class="course-status status-paid"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-circle-check"
                                        ></i>

                                        Enrolled & Active

                                    </span>


                                <?php elseif (
                                    $paymentStatus === 'pending'
                                ): ?>


                                    <span
                                        class="course-status status-pending"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-clock"
                                        ></i>

                                        Payment Pending

                                    </span>


                                <?php elseif (
                                    $accessStatus === 'suspended'
                                ): ?>


                                    <span
                                        class="course-status
                                               status-suspended"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-ban"
                                        ></i>

                                        Access Suspended

                                    </span>


                                <?php else: ?>


                                    <span
                                        class="course-status
                                               status-access-pending"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-hourglass-half"
                                        ></i>

                                        Access Pending

                                    </span>


                                <?php endif; ?>


                            </div>


                            <!-- ACTIVE COURSE PROGRESS -->

                            <?php if (
                                $paymentStatus === 'paid'
                                && $accessStatus === 'active'
                            ): ?>


                                <div
                                    class="mb-2
                                           d-flex
                                           justify-content-between
                                           small"
                                >

                                    <span class="text-muted">

                                        Learning Progress

                                    </span>

                                    <strong>

                                        <?= $courseProgress ?>%

                                    </strong>

                                </div>


                                <div class="progress mb-3">

                                    <div
                                        class="progress-bar
                                               bg-primary"
                                        style="
                                            width:
                                            <?= $courseProgress ?>%
                                        "
                                    ></div>

                                </div>


                                <?php if (
                                    $courseProgress >= 100
                                ): ?>


                                    <a
                                        href="<?= e(
                                            base_url(
                                                'assan_computer_institute/student/course.php?id=' .
                                                (int) $course['course_id']
                                            )
                                        ) ?>"
                                        class="btn btn-primary w-100"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-circle-check
                                                   me-1"
                                        ></i>

                                        Review Course

                                    </a>


                                <?php else: ?>


                                    <a
                                        href="<?= e(
                                            base_url(
                                                'assan_computer_institute/student/course.php?id=' .
                                                (int) $course['course_id']
                                            )
                                        ) ?>"
                                        class="btn btn-primary w-100"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-play
                                                   me-1"
                                        ></i>

                                        Continue Learning

                                    </a>


                                <?php endif; ?>


                            <?php elseif (
                                $paymentStatus === 'pending'
                            ): ?>


                                <a
                                    href="<?= e(
                                        base_url(
                                            'assan_computer_institute/student/enrolled_courses.php'
                                        )
                                    ) ?>"
                                    class="btn btn-warning w-100"
                                >

                                    <i
                                        class="fa-solid
                                               fa-credit-card
                                               me-1"
                                    ></i>

                                    Complete Payment

                                </a>


                            <?php elseif (
                                $accessStatus === 'suspended'
                            ): ?>


                                <button
                                    type="button"
                                    class="btn btn-outline-danger w-100"
                                    disabled
                                >

                                    <i
                                        class="fa-solid
                                               fa-ban
                                               me-1"
                                    ></i>

                                    Access Suspended

                                </button>


                            <?php else: ?>


                                <a
                                    href="<?= e(
                                        base_url(
                                            'assan_computer_institute/student/enrolled_courses.php'
                                        )
                                    ) ?>"
                                    class="btn btn-outline-primary w-100"
                                >

                                    <i
                                        class="fa-solid
                                               fa-clock
                                               me-1"
                                    ></i>

                                    View Enrollment

                                </a>


                            <?php endif; ?>


                        </div>

                    </div>


                <?php endforeach; ?>


            <?php endif; ?>


        </div>


        <!-- =====================================================
             EXPLORE COURSES
        ====================================================== -->

        <div
            class="d-flex
                   justify-content-between
                   align-items-center
                   mb-3"
        >

            <div>

                <div class="section-title">

                    Explore Courses

                </div>

                <div class="text-muted small">

                    Discover more courses available
                    at the institute.

                </div>

            </div>


            <a
                href="<?= e(
                    base_url(
                        'assan_computer_institute/student/courses.php'
                    )
                ) ?>"
                class="dashboard-link"
            >

                View All

                <i class="fa-solid fa-arrow-right ms-1"></i>

            </a>

        </div>


        <div class="row g-4">


            <?php if (empty($availableCourses)): ?>


                <div class="col-12">

                    <div class="empty-box">

                        <i
                            class="fa-solid
                                   fa-graduation-cap
                                   fa-2x
                                   mb-3"
                        ></i>

                        <h5>

                            No courses available

                        </h5>

                        <p class="mb-0">

                            New courses will appear here
                            when they are published.

                        </p>

                    </div>

                </div>


            <?php else: ?>


                <?php foreach ($availableCourses as $course): ?>


                    <?php

                    $isEnrolled =
                        !empty($course['is_enrolled']);

                    $paymentStatus =
                        isset(
                            $course[
                                'enrollment_payment_status'
                            ]
                        )
                            ? $course[
                                'enrollment_payment_status'
                            ]
                            : '';

                    $accessStatus =
                        isset(
                            $course[
                                'enrollment_access_status'
                            ]
                        )
                            ? $course[
                                'enrollment_access_status'
                            ]
                            : '';

                    ?>


                    <div class="col-md-6 col-xl-4">

                        <div class="course-card">


                            <div class="course-icon mb-3">

                                <i
                                    class="fa-solid
                                           fa-graduation-cap"
                                ></i>

                            </div>


                            <div class="course-title mb-2">

                                <?= e($course['title']) ?>

                            </div>


                            <div class="course-description mb-3">

                                <?= e(
                                    mb_strimwidth(
                                        (string)
                                        $course['description'],
                                        0,
                                        130,
                                        '...'
                                    )
                                ) ?>

                            </div>


                            <div
                                class="small
                                       text-muted
                                       mb-3"
                            >

                                <i
                                    class="fa-regular
                                           fa-clock
                                           me-1"
                                ></i>

                                <?= e(
                                    !empty(
                                        $course['duration']
                                    )
                                        ? $course['duration']
                                        : 'Flexible learning'
                                ) ?>


                                <span class="mx-2">
                                    •
                                </span>


                                <?= (int)
                                    $course['total_lessons'] ?>

                                lessons

                            </div>


                            <div
                                class="d-flex
                                       justify-content-between
                                       align-items-center
                                       gap-2"
                            >

                                <strong class="text-primary">

                                    <?= money(
                                        $course['price']
                                    ) ?>

                                </strong>


                                <?php if (
                                    $isEnrolled
                                ): ?>


                                    <?php if (
                                        $paymentStatus === 'paid'
                                        && $accessStatus === 'active'
                                    ): ?>


                                        <a
                                            href="<?= e(
                                                base_url(
                                                    'assan_computer_institute/student/course.php?id=' .
                                                    (int) $course['id']
                                                )
                                            ) ?>"
                                            class="btn btn-outline-primary btn-sm"
                                        >

                                            <i
                                                class="fa-solid
                                                       fa-play
                                                       me-1"
                                            ></i>

                                            Open Course

                                        </a>


                                    <?php elseif (
                                        $paymentStatus === 'pending'
                                    ): ?>


                                        <a
                                            href="<?= e(
                                                base_url(
                                                    'assan_computer_institute/student/enrolled_courses.php'
                                                )
                                            ) ?>"
                                            class="btn btn-warning btn-sm"
                                        >

                                            <i
                                                class="fa-solid
                                                       fa-clock
                                                       me-1"
                                            ></i>

                                            Payment Pending

                                        </a>


                                    <?php elseif (
                                        $accessStatus === 'suspended'
                                    ): ?>


                                        <span
                                            class="course-status
                                                   status-suspended"
                                        >

                                            Suspended

                                        </span>


                                    <?php else: ?>


                                        <a
                                            href="<?= e(
                                                base_url(
                                                    'assan_computer_institute/student/enrolled_courses.php'
                                                )
                                            ) ?>"
                                            class="btn btn-outline-primary btn-sm"
                                        >

                                            View Enrollment

                                        </a>


                                    <?php endif; ?>


                                <?php else: ?>


                                    <a
                                        href="<?= e(
                                            base_url(
                                                'assan_computer_institute/student/enroll.php?course_id=' .
                                                (int) $course['id']
                                            )
                                        ) ?>"
                                        class="btn btn-primary btn-sm"
                                    >

                                        <i
                                            class="fa-solid
                                                   fa-user-plus
                                                   me-1"
                                        ></i>

                                        Enroll Now

                                    </a>


                                <?php endif; ?>


                            </div>


                        </div>

                    </div>


                <?php endforeach; ?>


            <?php endif; ?>


        </div>


        <!-- =====================================================
             PENDING PAYMENT NOTICE
        ====================================================== -->

        <?php if ($pendingPayments > 0): ?>

            <div class="alert alert-warning mt-5">

                <div
                    class="d-flex
                           align-items-center
                           justify-content-between
                           flex-wrap
                           gap-3"
                >

                    <div>

                        <strong>

                            <i
                                class="fa-solid
                                       fa-clock
                                       me-2"
                            ></i>

                            <?= $pendingPayments ?>

                            payment
                            <?= $pendingPayments === 1
                                ? 'is'
                                : 'are' ?>

                            waiting for verification.

                        </strong>

                        <div class="small mt-1">

                            Complete your payment and
                            contact the institute for
                            activation.

                        </div>

                    </div>


                    <a
                        href="<?= e(
                            base_url(
                                'assan_computer_institute/student/payments.php'
                            )
                        ) ?>"
                        class="btn btn-warning"
                    >

                        View Payments

                    </a>

                </div>

            </div>

        <?php endif; ?>


    </div>

</div>


<?php

include dirname(__DIR__) . '/partials/footer.php';

?>


<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student Profile & Account Settings
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];

$pageTitle = 'Profile Settings';

$successMessage = '';
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| Handle Profile and Password Updates
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();

        $action = isset($_POST['action'])
            ? trim($_POST['action'])
            : '';

        /*
        |--------------------------------------------------------------------------
        | Update Personal Information
        |--------------------------------------------------------------------------
        */

        if ($action === 'update_profile') {
            $fullName = isset($_POST['full_name'])
                ? trim($_POST['full_name'])
                : '';

            $email = isset($_POST['email'])
                ? trim($_POST['email'])
                : '';

            $mobile = isset($_POST['mobile'])
                ? trim($_POST['mobile'])
                : '';

            if ($fullName === '' || $email === '') {
                throw new Exception(
                    'Full name and email address are required.'
                );
            }

            if (strlen($fullName) > 150) {
                throw new Exception(
                    'Full name cannot exceed 150 characters.'
                );
            }

            if (
                strlen($email) > 190 ||
                !filter_var($email, FILTER_VALIDATE_EMAIL)
            ) {
                throw new Exception(
                    'Please enter a valid email address.'
                );
            }

            if (strlen($mobile) > 30) {
                throw new Exception(
                    'Mobile number cannot exceed 30 characters.'
                );
            }

            /*
             * Prevent duplicate email addresses.
             */
            $emailCheck = $pdo->prepare(
                "SELECT id
                 FROM users
                 WHERE email = :email
                   AND id <> :user_id
                 LIMIT 1"
            );

            $emailCheck->execute(array(
                ':email' => $email,
                ':user_id' => $userId
            ));

            if ($emailCheck->fetch(PDO::FETCH_ASSOC)) {
                throw new Exception(
                    'This email address is already registered to another account.'
                );
            }

            /*
             * Update only editable student profile fields.
             */
            $update = $pdo->prepare(
                "UPDATE users
                 SET full_name = :full_name,
                     email = :email,
                     mobile = :mobile
                 WHERE id = :user_id
                   AND role = 'student'
                 LIMIT 1"
            );

            $update->execute(array(
                ':full_name' => $fullName,
                ':email' => $email,
                ':mobile' => $mobile !== '' ? $mobile : null,
                ':user_id' => $userId
            ));

            $successMessage =
                'Your personal information has been updated successfully.';
        }

        /*
        |--------------------------------------------------------------------------
        | Change Password
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'change_password') {
            $currentPassword = isset($_POST['current_password'])
                ? (string) $_POST['current_password']
                : '';

            $newPassword = isset($_POST['new_password'])
                ? (string) $_POST['new_password']
                : '';

            $confirmPassword = isset($_POST['confirm_password'])
                ? (string) $_POST['confirm_password']
                : '';

            if (
                $currentPassword === '' ||
                $newPassword === '' ||
                $confirmPassword === ''
            ) {
                throw new Exception(
                    'Please complete all password fields.'
                );
            }

            if (strlen($newPassword) < 8) {
                throw new Exception(
                    'Your new password must contain at least 8 characters.'
                );
            }

            if ($newPassword !== $confirmPassword) {
                throw new Exception(
                    'The new password and confirmation do not match.'
                );
            }

            if ($currentPassword === $newPassword) {
                throw new Exception(
                    'Your new password must be different from your current password.'
                );
            }

            /*
             * Retrieve the current password hash.
             */
            $passwordQuery = $pdo->prepare(
                "SELECT password_hash
                 FROM users
                 WHERE id = :user_id
                   AND role = 'student'
                 LIMIT 1"
            );

            $passwordQuery->execute(array(
                ':user_id' => $userId
            ));

            $passwordRecord = $passwordQuery->fetch(PDO::FETCH_ASSOC);

            if (
                !$passwordRecord ||
                !password_verify(
                    $currentPassword,
                    $passwordRecord['password_hash']
                )
            ) {
                throw new Exception(
                    'Your current password is incorrect.'
                );
            }

            $newPasswordHash = password_hash(
                $newPassword,
                PASSWORD_DEFAULT
            );

            $passwordUpdate = $pdo->prepare(
                "UPDATE users
                 SET password_hash = :password_hash
                 WHERE id = :user_id
                   AND role = 'student'
                 LIMIT 1"
            );

            $passwordUpdate->execute(array(
                ':password_hash' => $newPasswordHash,
                ':user_id' => $userId
            ));

            $successMessage =
                'Your password has been changed successfully.';
        }

        else {
            throw new Exception(
                'Invalid request. Please try again.'
            );
        }

    } catch (PDOException $e) {
        error_log(
            'Student profile database error: ' . $e->getMessage()
        );

        $errorMessage =
            'A database error occurred. Please try again.';

    } catch (Exception $e) {
        $errorMessage = $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| Load Current Student Information
|--------------------------------------------------------------------------
*/

try {
    $profileQuery = $pdo->prepare(
        "SELECT
            id,
            full_name,
            email,
            mobile,
            role,
            status,
            created_at
         FROM users
         WHERE id = :user_id
         LIMIT 1"
    );

    $profileQuery->execute(array(
        ':user_id' => $userId
    ));

    $profile = $profileQuery->fetch(PDO::FETCH_ASSOC);

    if (!$profile) {
        throw new Exception(
            'Student account could not be found.'
        );
    }

} catch (Exception $e) {
    error_log(
        'Student profile loading error: ' . $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to load your profile. Please contact the administrator.'
    );
}

/*
|--------------------------------------------------------------------------
| Display Values
|--------------------------------------------------------------------------
*/

$accountStatus = isset($profile['status'])
    ? strtolower((string) $profile['status'])
    : 'unknown';

$statusClass = $accountStatus === 'active'
    ? 'profile-status-active'
    : 'profile-status-other';

$memberSince = 'Not available';

if (!empty($profile['created_at'])) {
    $createdTimestamp = strtotime($profile['created_at']);

    if ($createdTimestamp !== false) {
        $memberSince = date('d M Y', $createdTimestamp);
    }
}

$initial = strtoupper(
    substr(trim($profile['full_name']), 0, 1)
);

require_once dirname(__DIR__) . '/partials/header.php';

?>

<style>
    .profile-page {
        max-width: 1150px;
        margin: 0 auto;
        padding: 25px 18px 45px;
        color: #1e293b;
    }

    .profile-heading {
        margin-bottom: 25px;
    }

    .profile-heading h1 {
        font-size: 27px;
        font-weight: 750;
        color: #0f2a5f;
        margin: 0 0 7px;
    }

    .profile-heading p {
        color: #64748b;
        font-size: 14px;
        margin: 0;
    }

    .profile-summary {
        display: flex;
        align-items: center;
        gap: 17px;
        padding: 23px;
        margin-bottom: 22px;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        box-shadow: 0 4px 15px rgba(15, 42, 95, 0.04);
    }

    .profile-avatar {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 68px;
        height: 68px;
        flex-shrink: 0;
        border-radius: 50%;
        background: linear-gradient(135deg, #0f2a5f, #2563eb);
        color: #fff;
        font-size: 27px;
        font-weight: 750;
    }

    .profile-summary h2 {
        color: #0f2a5f;
        font-size: 19px;
        font-weight: 750;
        margin: 0 0 5px;
        overflow-wrap: anywhere;
    }

    .profile-summary p {
        margin: 0;
        color: #64748b;
        font-size: 13px;
        overflow-wrap: anywhere;
    }

    .profile-status {
        display: inline-block;
        margin-top: 8px;
        padding: 5px 10px;
        border-radius: 20px;
        background: #dcfce7;
        color: #166534;
        font-size: 11px;
        font-weight: 750;
    }

    .profile-status-other {
        background: #fef3c7;
        color: #92400e;
    }

    .profile-settings {
        display: flex;
        flex-direction: column;
        gap: 13px;
    }

    .profile-setting {
        overflow: hidden;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 13px;
        box-shadow: 0 3px 12px rgba(15, 42, 95, 0.025);
    }

    .profile-setting summary {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 19px 21px;
        cursor: pointer;
        list-style: none;
        user-select: none;
    }

    .profile-setting summary::-webkit-details-marker {
        display: none;
    }

    .profile-setting summary:hover {
        background: #f8fafc;
    }

    .profile-setting[open] summary {
        background: #f8fbff;
        border-bottom: 1px solid #e2e8f0;
    }

    .profile-setting-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 43px;
        height: 43px;
        flex-shrink: 0;
        border-radius: 11px;
        background: #eff6ff;
        color: #2563eb;
        font-size: 17px;
    }

    .profile-setting-heading {
        flex: 1;
        min-width: 0;
    }

    .profile-setting-heading strong {
        display: block;
        color: #0f2a5f;
        font-size: 14px;
        font-weight: 750;
        margin-bottom: 4px;
    }

    .profile-setting-heading span {
        display: block;
        color: #64748b;
        font-size: 12px;
        line-height: 1.5;
    }

    .profile-setting-chevron {
        color: #64748b;
        transition: transform .2s ease;
    }

    .profile-setting[open] .profile-setting-chevron {
        transform: rotate(180deg);
    }

    .profile-setting-content {
        padding: 24px;
    }

    .profile-form .form-label {
        display: block;
        margin-bottom: 7px;
        color: #334155;
        font-size: 13px;
        font-weight: 650;
    }

    .profile-form .form-control {
        width: 100%;
        min-height: 44px;
        border: 1px solid #dbe4f0;
        border-radius: 9px;
        padding: 10px 12px;
        font-size: 13px;
        color: #1e293b;
        background: #fff;
        box-shadow: none;
    }

    .profile-form .form-control:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, .1);
    }

    .profile-form .form-text {
        color: #64748b;
        font-size: 11px;
    }

    .profile-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 11px 17px;
        border: 1px solid #1d4ed8;
        border-radius: 9px;
        background: #1d4ed8;
        color: #fff;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
    }

    .profile-btn:hover {
        background: #1e40af;
        border-color: #1e40af;
        color: #fff;
    }

    .profile-alert {
        padding: 13px 16px;
        border-radius: 10px;
        margin-bottom: 18px;
        font-size: 13px;
    }

    .profile-alert-success {
        background: #ecfdf5;
        border: 1px solid #bbf7d0;
        color: #166534;
    }

    .profile-alert-error {
        background: #fef2f2;
        border: 1px solid #fecaca;
        color: #991b1b;
    }

    .profile-account-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 14px;
    }

    .profile-account-item {
        padding: 15px;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        background: #f8fafc;
        min-width: 0;
    }

    .profile-account-item span {
        display: block;
        margin-bottom: 7px;
        color: #64748b;
        font-size: 11px;
    }

    .profile-account-item strong {
        display: block;
        color: #0f2a5f;
        font-size: 13px;
        overflow-wrap: anywhere;
    }

    .profile-note {
        margin-top: 15px;
        color: #64748b;
        font-size: 12px;
        line-height: 1.6;
    }

    @media (max-width: 600px) {
        .profile-page {
            padding: 18px 10px 30px;
        }

        .profile-heading h1 {
            font-size: 23px;
        }

        .profile-summary {
            padding: 17px;
        }

        .profile-avatar {
            width: 55px;
            height: 55px;
            font-size: 22px;
        }

        .profile-setting summary {
            padding: 15px;
            gap: 11px;
        }

        .profile-setting-icon {
            width: 38px;
            height: 38px;
        }

        .profile-setting-content {
            padding: 17px;
        }

        .profile-account-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="profile-page">

    <div class="profile-heading">
        <h1>
            <i class="fa-solid fa-user-gear"></i>
            Profile Settings
        </h1>
        <p>
            Manage your personal information, security, and account details.
        </p>
    </div>

    <?php if ($successMessage !== ''): ?>
        <div class="profile-alert profile-alert-success">
            <i class="fa-solid fa-circle-check"></i>
            <?= e($successMessage) ?>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>
        <div class="profile-alert profile-alert-error">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= e($errorMessage) ?>
        </div>
    <?php endif; ?>

    <!-- Student Summary -->

    <div class="profile-summary">

        <div class="profile-avatar">
            <?= e($initial) ?>
        </div>

        <div>
            <h2><?= e($profile['full_name']) ?></h2>

            <p><?= e($profile['email']) ?></p>

            <span class="profile-status <?= e($statusClass) ?>">
                <i class="fa-solid fa-circle"></i>
                <?= e(ucfirst($accountStatus)) ?> Account
            </span>
        </div>

    </div>

    <div class="profile-settings">

        <!-- PERSONAL INFORMATION -->

        <details class="profile-setting">

            <summary>
                <span class="profile-setting-icon">
                    <i class="fa-solid fa-user-pen"></i>
                </span>

                <span class="profile-setting-heading">
                    <strong>Personal Information</strong>
                    <span>
                        Update your name, email address, and mobile number.
                    </span>
                </span>

                <i class="fa-solid fa-chevron-down profile-setting-chevron"></i>
            </summary>

            <div class="profile-setting-content">

                <form
                    method="post"
                    action="<?= e(base_url('assan_computer_institute/student/profile.php')) ?>"
                    class="profile-form">

                    <?= csrf_field() ?>

                    <input
                        type="hidden"
                        name="action"
                        value="update_profile">

                    <div class="mb-3">
                        <label for="full_name" class="form-label">
                            Full Name *
                        </label>

                        <input
                            type="text"
                            id="full_name"
                            name="full_name"
                            class="form-control"
                            maxlength="150"
                            autocomplete="name"
                            value="<?= e($profile['full_name']) ?>"
                            required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">
                            Email Address *
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            class="form-control"
                            maxlength="190"
                            autocomplete="email"
                            value="<?= e($profile['email']) ?>"
                            required>
                    </div>

                    <div class="mb-4">
                        <label for="mobile" class="form-label">
                            Mobile Number
                        </label>

                        <input
                            type="tel"
                            id="mobile"
                            name="mobile"
                            class="form-control"
                            maxlength="30"
                            autocomplete="tel"
                            value="<?= e(isset($profile['mobile']) ? $profile['mobile'] : '') ?>"
                            placeholder="Enter your mobile number">
                    </div>

                    <button type="submit" class="profile-btn">
                        <i class="fa-solid fa-floppy-disk"></i>
                        Save Personal Information
                    </button>

                </form>

            </div>

        </details>

        <!-- PASSWORD AND SECURITY -->

        <details class="profile-setting">

            <summary>
                <span class="profile-setting-icon">
                    <i class="fa-solid fa-shield-halved"></i>
                </span>

                <span class="profile-setting-heading">
                    <strong>Password &amp; Security</strong>
                    <span>
                        Change your password to keep your account secure.
                    </span>
                </span>

                <i class="fa-solid fa-chevron-down profile-setting-chevron"></i>
            </summary>

            <div class="profile-setting-content">

                <form
                    method="post"
                    action="<?= e(base_url('assan_computer_institute/student/profile.php')) ?>"
                    class="profile-form">

                    <?= csrf_field() ?>

                    <input
                        type="hidden"
                        name="action"
                        value="change_password">

                    <div class="mb-3">
                        <label for="current_password" class="form-label">
                            Current Password *
                        </label>

                        <input
                            type="password"
                            id="current_password"
                            name="current_password"
                            class="form-control"
                            autocomplete="current-password"
                            required>
                    </div>

                    <div class="mb-3">
                        <label for="new_password" class="form-label">
                            New Password *
                        </label>

                        <input
                            type="password"
                            id="new_password"
                            name="new_password"
                            class="form-control"
                            minlength="8"
                            autocomplete="new-password"
                            required>

                        <div class="form-text">
                            Use at least 8 characters.
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="confirm_password" class="form-label">
                            Confirm New Password *
                        </label>

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            class="form-control"
                            minlength="8"
                            autocomplete="new-password"
                            required>
                    </div>

                    <button type="submit" class="profile-btn">
                        <i class="fa-solid fa-key"></i>
                        Update Password
                    </button>

                </form>

                <div class="profile-note">
                    <i class="fa-solid fa-lock"></i>
                    Your current password is verified before a new password
                    is saved. Passwords are stored as secure hashes.
                </div>

            </div>

        </details>

        <!-- ACCOUNT DETAILS -->

        <details class="profile-setting">

            <summary>
                <span class="profile-setting-icon">
                    <i class="fa-solid fa-id-card"></i>
                </span>

                <span class="profile-setting-heading">
                    <strong>Account Details</strong>
                    <span>
                        View your student ID, account status, and membership date.
                    </span>
                </span>

                <i class="fa-solid fa-chevron-down profile-setting-chevron"></i>
            </summary>

            <div class="profile-setting-content">

                <div class="profile-account-grid">

                    <div class="profile-account-item">
                        <span>Student ID</span>
                        <strong>
                            #<?= (int) $profile['id'] ?>
                        </strong>
                    </div>

                    <div class="profile-account-item">
                        <span>Account Type</span>
                        <strong>
                            <?= e(ucfirst($profile['role'])) ?>
                        </strong>
                    </div>

                    <div class="profile-account-item">
                        <span>Account Status</span>
                        <strong>
                            <?= e(ucfirst($accountStatus)) ?>
                        </strong>
                    </div>

                    <div class="profile-account-item">
                        <span>Member Since</span>
                        <strong>
                            <?= e($memberSince) ?>
                        </strong>
                    </div>

                    <div class="profile-account-item">
                        <span>Registered Email</span>
                        <strong>
                            <?= e($profile['email']) ?>
                        </strong>
                    </div>

                    <div class="profile-account-item">
                        <span>Mobile Number</span>
                        <strong>
                            <?= !empty($profile['mobile'])
                                ? e($profile['mobile'])
                                : 'Not provided' ?>
                        </strong>
                    </div>

                </div>

                <div class="profile-note">
                    <i class="fa-solid fa-circle-info"></i>
                    Student ID, account type, and account status are managed
                    by the system and cannot be changed here.
                </div>

            </div>

        </details>

    </div>

</div>

<script>
document.querySelectorAll('.profile-setting').forEach(function (section) {
    section.addEventListener('toggle', function () {
        if (!section.open) {
            return;
        }

        document.querySelectorAll('.profile-setting').forEach(function (other) {
            if (other !== section) {
                other.open = false;
            }
        });
    });
});
</script>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
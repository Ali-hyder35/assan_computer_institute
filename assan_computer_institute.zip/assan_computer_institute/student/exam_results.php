<?php /* |-------------------------------------------------------------------------- | Assan Computer Institute | Student - All Exam Results |-------------------------------------------------------------------------- */ require_once dirname(__DIR__) . '/config/bootstrap.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];
$pageTitle = 'Exam Results';
try { /* |-------------------------------------------------------------------------- | Load Student Exam Results |-------------------------------------------------------------------------- */
    $stmt = $pdo->prepare(" SELECT ea.id, ea.exam_id, ea.started_at, ea.submitted_at, ea.score, ea.total_marks, ea.percentage, ea.status, ea.result, e.title AS exam_title, e.pass_marks, c.title AS course_title FROM exam_attempts ea INNER JOIN exams e ON e.id = ea.exam_id INNER JOIN courses c ON c.id = e.course_id WHERE ea.user_id = ? ORDER BY COALESCE(ea.submitted_at, ea.started_at) DESC, ea.id DESC ");
    $stmt->execute(array($userId));
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $results = array();
    flash('error', 'Unable to load exam results.');
}
$totalAttempts = count($results);
$passed = 0;
$failed = 0;
$inProgress = 0;
foreach ($results as $result) {
    if ($result['result'] === 'passed') {
        $passed++;
    }
    elseif ($result['result'] === 'failed') {
        $failed++;
    }
    if ($result['status'] === 'in_progress') {
        $inProgress++;
    }
}
require_once dirname(__DIR__) . '/partials/header.php'; ?>
<style>
    :root {
        --lms-primary: #0f2a5f;
        --lms-primary-light: #1e4b8f;
        --lms-accent: #2563eb;
        --lms-bg: #f5f7fb;
        --lms-card: #fff;
        --lms-text: #1e293b;
        --lms-muted: #64748b;
        --lms-border: #e2e8f0;
        --lms-success: #16a34a;
        --lms-danger: #dc2626;
        --lms-warning: #d97706;
        --lms-shadow: 0 8px 25px rgba(15, 42, 95, .08);
    }

    body {
        background: var(--lms-bg);
    }

    .results-page {
        padding: 30px 0 60px;
    }

    .results-header {
        background: linear-gradient(135deg, var(--lms-primary), var(--lms-primary-light));
        color: #fff;
        border-radius: 18px;
        padding: 30px;
        margin-bottom: 25px;
        box-shadow: var(--lms-shadow);
    }

    .results-header h2 {
        margin: 0 0 7px;
        font-weight: 700;
    }

    .results-header p {
        margin: 0;
        color: rgba(255, 255, 255, .8);
    }

    .summary-card {
        background: #fff;
        border: 1px solid var(--lms-border);
        border-radius: 15px;
        padding: 20px;
        box-shadow: var(--lms-shadow);
        height: 100%;
    }

    .summary-icon {
        width: 45px;
        height: 45px;
        border-radius: 12px;
        background: #eff6ff;
        color: var(--lms-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 21px;
        margin-bottom: 12px;
    }

    .summary-card strong {
        display: block;
        color: var(--lms-text);
        font-size: 27px;
    }

    .summary-card span {
        color: var(--lms-muted);
        font-size: 13px;
    }

    .results-table-card {
        background: #fff;
        border: 1px solid var(--lms-border);
        border-radius: 16px;
        padding: 20px;
        box-shadow: var(--lms-shadow);
        margin-top: 25px;
    }

    .results-table th {
        color: var(--lms-muted);
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: .4px;
        border-bottom: 1px solid var(--lms-border);
        white-space: nowrap;
    }

    .results-table td {
        vertical-align: middle;
        color: var(--lms-text);
        border-bottom: 1px solid #f1f5f9;
    }

    .exam-name {
        font-weight: 700;
    }

    .course-name {
        color: var(--lms-muted);
        font-size: 13px;
    }

    .result-badge {
        display: inline-block;
        padding: 6px 11px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 800;
    }

    .result-passed {
        background: #dcfce7;
        color: #166534;
    }

    .result-failed {
        background: #fee2e2;
        color: #991b1b;
    }

    .result-progress {
        background: #fef3c7;
        color: #92400e;
    }

    .view-result {
        background: #eff6ff;
        color: #1d4ed8;
        border-radius: 9px;
        padding: 8px 12px;
        text-decoration: none;
        font-weight: 600;
        font-size: 13px;
    }

    .view-result:hover {
        background: #dbeafe;
        color: #1d4ed8;
    }

    .empty-results {
        text-align: center;
        padding: 55px 20px;
    }

    .empty-results i {
        font-size: 50px;
        color: var(--lms-accent);
    }

    .empty-results h4 {
        margin-top: 15px;
        color: var(--lms-text);
    }

    .empty-results p {
        color: var(--lms-muted);
    }
</style>
<div class="container results-page">
    <div class="results-header">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h2> <i class="bi bi-bar-chart-line me-2"></i> Exam Results </h2>
                <p> View your examination history, marks and performance. </p>
            </div>
            <div> <a href="<?= e(base_url('assan_computer_institute/student/exams.php')) ?>" class="btn btn-light"> <i
                        class="bi bi-journal-check me-1"></i> Available Exams </a> </div>
        </div>
    </div> <?php $flashSuccess = flash('success');
    $flashError = flash('error'); ?> <?php if ($flashSuccess): ?>
        <div class="alert alert-success"> <?= e($flashSuccess) ?> </div> <?php endif; ?> <?php if ($flashError): ?>
        <div class="alert alert-danger"> <?= e($flashError) ?> </div> <?php endif; ?>
    <div class="row g-3">
        <div class="col-lg-3 col-md-6">
            <div class="summary-card">
                <div class="summary-icon"> <i class="bi bi-journal-check"></i> </div> <strong> <?= $totalAttempts ?>
                </strong> <span> Total Attempts </span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="summary-card">
                <div class="summary-icon"> <i class="bi bi-check-circle"></i> </div> <strong style="color:#16a34a;">
                    <?= $passed ?> </strong> <span> Exams Passed </span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="summary-card">
                <div class="summary-icon"> <i class="bi bi-x-circle"></i> </div> <strong style="color:#dc2626;">
                    <?= $failed ?> </strong> <span> Exams Failed </span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="summary-card">
                <div class="summary-icon"> <i class="bi bi-clock"></i> </div> <strong style="color:#d97706;">
                    <?= $inProgress ?> </strong> <span> In Progress </span>
            </div>
        </div>
    </div>
    <div class="results-table-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h5 class="fw-bold mb-1"> Examination History </h5> <small class="text-muted"> All your exam attempts
                    are listed below. </small>
            </div>
        </div> <?php if (empty($results)): ?>
            <div class="empty-results"> <i class="bi bi-bar-chart-line"></i>
                <h4> No Exam Results Yet </h4>
                <p> Once you complete an exam, your result will appear here. </p> <a
                    href="<?= e(base_url('assan_computer_institute/student/exams.php')) ?>" class="btn btn-primary"> Browse
                    Exams </a>
            </div> <?php else: ?>
            <div class="table-responsive">
                <table class="table results-table">
                    <thead>
                        <tr>
                            <th> Exam </th>
                            <th> Course </th>
                            <th> Score </th>
                            <th> Percentage </th>
                            <th> Result </th>
                            <th> Date </th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody> <?php foreach ($results as $result): ?>
                            <tr>
                                <td>
                                    <div class="exam-name"> <?= e($result['exam_title']) ?> </div>
                                </td>
                                <td>
                                    <div class="course-name"> <?= e($result['course_title']) ?> </div>
                                </td>
                                <td> <strong> <?= e($result['score']) ?> / <?= e($result['total_marks']) ?> </strong> </td>
                                <td> <strong> <?= number_format((float) $result['percentage'], 1) ?>% </strong> </td>
                                <td> <?php if ($result['result'] === 'passed'): ?> <span class="result-badge result-passed">
                                            PASSED </span> <?php elseif ($result['result'] === 'failed'): ?> <span
                                            class="result-badge result-failed"> FAILED </span> <?php else: ?> <span
                                            class="result-badge result-progress"> IN PROGRESS </span> <?php endif; ?> </td>
                                <td> <small class="text-muted">
                                        <?= e($result['submitted_at'] ? $result['submitted_at'] : $result['started_at']) ?>
                                    </small> </td>
                                <td> <?php if ($result['status'] === 'submitted' || $result['status'] === 'expired'): ?> <a
                                            href="<?= e(base_url('assan_computer_institute/student/exam_result.php?id=' . (int) $result['id'])) ?>"
                                            class="view-result"> <i class="bi bi-eye me-1"></i> View </a> <?php else: ?> <a
                                            href="<?= e(base_url('assan_computer_institute/student/exam.php?id=' . (int) $result['exam_id'])) ?>"
                                            class="view-result"> Continue </a> <?php endif; ?> </td>
                            </tr> <?php endforeach; ?>
                    </tbody>
                </table>
            </div> <?php endif; ?>
    </div>
</div> <?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
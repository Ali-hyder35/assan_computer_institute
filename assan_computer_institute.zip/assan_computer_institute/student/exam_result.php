<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Student - Exam Result
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login();

$user = current_user();
$userId = (int) $user['id'];

$pageTitle = 'Exam Result';

$attemptId =
    isset($_GET['id'])
        ? (int) $_GET['id']
        : 0;

if ($attemptId <= 0) {

    flash(
        'error',
        'Invalid exam result selected.'
    );

    redirect(
        base_url('assan_computer_institute/student/exam_results.php')
    );
}

/*
|--------------------------------------------------------------------------
| Load Attempt
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        ea.*,
        e.title AS exam_title,
        e.description AS exam_description,
        e.duration_minutes,
        e.pass_marks,
        c.id AS course_id,
        c.title AS course_title
    FROM exam_attempts ea
    INNER JOIN exams e
        ON e.id = ea.exam_id
    INNER JOIN courses c
        ON c.id = e.course_id
    WHERE ea.id = ?
      AND ea.user_id = ?
    LIMIT 1
");

$stmt->execute(array(
    $attemptId,
    $userId
));

$attempt = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$attempt) {

    flash(
        'error',
        'Exam result not found.'
    );

    redirect(
        base_url('assan_computer_institute/student/exam_results.php')
    );
}

/*
|--------------------------------------------------------------------------
| Load Answer Details
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        ea.id,
        ea.question_id,
        ea.selected_option,
        ea.is_correct,
        ea.marks_obtained,

        eq.question_text,
        eq.option_a,
        eq.option_b,
        eq.option_c,
        eq.option_d,
        eq.marks,
        eq.correct_option

    FROM exam_answers ea

    INNER JOIN exam_questions eq
        ON eq.id = ea.question_id

    WHERE ea.attempt_id = ?

    ORDER BY eq.question_order ASC, eq.id ASC
");

$stmt->execute(array($attemptId));

$answers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalQuestions = count($answers);

$correctCount = 0;
$wrongCount = 0;
$unansweredCount = 0;

foreach ($answers as $answer) {

    if (empty($answer['selected_option'])) {

        $unansweredCount++;

    } elseif ((int) $answer['is_correct'] === 1) {

        $correctCount++;

    } else {

        $wrongCount++;
    }
}

$isPassed =
    $attempt['result'] === 'passed';

$pageTitle = $attempt['exam_title'];

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
:root {
    --lms-primary: #0f2a5f;
    --lms-primary-light: #1e4b8f;
    --lms-accent: #2563eb;
    --lms-bg: #f5f7fb;
    --lms-card: #fff;
    --lms-text: #1e293b;
    --lms-muted: #64748b;
    --lms-border: #e2e8f0;
    --lms-success: #16a34a;
    --lms-danger: #dc2626;
    --lms-warning: #d97706;
    --lms-shadow: 0 8px 25px rgba(15,42,95,.08);
}

body {
    background: var(--lms-bg);
}

.result-page {
    padding: 30px 0 60px;
}

.result-header {
    background: linear-gradient(
        135deg,
        var(--lms-primary),
        var(--lms-primary-light)
    );
    color: #fff;
    border-radius: 18px;
    padding: 30px;
    margin-bottom: 25px;
    box-shadow: var(--lms-shadow);
}

.result-header h2 {
    margin: 0 0 7px;
    font-weight: 700;
}

.result-header p {
    margin: 0;
    color: rgba(255,255,255,.8);
}

.result-card {
    background: #fff;
    border: 1px solid var(--lms-border);
    border-radius: 16px;
    padding: 25px;
    box-shadow: var(--lms-shadow);
    margin-bottom: 20px;
}

.result-circle {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    border: 12px solid #e2e8f0;
}

.result-circle strong {
    font-size: 32px;
    color: var(--lms-text);
}

.result-circle.passed {
    border-color: #86efac;
    background: #f0fdf4;
}

.result-circle.failed {
    border-color: #fecaca;
    background: #fef2f2;
}

.result-status {
    display: inline-block;
    padding: 8px 18px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 800;
}

.result-status.passed {
    background: #dcfce7;
    color: #166534;
}

.result-status.failed {
    background: #fee2e2;
    color: #991b1b;
}

.stat-box {
    background: #f8fafc;
    border: 1px solid var(--lms-border);
    border-radius: 12px;
    padding: 18px;
    text-align: center;
}

.stat-box strong {
    display: block;
    color: var(--lms-text);
    font-size: 25px;
}

.stat-box span {
    color: var(--lms-muted);
    font-size: 13px;
}

.question-review {
    border: 1px solid var(--lms-border);
    border-radius: 13px;
    padding: 20px;
    margin-bottom: 15px;
}

.question-review.correct {
    border-left: 5px solid var(--lms-success);
}

.question-review.wrong {
    border-left: 5px solid var(--lms-danger);
}

.question-review.unanswered {
    border-left: 5px solid var(--lms-warning);
}

.question-review h6 {
    color: var(--lms-text);
    font-weight: 700;
    line-height: 1.5;
}

.answer-line {
    padding: 9px 12px;
    background: #f8fafc;
    border-radius: 8px;
    margin-top: 8px;
    color: var(--lms-text);
}

.correct-answer {
    background: #f0fdf4;
    color: #166534;
}

.wrong-answer {
    background: #fef2f2;
    color: #991b1b;
}

.btn-primary-lms {
    background: var(--lms-accent);
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 11px 18px;
    text-decoration: none;
    display: inline-block;
    font-weight: 600;
}

.btn-primary-lms:hover {
    color: #fff;
    background: #1d4ed8;
}
</style>

<div class="container result-page">

    <div class="result-header">

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">

            <div>
                <h2>
                    <i class="bi bi-award me-2"></i>
                    <?= e($attempt['exam_title']) ?>
                </h2>

                <p>
                    <?= e($attempt['course_title']) ?>
                </p>
            </div>

            <div>

                <a
                    href="<?= e(base_url('assan_computer_institute/student/exam_results.php')) ?>"
                    class="btn btn-light"
                >
                    <i class="bi bi-bar-chart-line me-1"></i>
                    All Results
                </a>

            </div>

        </div>

    </div>

    <div class="row">

        <div class="col-lg-4">

            <div class="result-card text-center">

                <div
                    class="result-circle <?= $isPassed ? 'passed' : 'failed' ?>"
                >

                    <strong>
                        <?= number_format((float) $attempt['percentage'], 1) ?>%
                    </strong>

                </div>

                <div>

                    <?php if ($isPassed): ?>

                        <span class="result-status passed">
                            <i class="bi bi-check-circle me-1"></i>
                            PASSED
                        </span>

                    <?php else: ?>

                        <span class="result-status failed">
                            <i class="bi bi-x-circle me-1"></i>
                            FAILED
                        </span>

                    <?php endif; ?>

                </div>

                <div class="mt-4">

                    <h4 class="mb-1">
                        <?= e($attempt['score']) ?>
                        /
                        <?= e($attempt['total_marks']) ?>
                    </h4>

                    <small class="text-muted">
                        Marks Obtained
                    </small>

                </div>

                <hr>

                <div class="text-muted small">

                    Submitted:
                    <?= e($attempt['submitted_at']) ?>

                </div>

                <div class="text-muted small mt-1">

                    Pass Marks:
                    <?= e($attempt['pass_marks']) ?>

                </div>

            </div>

        </div>

        <div class="col-lg-8">

            <div class="result-card">

                <h5 class="fw-bold mb-4">
                    Performance Summary
                </h5>

                <div class="row g-3">

                    <div class="col-md-3 col-6">

                        <div class="stat-box">

                            <strong>
                                <?= $totalQuestions ?>
                            </strong>

                            <span>
                                Questions
                            </span>

                        </div>

                    </div>

                    <div class="col-md-3 col-6">

                        <div class="stat-box">

                            <strong style="color:#16a34a;">
                                <?= $correctCount ?>
                            </strong>

                            <span>
                                Correct
                            </span>

                        </div>

                    </div>

                    <div class="col-md-3 col-6">

                        <div class="stat-box">

                            <strong style="color:#dc2626;">
                                <?= $wrongCount ?>
                            </strong>

                            <span>
                                Wrong
                            </span>

                        </div>

                    </div>

                    <div class="col-md-3 col-6">

                        <div class="stat-box">

                            <strong style="color:#d97706;">
                                <?= $unansweredCount ?>
                            </strong>

                            <span>
                                Unanswered
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="result-card">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>
                <h5 class="fw-bold mb-1">
                    Answer Review
                </h5>

                <small class="text-muted">
                    Review your answers and correct answers.
                </small>
            </div>

        </div>

        <?php if (empty($answers)): ?>

            <div class="alert alert-info">
                No answer details are available.
            </div>

        <?php else: ?>

            <?php foreach ($answers as $index => $answer): ?>

                <?php

                if (empty($answer['selected_option'])) {
                    $reviewClass = 'unanswered';
                } elseif ((int) $answer['is_correct'] === 1) {
                    $reviewClass = 'correct';
                } else {
                    $reviewClass = 'wrong';
                }

                $selectedText = '';

                if ($answer['selected_option'] === 'A') {
                    $selectedText = $answer['option_a'];
                } elseif ($answer['selected_option'] === 'B') {
                    $selectedText = $answer['option_b'];
                } elseif ($answer['selected_option'] === 'C') {
                    $selectedText = $answer['option_c'];
                } elseif ($answer['selected_option'] === 'D') {
                    $selectedText = $answer['option_d'];
                }

                $correctText = '';

                if ($answer['correct_option'] === 'A') {
                    $correctText = $answer['option_a'];
                } elseif ($answer['correct_option'] === 'B') {
                    $correctText = $answer['option_b'];
                } elseif ($answer['correct_option'] === 'C') {
                    $correctText = $answer['option_c'];
                } elseif ($answer['correct_option'] === 'D') {
                    $correctText = $answer['option_d'];
                }

                ?>

                <div class="question-review <?= $reviewClass ?>">

                    <h6>

                        <span class="text-primary">
                            Q<?= $index + 1 ?>.
                        </span>

                        <?= nl2br(e($answer['question_text'])) ?>

                    </h6>

                    <?php if ($answer['selected_option']): ?>

                        <div class="answer-line
                            <?= (int) $answer['is_correct'] === 1
                                ? 'correct-answer'
                                : 'wrong-answer'
                            ?>"
                        >

                            <strong>Your Answer:</strong>

                            <?= e($answer['selected_option']) ?>.
                            <?= e($selectedText) ?>

                        </div>

                    <?php else: ?>

                        <div class="answer-line">

                            <strong>
                                Your Answer:
                            </strong>

                            Not Answered

                        </div>

                    <?php endif; ?>

                    <div class="answer-line correct-answer">

                        <strong>
                            Correct Answer:
                        </strong>

                        <?= e($answer['correct_option']) ?>.
                        <?= e($correctText) ?>

                    </div>

                    <div class="text-end mt-2">

                        <small class="text-muted">

                            Marks:
                            <?= e($answer['marks_obtained']) ?>
                            /
                            <?= e($answer['marks']) ?>

                        </small>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

    <div class="text-center">

        <a
            href="<?= e(base_url('assan_computer_institute/student/exams.php')) ?>"
            class="btn-primary-lms me-2"
        >
            <i class="bi bi-journal-check me-1"></i>
            Back to Exams
        </a>

        <a
            href="<?= e(base_url('assan_computer_institute/student/dashboard.php')) ?>"
            class="btn btn-outline-secondary"
        >
            Dashboard
        </a>

    </div>

</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
CREATE DATABASE IF NOT EXISTS assan_computer_institute CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE assan_computer_institute;

CREATE TABLE IF NOT EXISTS users(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 mobile VARCHAR(30) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('student','admin') NOT NULL DEFAULT 'student',
 status ENUM('active','blocked') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS courses(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(180) NOT NULL,
 slug VARCHAR(190) NOT NULL UNIQUE,
 description TEXT,
 price DECIMAL(12,2) NOT NULL,
 duration VARCHAR(80),
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS enrollments(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 course_id INT UNSIGNED NOT NULL,
 order_ref VARCHAR(60) NOT NULL UNIQUE,
 amount DECIMAL(12,2) NOT NULL,
 payment_method ENUM('jazzcash','easypaisa','bank') NOT NULL,
 payment_status ENUM('pending','paid','failed','cancelled','refunded') DEFAULT 'pending',
 access_status ENUM('pending','active','suspended') DEFAULT 'pending',
 gateway_txn_id VARCHAR(120),
 gateway_response TEXT,
 paid_at DATETIME,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE RESTRICT,
 INDEX(user_id), INDEX(payment_status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payment_transactions(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 enrollment_id BIGINT UNSIGNED NOT NULL,
 gateway VARCHAR(30) NOT NULL,
 merchant_reference VARCHAR(120) NOT NULL,
 gateway_transaction_id VARCHAR(120),
 request_payload MEDIUMTEXT,
 response_payload MEDIUMTEXT,
 status VARCHAR(40) DEFAULT 'initiated',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NULL,
 action VARCHAR(120) NOT NULL,
 details TEXT,
 ip_address VARCHAR(45),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX(user_id)
) ENGINE=InnoDB;

INSERT IGNORE INTO courses(title,slug,description,price,duration) VALUES
('Web Development','web-development','HTML, CSS, JavaScript, Bootstrap, PHP and practical projects.',18000,'8 weeks'),
('Microsoft Office','microsoft-office','Word, Excel, PowerPoint and workplace productivity.',12000,'6 weeks'),
('Database Management','database-management','MySQL, SQL, database design and administration fundamentals.',30000,'10 weeks'),
('Data Analytics','data-analytics','Excel, Power BI, Tableau and practical analytics workflows.',25000,'10 weeks'),
('Python','python','Python programming, problem solving and practical projects.',15000,'8 weeks'),
('Networking Basics','networking-basics','LAN/WAN, IP addressing, subnetting and troubleshooting.',20000,'8 weeks');

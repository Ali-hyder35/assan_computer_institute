<?php



/*

|--------------------------------------------------------------------------

| Assan Computer Institute

| Main Homepage

|--------------------------------------------------------------------------

*/



$baseUrl = '/assan_computer_institute';



function site_url($path = '')

{

    global $baseUrl;



    $base = rtrim($baseUrl, '/');

    $path = ltrim($path, '/');



    if ($path === '') {

        return $base . '/';

    }



    return $base . '/' . $path;

}



/*

|--------------------------------------------------------------------------

| Direct URLs

|--------------------------------------------------------------------------

| These are intentionally kept absolute so Apache does not create

| incorrect URLs such as ".../student/login.php".

*/



$studentLoginUrl    = '/assan_computer_institute/student/login.php';

$studentRegisterUrl = '/assan_computer_institute/student/register.php';

$studentDashboardUrl = '/assan_computer_institute/student/dashboard.php';

$adminLoginUrl      = '/assan_computer_institute/admin/login.php';




// Load the existing application configuration so the homepage can read
// the same database used by the admin course-management page.
require_once __DIR__ . '/config/bootstrap.php';

$homepageCourses = array();

try {
    $courseStmt = $pdo->prepare(
        "SELECT id, title, description, price
         FROM courses
         WHERE active = 1
         ORDER BY id DESC"
    );
    $courseStmt->execute();
    $homepageCourses = $courseStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Keep the homepage available if the course query fails.
    $homepageCourses = array();
}

function homepage_course_icon($title)
{
    $title = strtolower((string) $title);

    if (strpos($title, 'web') !== false || strpos($title, 'html') !== false) {
        return 'fa-solid fa-code';
    }
    if (strpos($title, 'office') !== false || strpos($title, 'word') !== false) {
        return 'fa-solid fa-file-word';
    }
    if (strpos($title, 'database') !== false || strpos($title, 'sql') !== false) {
        return 'fa-solid fa-database';
    }
    if (strpos($title, 'analytics') !== false || strpos($title, 'data') !== false) {
        return 'fa-solid fa-chart-line';
    }
    if (strpos($title, 'python') !== false) {
        return 'fa-brands fa-python';
    }
    if (strpos($title, 'network') !== false) {
        return 'fa-solid fa-network-wired';
    }

    return 'fa-solid fa-laptop-code';
}
?>

<!DOCTYPE html>

<html lang="en">



<head>



    <meta charset="UTF-8">



    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <title>Assan Computer Institute | Learn Computer Skills</title>



    <meta

        name="description"

        content="Assan Computer Institute offers professional computer courses including Web Development, Microsoft Office, Database Management, Data Analytics, Python and Networking."

    >



    <link

        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"

        rel="stylesheet"

    >



    <link

        rel="stylesheet"

        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"

    >





<style>



/* =========================================================

   PROFESSIONAL LMS COLOR SYSTEM

\========================================================= */



:root {

    --lms-primary: #0f2a5f;

    --lms-primary-light: #1e4b8f;

    --lms-accent: #2563eb;

    --lms-accent-hover: #1d4ed8;



    --lms-bg: #f5f7fb;

    --lms-card: #ffffff;



    --lms-text: #1e293b;

    --lms-muted: #64748b;



    --lms-border: #e2e8f0;



    --lms-success: #16a34a;



    --lms-shadow:

        0 8px 25px rgba(15, 42, 95, 0.08);

}





/* =========================

   GENERAL

\========================= */



html {

    scroll-behavior: smooth;

}



body {

    font-family: Arial, Helvetica, sans-serif;

    background: var(--lms-bg);

    color: var(--lms-text);

}





/* =========================

   NAVBAR

\========================= */



.navbar {

    background: var(--lms-primary);

    padding: 13px 0;

    box-shadow: 0 4px 18px rgba(15, 42, 95, 0.16);

}



.navbar-brand {

    font-size: 24px;

    font-weight: 700;

    color: #fff !important;

}



.navbar-brand span {

    color: #60a5fa;

}



.navbar-nav .nav-link {

    color: #e8eefb !important;

    font-weight: 500;

    margin-left: 12px;

    transition: 0.25s ease;

}



.navbar-nav .nav-link:hover {

    color: #60a5fa !important;

}





/* =========================

   LOGIN BUTTON

\========================= */



.btn-login {

    background: var(--lms-accent);

    color: #fff !important;

    padding: 9px 18px;

    border-radius: 8px;

    text-decoration: none;

    font-weight: 600;

    margin-left: 10px;

    display: inline-block;

    transition: 0.25s ease;

}



.btn-login:hover {

    background: var(--lms-accent-hover);

    color: #fff !important;

    transform: translateY(-1px);

}





/* =========================

   REGISTER BUTTON

\========================= */



.btn-register {

    border: 1px solid rgba(255,255,255,0.65);

    color: #fff !important;

    padding: 8px 18px;

    border-radius: 8px;

    text-decoration: none;

    font-weight: 600;

    margin-left: 8px;

    display: inline-block;

    transition: 0.25s ease;

}



.btn-register:hover {

    background: #fff;

    border-color: #fff;

    color: var(--lms-primary) !important;

}





/* =========================

   HERO

\========================= */



.hero {

    background:

        linear-gradient(

            135deg,

            var(--lms-primary) 0%,

            var(--lms-primary-light) 55%,

            #2563eb 100%

        );



    color: #fff;

    padding: 100px 0;

}



.hero h1 {

    font-size: 48px;

    font-weight: 800;

    line-height: 1.2;

}



.hero h1 span {

    color: #93c5fd;

}



.hero p {

    font-size: 18px;

    line-height: 1.8;

    color: #dbeafe;

    max-width: 650px;

}



.hero-buttons {

    margin-top: 30px;

}





/* =========================

   PRIMARY CUSTOM BUTTON

\========================= */



.btn-primary-custom {

    background: var(--lms-accent);

    border: none;

    color: #fff;

    padding: 13px 25px;

    border-radius: 8px;

    font-weight: 600;

    text-decoration: none;

    display: inline-block;

    transition: 0.25s ease;

}



.btn-primary-custom:hover {

    background: var(--lms-accent-hover);

    color: #fff;

    transform: translateY(-2px);

}





/* =========================

   OUTLINE BUTTON

\========================= */



.btn-outline-custom {

    border: 1px solid rgba(255,255,255,0.7);

    color: #fff;

    padding: 12px 25px;

    border-radius: 8px;

    font-weight: 600;

    text-decoration: none;

    display: inline-block;

    margin-left: 10px;

    transition: 0.25s ease;

}



.btn-outline-custom:hover {

    background: #fff;

    border-color: #fff;

    color: var(--lms-primary);

}





/* =========================

   HERO BOX

\========================= */



.hero-box {

    background: rgba(255,255,255,0.09);

    border: 1px solid rgba(255,255,255,0.18);

    border-radius: 16px;

    padding: 35px;

    backdrop-filter: blur(8px);

}



.hero-box i {

    font-size: 55px;

    color: #93c5fd;

    margin-bottom: 20px;

}





/* =========================

   SECTIONS

\========================= */



.section {

    padding: 75px 0;

}



.section-title {

    text-align: center;

    margin-bottom: 50px;

}



.section-title h2 {

    color: var(--lms-primary);

    font-size: 36px;

    font-weight: 700;

}



.section-title p {

    color: var(--lms-muted);

}





/* =========================

   COURSE CARDS

\========================= */



.course-card {

    background: var(--lms-card);

    border: 1px solid var(--lms-border);

    border-radius: 14px;

    overflow: hidden;

    box-shadow: var(--lms-shadow);

    height: 100%;

    transition: 0.25s ease;

}



.course-card:hover {

    transform: translateY(-6px);

    box-shadow:

        0 15px 35px rgba(15, 42, 95, 0.12);

}



.course-icon {

    height: 130px;



    background:

        linear-gradient(

            135deg,

            var(--lms-primary),

            var(--lms-primary-light)

        );



    display: flex;

    align-items: center;

    justify-content: center;

}



.course-icon i {

    font-size: 48px;

    color: #fff;

}



.course-body {

    padding: 25px;

}



.course-body h4 {

    color: var(--lms-primary);

    font-weight: 700;

}



.course-body p {

    color: var(--lms-muted);

    min-height: 60px;

}



.price {

    color: var(--lms-accent);

    font-size: 24px;

    font-weight: 700;

    margin-bottom: 15px;

}





/* =========================

   COURSE BUTTON

\========================= */



.btn-course {

    width: 100%;

    background: var(--lms-primary);

    color: #fff;

    border: none;

    padding: 11px;

    border-radius: 8px;

    font-weight: 600;

    text-decoration: none;

    display: inline-block;

    text-align: center;

    transition: 0.25s ease;

}



.btn-course:hover {

    background: var(--lms-accent);

    color: #fff;

}





/* =========================

   HOW IT WORKS

\========================= */



.step-card {

    background: var(--lms-card);

    border: 1px solid var(--lms-border);

    border-radius: 14px;

    padding: 30px;

    text-align: center;

    height: 100%;

    box-shadow: var(--lms-shadow);

}



.step-number {

    width: 60px;

    height: 60px;



    background:

        linear-gradient(

            135deg,

            var(--lms-primary),

            var(--lms-accent)

        );



    color: #fff;

    border-radius: 50%;



    display: flex;

    align-items: center;

    justify-content: center;



    margin: 0 auto 20px;



    font-size: 23px;

    font-weight: 700;

}



.step-card h4 {

    color: var(--lms-primary);

    font-weight: 700;

}





/* =========================

   PRICING

\========================= */



.pricing-box {

    background: var(--lms-card);

    border: 1px solid var(--lms-border);

    border-radius: 16px;

    padding: 35px;

    text-align: center;

    box-shadow: var(--lms-shadow);

    height: 100%;

}



.pricing-box h3 {

    color: var(--lms-primary);

    font-weight: 700;

}



.pricing-price {

    font-size: 35px;

    font-weight: 800;

    color: var(--lms-accent);

    margin: 20px 0;

}



.pricing-box ul {

    padding: 0;

    list-style: none;

    text-align: left;

}



.pricing-box li {

    margin: 12px 0;

    color: var(--lms-muted);

}



.pricing-box li i {

    color: var(--lms-success);

    margin-right: 8px;

}





/* =========================

   TESTIMONIAL

\========================= */



.testimonial {

    background: var(--lms-card);

    border: 1px solid var(--lms-border);

    padding: 30px;

    border-radius: 14px;

    box-shadow: var(--lms-shadow);

    height: 100%;

}



.testimonial p {

    color: var(--lms-muted);

    line-height: 1.8;

}



.testimonial h5 {

    color: var(--lms-primary);

    font-weight: 700;

}





/* =========================

   FAQ

\========================= */



.accordion-item {

    border: 1px solid var(--lms-border);

    border-radius: 10px !important;

    overflow: hidden;

}



.accordion-button {

    font-weight: 600;

    color: var(--lms-primary);

    background: #fff;

}



.accordion-button:not(.collapsed) {

    background: var(--lms-primary);

    color: #fff;

    box-shadow: none;

}



.accordion-button:focus {

    box-shadow: none;

    border-color: var(--lms-border);

}





/* =========================

   PAYMENT

\========================= */



.payment-box {

    background: var(--lms-card);

    border: 1px solid var(--lms-border);

    border-radius: 16px;

    padding: 35px;

    box-shadow: var(--lms-shadow);

}



.payment-method {

    border: 1px solid var(--lms-border);

    border-radius: 10px;

    padding: 20px;

    margin-bottom: 15px;

    background: #fff;

    transition: 0.2s ease;

}



.payment-method:hover {

    border-color: #bfdbfe;

    background: #f8fbff;

}



.payment-method h5 {

    color: var(--lms-primary);

    font-weight: 700;

}



.payment-method strong {

    color: var(--lms-accent);

}





/* =========================

   CONTACT

\========================= */



.contact-box {

    background:

        linear-gradient(

            135deg,

            var(--lms-primary),

            var(--lms-primary-light)

        );



    color: #fff;

    border-radius: 18px;

    padding: 40px;

}



.contact-box h3 {

    font-weight: 700;

}



.contact-item {

    margin: 20px 0;

}



.contact-item i {

    width: 35px;

    color: #93c5fd;

}





/* =========================

   FOOTER

\========================= */



footer {

    background: #0b1f47;

    color: #fff;

    padding: 55px 0 20px;

}



footer h5 {

    font-size: 20px;

    font-weight: 700;

    margin-bottom: 20px;

}



footer p {

    color: #b9c7df;

    line-height: 1.8;

}



footer ul {

    padding: 0;

    list-style: none;

}



footer ul li {

    margin-bottom: 10px;

}



footer ul li a {

    color: #b9c7df;

    text-decoration: none;

    transition: 0.2s ease;

}



footer ul li a:hover {

    color: #60a5fa;

}



.footer-bottom {

    border-top: 1px solid rgba(255,255,255,0.12);

    margin-top: 35px;

    padding-top: 20px;

    text-align: center;

    color: #94a3b8;

}





/* =========================

   SECTION BACKGROUNDS

\========================= */



section[style*="background:#eef2fb"] {

    background: #eef3f9 !important;

}





/* =========================

   BOOTSTRAP OVERRIDES

\========================= */



.btn-primary {

    background-color: var(--lms-accent);

    border-color: var(--lms-accent);

}



.btn-primary:hover {

    background-color: var(--lms-accent-hover);

    border-color: var(--lms-accent-hover);

}





/* =========================

   RESPONSIVE

\========================= */



@media (max-width: 991px) {



    .navbar-nav {

        margin-top: 15px;

    }



    .navbar-nav .nav-link {

        margin-left: 0;

        padding: 8px 0;

    }



    .btn-login,

    .btn-register {

        margin: 8px 5px 0 0;

    }



    .hero {

        padding: 70px 0;

    }



    .hero h1 {

        font-size: 38px;

    }



}





@media (max-width: 576px) {



    .hero h1 {

        font-size: 32px;

    }



    .hero p {

        font-size: 16px;

    }



    .btn-outline-custom {

        margin-left: 0;

        margin-top: 10px;

    }



    .section {

        padding: 55px 0;

    }



}



</style>





</head>



<body>



<!-- =========================================================

     NAVBAR

\========================================================= -->



<nav class="navbar navbar-expand-lg navbar-dark sticky-top">



    <div class="container">



        <a class="navbar-brand" href="<?= site_url(); ?>">

            Assan <span>Computer Institute</span>

        </a>



        <button

            class="navbar-toggler"

            type="button"

            data-bs-toggle="collapse"

            data-bs-target="#mainNavbar"

            aria-controls="mainNavbar"

            aria-expanded="false"

            aria-label="Toggle navigation"

        >

            <span class="navbar-toggler-icon"></span>

        </button>



        <div class="collapse navbar-collapse" id="mainNavbar">



            <ul class="navbar-nav ms-auto align-items-lg-center">



                <li class="nav-item">

                    <a class="nav-link" href="<?= site_url(); ?>">

                        Home

                    </a>

                </li>



                <li class="nav-item">

                    <a class="nav-link" href="#courses">

                        Courses

                    </a>

                </li>



                <li class="nav-item">

                    <a class="nav-link" href="#how-it-works">

                        How It Works

                    </a>

                </li>



                <li class="nav-item">

                    <a class="nav-link" href="#pricing">

                        Pricing

                    </a>

                </li>



                <li class="nav-item">

                    <a class="nav-link" href="#faq">

                        FAQ

                    </a>

                </li>



                <li class="nav-item">

                    <a class="nav-link" href="#contact">

                        Contact

                    </a>

                </li>



                <!-- IMPORTANT:

                     Direct absolute URL -->

                <li class="nav-item">

                    <a

                        class="btn-login"

                        href="<?= htmlspecialchars($studentLoginUrl); ?>"

                    >

                        <i class="fa-solid fa-right-to-bracket me-1"></i>

                        Student Login

                    </a>

                </li>



                <li class="nav-item">

                    <a

                        class="btn-register"

                        href="<?= htmlspecialchars($studentRegisterUrl); ?>"

                    >

                        Register

                    </a>

                </li>



            </ul>



        </div>



    </div>



</nav>





<!-- =========================================================

     HERO

\========================================================= -->



<section class="hero">



    <div class="container">



        <div class="row align-items-center g-5">



            <div class="col-lg-7">



                <h1>

                    Learn Computer Skills

                    <span>Build Your Future</span>

                </h1>



                <p>

                    Welcome to Assan Computer Institute.

                    Learn practical computer skills through

                    professional courses designed for students,

                    beginners and working professionals.

                </p>



                <div class="hero-buttons">



                    <a

                        href="#courses"

                        class="btn-primary-custom"

                    >

                        <i class="fa-solid fa-book-open me-2"></i>

                        Explore Courses

                    </a>



                    <!-- Direct login URL -->

                    <a

                        href="<?= htmlspecialchars($studentLoginUrl); ?>"

                        class="btn-outline-custom"

                    >

                        <i class="fa-solid fa-user me-2"></i>

                        Student Login

                    </a>



                </div>



            </div>



            <div class="col-lg-5">



                <div class="hero-box text-center">



                    <i class="fa-solid fa-laptop-code"></i>



                    <h3>

                        Practical Computer Education

                    </h3>



                    <p>

                        Learn modern computer technologies

                        with practical examples and

                        project-based training.

                    </p>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     COURSES

\========================================================= -->



<section class="section" id="courses">



    <div class="container">



        <div class="section-title">



            <h2>Our Courses</h2>



            <p>

                Choose a course and start learning today.

            </p>



        </div>



        <div class="row g-4">
            <?php if (!empty($homepageCourses)): ?>
                <?php foreach ($homepageCourses as $course): ?>
                    <?php
                        $courseTitle = isset($course['title']) ? $course['title'] : 'Course';
                        $courseDescription = isset($course['description']) ? trim((string) $course['description']) : '';
                        $coursePrice = isset($course['price']) ? (float) $course['price'] : 0;
                        $courseIcon = homepage_course_icon($courseTitle);
                    ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="course-card">
                            <div class="course-icon">
                                <i class="<?= htmlspecialchars($courseIcon, ENT_QUOTES, 'UTF-8'); ?>"></i>
                            </div>
                            <div class="course-body">
                                <h4><?= htmlspecialchars($courseTitle, ENT_QUOTES, 'UTF-8'); ?></h4>
                                <p>
                                    <?= htmlspecialchars(
                                        $courseDescription !== '' ? $courseDescription : 'Explore this course and develop practical computer skills.',
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>
                                </p>
                                <div class="price">
                                    Rs. <?= number_format($coursePrice, 0); ?>
                                </div>
                                <a
                                    href="<?= htmlspecialchars($studentRegisterUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                    class="btn-course"
                                >
                                    Enroll Now
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="course-card p-4 text-center">
                        <h4 class="mb-2">No Courses Available Yet</h4>
                        <p class="mb-0">Please check back soon for available courses.</p>
                    </div>
                </div>
            <?php endif; ?>




        </div>



    </div>



</section>





<!-- =========================================================

     HOW IT WORKS

\========================================================= -->



<section

    class="section"

    id="how-it-works"

    style="background:#eef2fb;"

>



    <div class="container">



        <div class="section-title">



            <h2>How Enrollment Works</h2>



            <p>

                Start your course in a few simple steps.

            </p>



        </div>



        <div class="row g-4">



            <div class="col-lg-3 col-md-6">



                <div class="step-card">



                    <div class="step-number">1</div>



                    <h4>Create Account</h4>



                    <p>

                        Register as a student using

                        your name, mobile number,

                        email and password.

                    </p>



                </div>



            </div>



            <div class="col-lg-3 col-md-6">



                <div class="step-card">



                    <div class="step-number">2</div>



                    <h4>Select Course</h4>



                    <p>

                        Select the computer course

                        you want to study.

                    </p>



                </div>



            </div>



            <div class="col-lg-3 col-md-6">



                <div class="step-card">



                    <div class="step-number">3</div>



                    <h4>Make Payment</h4>



                    <p>

                        Pay through JazzCash,

                        Easypaisa or Bank Transfer.

                    </p>



                </div>



            </div>



            <div class="col-lg-3 col-md-6">



                <div class="step-card">



                    <div class="step-number">4</div>



                    <h4>Start Learning</h4>



                    <p>

                        After payment verification,

                        access your course from

                        your student dashboard.

                    </p>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     PRICING

\========================================================= -->



<section class="section" id="pricing">



    <div class="container">



        <div class="section-title">



            <h2>Course Pricing</h2>



            <p>

                Transparent course fees with multiple payment options.

            </p>



        </div>



        <div class="row g-4">



            <div class="col-lg-4 col-md-6">



                <div class="pricing-box">



                    <h3>Microsoft Office</h3>



                    <div class="pricing-price">

                        Rs. 12,000

                    </div>



                    <ul>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            MS Word

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            MS Excel

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            PowerPoint

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            Practical Exercises

                        </li>



                    </ul>



                    <a

                        href="<?= htmlspecialchars($studentRegisterUrl); ?>"

                        class="btn-course"

                    >

                        Register Now

                    </a>



                </div>



            </div>





            <div class="col-lg-4 col-md-6">



                <div class="pricing-box">



                    <h3>Python</h3>



                    <div class="pricing-price">

                        Rs. 15,000

                    </div>



                    <ul>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            Python Basics

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            Functions

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            OOP

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            Practical Projects

                        </li>



                    </ul>



                    <a

                        href="<?= htmlspecialchars($studentRegisterUrl); ?>"

                        class="btn-course"

                    >

                        Register Now

                    </a>



                </div>



            </div>





            <div class="col-lg-4 col-md-6">



                <div class="pricing-box">



                    <h3>Web Development</h3>



                    <div class="pricing-price">

                        Rs. 18,000

                    </div>



                    <ul>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            HTML & CSS

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            Bootstrap

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            JavaScript

                        </li>



                        <li>

                            <i class="fa-solid fa-check"></i>

                            PHP & MySQL

                        </li>



                    </ul>



                    <a

                        href="<?= htmlspecialchars($studentRegisterUrl); ?>"

                        class="btn-course"

                    >

                        Register Now

                    </a>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     TESTIMONIALS

\========================================================= -->



<section

    class="section"

    style="background:#eef2fb;"

>



    <div class="container">



        <div class="section-title">



            <h2>Student Feedback</h2>



            <p>

                What students say about their learning experience.

            </p>



        </div>



        <div class="row g-4">



            <div class="col-md-4">



                <div class="testimonial">



                    <p>

                        "The practical approach helped me

                        understand computer concepts much

                        more easily."

                    </p>



                    <h5>

                        Amna Zain

                    </h5>



                </div>



            </div>



            <div class="col-md-4">



                <div class="testimonial">



                    <p>

                        "The course structure is easy to follow

                        and includes practical exercises."

                    </p>



                    <h5>

                        Haris Nadeem

                    </h5>



                </div>



            </div>



            <div class="col-md-4">



                <div class="testimonial">



                    <p>

                        "I was able to improve my computer

                        skills through regular practice."

                    </p>



                    <h5>

                        Umer Ali

                    </h5>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     FAQ

\========================================================= -->



<section class="section" id="faq">



    <div class="container">



        <div class="section-title">



            <h2>Frequently Asked Questions</h2>



            <p>

                Common questions about our courses.

            </p>



        </div>



        <div class="accordion" id="faqAccordion">



            <div class="accordion-item mb-3">



                <h2 class="accordion-header">



                    <button

                        class="accordion-button"

                        type="button"

                        data-bs-toggle="collapse"

                        data-bs-target="#faqOne"

                    >

                        How can I register?

                    </button>



                </h2>



                <div

                    id="faqOne"

                    class="accordion-collapse collapse show"

                    data-bs-parent="#faqAccordion"

                >



                    <div class="accordion-body">



                        Click the Register button,

                        create your student account

                        and then select your course.



                    </div>



                </div>



            </div>





            <div class="accordion-item mb-3">



                <h2 class="accordion-header">



                    <button

                        class="accordion-button collapsed"

                        type="button"

                        data-bs-toggle="collapse"

                        data-bs-target="#faqTwo"

                    >

                        Which payment methods are available?

                    </button>



                </h2>



                <div

                    id="faqTwo"

                    class="accordion-collapse collapse"

                    data-bs-parent="#faqAccordion"

                >



                    <div class="accordion-body">



                        You can make payment through

                        Easypaisa, JazzCash or Bank Transfer.



                    </div>



                </div>



            </div>





            <div class="accordion-item mb-3">



                <h2 class="accordion-header">



                    <button

                        class="accordion-button collapsed"

                        type="button"

                        data-bs-toggle="collapse"

                        data-bs-target="#faqThree"

                    >

                        When will I get course access?

                    </button>



                </h2>



                <div

                    id="faqThree"

                    class="accordion-collapse collapse"

                    data-bs-parent="#faqAccordion"

                >



                    <div class="accordion-body">



                        After your payment is verified,

                        your course access can be activated

                        through the student system.



                    </div>



                </div>



            </div>





            <div class="accordion-item">



                <h2 class="accordion-header">



                    <button

                        class="accordion-button collapsed"

                        type="button"

                        data-bs-toggle="collapse"

                        data-bs-target="#faqFour"

                    >

                        Can I use my own laptop?

                    </button>



                </h2>



                <div

                    id="faqFour"

                    class="accordion-collapse collapse"

                    data-bs-parent="#faqAccordion"

                >



                    <div class="accordion-body">



                        Yes. Students can use their own laptops

                        for practical learning and exercises.



                    </div>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     PAYMENT

\========================================================= -->



<section

    class="section"

    id="payment"

    style="background:#eef2fb;"

>



    <div class="container">



        <div class="section-title">



            <h2>Payment Methods</h2>



            <p>

                Select any available payment method

                when enrolling in a course.

            </p>



        </div>



        <div class="row justify-content-center">



            <div class="col-lg-8">



                <div class="payment-box">



                    <!-- Easypaisa -->



                    <div class="payment-method">



                        <h5>

                            <i class="fa-solid fa-mobile-screen-button me-2"></i>

                            Easypaisa

                        </h5>



                        <p class="mb-0">



                            Account Name:

                            <strong>Dummy</strong>



                            <br>



                            Account Number:

                            <strong>Dummy</strong>



                        </p>



                    </div>





                    <!-- JazzCash -->



                    <div class="payment-method">



                        <h5>

                            <i class="fa-solid fa-mobile-screen-button me-2"></i>

                            JazzCash

                        </h5>



                        <p class="mb-0">



                            Account Name:

                            <strong>Dummy</strong>



                        </p>



                    </div>





                    <!-- Bank -->



                    <div class="payment-method">



                        <h5>

                            <i class="fa-solid fa-building-columns me-2"></i>

                            Bank Transfer

                        </h5>



                        <p class="mb-0">



                            Bank transfer details will

                            be provided during enrollment.



                        </p>



                    </div>





                    <div class="text-center mt-4">



                        <a

                            href="<?= htmlspecialchars($studentRegisterUrl); ?>"

                            class="btn-primary-custom"

                        >

                            Continue Registration

                        </a>



                    </div>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     CONTACT

\========================================================= -->



<section class="section" id="contact">



    <div class="container">



        <div class="contact-box">



            <div class="row align-items-center">



                <div class="col-lg-7">



                    <h3>

                        Contact Assan Computer Institute

                    </h3>



                    <p>

                        Have questions about our courses,

                        registration or payment?

                        Contact us for more information.

                    </p>



                    <div class="contact-item">



                        <i class="fa-solid fa-phone"></i>



                        Contact us for course information



                    </div>



                    <div class="contact-item">



                        <i class="fa-solid fa-envelope"></i>



                        Contact us for registration assistance



                    </div>



                    <div class="contact-item">



                        <i class="fa-solid fa-location-dot"></i>



                        Pakistan



                    </div>



                </div>



                <div class="col-lg-5 text-lg-end mt-4 mt-lg-0">



                    <a

                        href="<?= htmlspecialchars($studentRegisterUrl); ?>"

                        class="btn-primary-custom"

                    >

                        Register as Student

                    </a>



                </div>



            </div>



        </div>



    </div>



</section>





<!-- =========================================================

     FOOTER

\========================================================= -->



<footer>



    <div class="container">



        <div class="row g-4">



            <div class="col-lg-4">



                <h5>

                    Assan Computer Institute

                </h5>



                <p>

                    Practical computer education

                    for students and professionals.

                    Learn useful skills and build

                    your career with confidence.

                </p>



            </div>





            <div class="col-lg-2 col-md-4">



                <h5>

                    Quick Links

                </h5>



                <ul>



                    <li>

                        <a href="<?= site_url(); ?>">

                            Home

                        </a>

                    </li>



                    <li>

                        <a href="#courses">

                            Courses

                        </a>

                    </li>



                    <li>

                        <a href="#pricing">

                            Pricing

                        </a>

                    </li>



                    <li>

                        <a href="#contact">

                            Contact

                        </a>

                    </li>



                </ul>



            </div>





            <div class="col-lg-3 col-md-4">



                <h5>

                    Student

                </h5>



                <ul>



                    <!-- Direct absolute URLs -->



                    <li>

                        <a href="<?= htmlspecialchars($studentLoginUrl); ?>">

                            Student Login

                        </a>

                    </li>



                    <li>

                        <a href="<?= htmlspecialchars($studentRegisterUrl); ?>">

                            Student Registration

                        </a>

                    </li>



                    <li>

                        <a href="<?= htmlspecialchars($studentDashboardUrl); ?>">

                            Student Dashboard

                        </a>

                    </li>



                </ul>



            </div>





            <div class="col-lg-3 col-md-4">



                <h5>

                    Administration

                </h5>



                <ul>



                    <li>

                        <a href="<?= htmlspecialchars($adminLoginUrl); ?>">

                            Admin Login

                        </a>

                    </li>



                    <li>

                        <a href="#payment">

                            Payment Methods

                        </a>

                    </li>



                    <li>

                        <a href="#faq">

                            FAQ

                        </a>

                    </li>



                </ul>



            </div>



        </div>





        <div class="footer-bottom">



            <p class="mb-0">



                &copy;

                <?= date('Y'); ?>

                Assan Computer Institute.

                All Rights Reserved.



            </p>



        </div>



    </div>



</footer>





<!-- =========================================================

     JAVASCRIPT

\========================================================= -->



<script

    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"

></script>



<script>



    /*

    |--------------------------------------------------------------------------

    | Correct Base URL

    |--------------------------------------------------------------------------

    */



    const BASE_URL = <?= json_encode($baseUrl . '/'); ?>;



</script>



</body>



</html>



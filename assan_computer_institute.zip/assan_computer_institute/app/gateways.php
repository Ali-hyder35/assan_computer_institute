<?php
function create_gateway_payment($method, $enrollment, $user) {
    $method = strtolower($method);

    /*
     * Live JazzCash/Easypaisa integrations require the exact merchant API/form
     * specification supplied for your merchant account. This function deliberately
     * does not invent provider fields or credentials.
     */
    if ($method === 'jazzcash' && env('JAZZCASH_ENABLED', '0') === '1') {
        return array('ok' => false, 'message' => 'JazzCash is enabled but its merchant-specific fields must be configured in app/gateways.php.');
    }

    if ($method === 'easypaisa' && env('EASYPAISA_ENABLED', '0') === '1') {
        return array('ok' => false, 'message' => 'Easypaisa is enabled but its merchant-specific fields must be configured in app/gateways.php.');
    }

    return array('ok' => false, 'message' => 'This payment method is currently configured as a secure integration placeholder. Use Bank Transfer or configure your merchant gateway.');
}

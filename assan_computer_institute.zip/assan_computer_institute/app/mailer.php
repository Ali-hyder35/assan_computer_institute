<?php
function send_email($to, $subject, $html) {
    if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) return false;
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = env('MAIL_HOST', '');
        $mail->SMTPAuth = true;
        $mail->Username = env('MAIL_USERNAME', '');
        $mail->Password = env('MAIL_PASSWORD', '');
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = (int)env('MAIL_PORT', 587);
        $mail->setFrom(env('MAIL_FROM', 'no-reply@example.com'), env('MAIL_FROM_NAME', 'Assan Computer Institute'));
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html;
        return $mail->send();
    } catch (Throwable $e) {
        return false;
    }
}

function enrollment_email($name, $course, $amount, $order) {
    return '<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;padding:25px">' .
        '<h2>Assan Computer Institute</h2><p>Hello ' . e($name) . ',</p>' .
        '<p>Your enrollment request has been received.</p>' .
        '<p><b>Course:</b> ' . e($course) . '<br><b>Amount:</b> ' . e(money($amount)) .
        '<br><b>Order:</b> ' . e($order) . '</p><p>We will update your payment and course access status after verification.</p></div>';
}

<?php
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function base_url($path = '') {
    $base = rtrim(env('APP_URL', ''), '/');
    return $base . ($path !== '' ? '/' . ltrim($path, '/') : '');
}

function redirect($path) {
    if (preg_match('#^https?://#i', $path)) {
        header('Location: ' . $path);
    } else {
        header('Location: ' . base_url($path));
    }
    exit;
}

function csrf_token() {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}

function csrf_field() {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function verify_csrf() {
    $token = isset($_POST['_csrf']) ? $_POST['_csrf'] : '';
    if (!$token || !hash_equals(isset($_SESSION['_csrf']) ? $_SESSION['_csrf'] : '', $token)) {
        http_response_code(419);
        exit('Invalid CSRF token.');
    }
}

function flash($key, $value = null) {
    if ($value !== null) {
        $_SESSION['_flash'][$key] = $value;
        return null;
    }
    $v = isset($_SESSION['_flash'][$key]) ? $_SESSION['_flash'][$key] : null;
    unset($_SESSION['_flash'][$key]);
    return $v;
}

function current_user() {
    return isset($_SESSION['user']) ? $_SESSION['user'] : null;
}

function money($amount) {
    return 'PKR ' . number_format((float)$amount, 0);
}

function order_ref() {
    return 'ACI-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(3)));
}

function old($key, $default = '') {
    return isset($_POST[$key]) ? $_POST[$key] : $default;
}

function active_link($file) {
    return basename($_SERVER['SCRIPT_NAME']) === $file ? 'active' : '';
}

function log_action($pdo, $userId, $action, $details = null) {
    $st = $pdo->prepare("INSERT INTO audit_logs(user_id, action, details, ip_address) VALUES(?,?,?,?)");
    $st->execute(array($userId, $action, $details, isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null));
}

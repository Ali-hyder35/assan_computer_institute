<?php
function login_user($pdo, $email, $password) {
    $st = $pdo->prepare("SELECT * FROM users WHERE email=? AND status='active' LIMIT 1");
    $st->execute(array($email));
    $user = $st->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        unset($user['password_hash']);
        $_SESSION['user'] = $user;
        session_regenerate_id(true);
        log_action($pdo, $user['id'], 'login', 'Successful login');
        return true;
    }
    return false;
}

function logout_user() {
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time()-42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function require_login() {
    if (empty($_SESSION['user'])) redirect('student/login.php');
}

function require_admin() {
    if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') redirect('admin/login.php');
}

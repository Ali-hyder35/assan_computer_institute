<?php require_once __DIR__.'/config/bootstrap.php'; $pageTitle='Page Not Found'; include __DIR__.'/partials/header.php'; ?>
<div class="section-pad text-center"><div class="container"><div class="display-1 fw-bold text-primary">404</div><h2 class="section-title">Page not found</h2><p class="text-secondary">The page you requested does not exist.</p><a class="btn btn-primary" href="<?=e(base_url())?>">Back to Home</a></div></div>
<?php include __DIR__.'/partials/footer.php'; ?>

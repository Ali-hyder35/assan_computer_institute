<?php
$pageTitle = isset($pageTitle)
    ? $pageTitle
    : env('APP_NAME', 'Assan Computer Institute');

$user = current_user();
?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta
        name="description"
        content="Assan Computer Institute - professional computer courses and practical training."
    >

    <meta name="theme-color" content="#14295f">

    <title><?= e($pageTitle) ?> | Assan Computer Institute</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <!-- Main CSS -->
    <link
        href="<?= e(base_url('assan_computer_institute/assets/css/style.css')) ?>"
        rel="stylesheet"
    >

    <style>

        /* =========================================================
           PROFESSIONAL HEADER
        ========================================================= */

        :root {
            --aci-primary: #14295f;
            --aci-blue: #1f3c88;
            --aci-blue-light: #386ed4;
            --aci-red: #c0392b;
            --aci-red-dark: #a93226;
            --aci-text: #172033;
            --aci-muted: #6b7280;
            --aci-border: rgba(255, 255, 255, 0.12);
        }

        body {
            background: #f5f7fb;
        }

        /* =========================================================
           NAVBAR
        ========================================================= */

        .main-navbar {
            background:
                linear-gradient(
                    120deg,
                    #101f4d 0%,
                    #14295f 42%,
                    #1f3c88 100%
                );

            min-height: 76px;

            border-bottom: 1px solid rgba(255, 255, 255, 0.10);

            box-shadow:
                0 8px 30px rgba(15, 35, 80, 0.18);

            backdrop-filter: blur(14px);

            z-index: 1050;
        }

        .main-navbar .container {
            min-height: 76px;
        }

        /* =========================================================
           BRAND
        ========================================================= */

        .main-navbar .navbar-brand {
            display: inline-flex;
            align-items: center;
            gap: 11px;

            color: #ffffff;

            font-size: 20px;
            font-weight: 700;

            letter-spacing: -0.3px;

            transition: all 0.25s ease;
        }

        .main-navbar .navbar-brand:hover {
            color: #ffffff;
            transform: translateY(-1px);
        }

        .brand-mark {
            width: 43px;
            height: 43px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            border-radius: 13px;

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #c0392b,
                    #e74c3c
                );

            box-shadow:
                0 7px 18px rgba(192, 57, 43, 0.35);

            font-size: 21px;

            flex-shrink: 0;
        }

        /* =========================================================
           NAVIGATION LINKS
        ========================================================= */

        .main-navbar .navbar-nav {
            gap: 3px;
        }

        .main-navbar .nav-link {
            position: relative;

            color: rgba(255, 255, 255, 0.82) !important;

            font-size: 14px;
            font-weight: 500;

            padding: 10px 10px !important;

            border-radius: 10px;

            transition:
                color 0.25s ease,
                background 0.25s ease,
                transform 0.25s ease;
        }

        .main-navbar .nav-link:hover {
            color: #ffffff !important;

            background: rgba(255, 255, 255, 0.09);

            transform: translateY(-1px);
        }

        .main-navbar .nav-link.active {
            color: #ffffff !important;

            background: rgba(255, 255, 255, 0.12);
        }

        .main-navbar .nav-link.active::after {
            content: "";

            position: absolute;

            left: 14px;
            right: 14px;
            bottom: 3px;

            height: 2px;

            border-radius: 20px;

            background: #e74c3c;
        }

        /* =========================================================
           DASHBOARD BUTTON
        ========================================================= */

        .header-dashboard-btn {
            display: inline-flex;
            align-items: center;
            gap: 7px;

            color: #14295f !important;

            background: #2d2937;

            border: none;

            border-radius: 11px;

            font-size: 13px;
            font-weight: 700;

            padding: 10px 15px !important;

            box-shadow:
                0 7px 18px rgba(0, 0, 0, 0.12);

            transition: all 0.25s ease;
        }

        .header-dashboard-btn:hover {
            color: #14295f !important;

            background: #35373b;

            transform: translateY(-2px);

            box-shadow:
                0 10px 22px rgba(0, 0, 0, 0.18);
        }

        .header-dashboard-btn i {
            font-size: 16px;
        }

        /* =========================================================
           LOGIN BUTTON
        ========================================================= */

        .header-login-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;

            color: rgba(255, 255, 255, 0.88) !important;

            font-weight: 600 !important;
        }

        .header-login-btn:hover {
            color: #ffffff !important;
        }

        /* =========================================================
           REGISTER BUTTON
        ========================================================= */

        .header-register-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;

            color: #ffffff !important;

            background:
                linear-gradient(
                    135deg,
                    #c0392b,
                    #e74c3c
                );

            border: none;

            border-radius: 11px;

            font-size: 13px;
            font-weight: 700;

            padding: 10px 17px !important;

            box-shadow:
                0 7px 18px rgba(192, 57, 43, 0.30);

            transition: all 0.25s ease;
        }

        .header-register-btn:hover {
            color: #ffffff !important;

            background:
                linear-gradient(
                    135deg,
                    #a93226,
                    #c0392b
                );

            transform: translateY(-2px);

            box-shadow:
                0 10px 22px rgba(192, 57, 43, 0.38);
        }

        /* =========================================================
           MOBILE TOGGLER
        ========================================================= */

        .main-navbar .navbar-toggler {
            width: 45px;
            height: 42px;

            border: 1px solid rgba(255, 255, 255, 0.22);

            border-radius: 11px;

            background: rgba(255, 255, 255, 0.07);

            padding: 0;

            display: flex;
            align-items: center;
            justify-content: center;

            box-shadow: none;
        }

        .main-navbar .navbar-toggler:focus {
            box-shadow:
                0 0 0 3px rgba(255, 255, 255, 0.10);
        }

        /* =========================================================
           FLASH MESSAGES
        ========================================================= */

        .header-alert-wrapper {
            position: relative;
            z-index: 10;
        }

        .header-alert {
            display: flex;
            align-items: flex-start;
            gap: 12px;

            border: none;

            border-radius: 14px;

            padding: 14px 17px;

            font-size: 14px;
            font-weight: 500;

            box-shadow:
                0 8px 24px rgba(20, 41, 95, 0.08);
        }

        .header-alert-icon {
            width: 34px;
            height: 34px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 10px;

            flex-shrink: 0;

            font-size: 17px;
        }

        .header-alert-success {
            background: #ecfdf3;
            color: #166534;
        }

        .header-alert-success .header-alert-icon {
            background: #d1fae5;
            color: #15803d;
        }

        .header-alert-danger {
            background: #fff1f2;
            color: #991b1b;
        }

        .header-alert-danger .header-alert-icon {
            background: #ffe4e6;
            color: #dc2626;
        }

        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 991.98px) {

            .main-navbar {
                min-height: 68px;
            }

            .main-navbar .container {
                min-height: 68px;
            }

            .main-navbar .navbar-collapse {
                margin-top: 12px;

                padding: 12px;

                background: rgba(8, 25, 66, 0.97);

                border:
                    1px solid rgba(255, 255, 255, 0.10);

                border-radius: 16px;

                box-shadow:
                    0 15px 35px rgba(0, 0, 0, 0.18);
            }

            .main-navbar .navbar-nav {
                gap: 3px;
            }

            .main-navbar .nav-link {
                padding: 11px 13px !important;
            }

            .main-navbar .nav-link.active::after {
                display: none;
            }

            .header-dashboard-btn,
            .header-register-btn {
                width: 100%;

                justify-content: center;

                margin-top: 5px;
            }

            .header-login-btn {
                width: 100%;

                justify-content: center;

                margin-top: 5px;
            }
        }

        @media (max-width: 575.98px) {

            .main-navbar .navbar-brand {
                font-size: 17px;
            }

            .brand-mark {
                width: 39px;
                height: 39px;

                border-radius: 11px;

                font-size: 18px;
            }

            .header-alert {
                padding: 12px;
            }

        }

    </style>

</head>

<body>

    <!-- =========================================================
         MAIN NAVBAR
    ========================================================= -->

    <nav class="navbar navbar-expand-lg navbar-dark main-navbar sticky-top">

        <div class="container">

            <!-- Brand -->

            <a
                class="navbar-brand"
                href="<?= e(base_url()) ?>"
            >

                <span class="brand-mark">
                    <i class="bi bi-cpu-fill"></i>
                </span>

                <span>
                    Assan Computer Institute
                </span>

            </a>


            <!-- Mobile Toggle -->

            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#mainNav"
                aria-controls="mainNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >

                <span class="navbar-toggler-icon"></span>

            </button>


            <!-- Navigation -->

            <div
                class="collapse navbar-collapse"
                id="mainNav"
            >

                <ul class="navbar-nav ms-auto align-items-lg-center">

                  

                    <?php if ($user): ?>

                        <!-- Logged In User -->

                        <li class="nav-item ms-lg-2">

                            <a
                                class="nav-link header-dashboard-btn"
                                href="<?= e(
                                    base_url(
                                        $user['role'] === 'admin'
                                            ? 'assan_computer_institute/admin/dashboard.php'
                                            : 'assan_computer_institute/student/dashboard.php'
                                    )
                                ) ?>"
                            >

                                <i class="bi bi-grid-1x2-fill"></i>

                                <span>Dashboard</span>

                            </a>

                        </li>


                    <?php else: ?>

                        <!-- Login -->

                        <li class="nav-item ms-lg-2">

                            <a
                                class="nav-link header-login-btn"
                                href="<?= e(base_url('assan_computer_institute/student/login.php')) ?>"
                            >

                                <i class="bi bi-box-arrow-in-right"></i>

                                <span>Login</span>

                            </a>

                        </li>


                        <!-- Register -->

                        <li class="nav-item">

                            <a
                                class="nav-link header-register-btn"
                                href="<?= e(base_url('assan_computer_institute/student/register.php')) ?>"
                            >

                                <i class="bi bi-person-plus-fill"></i>

                                <span>Register</span>

                            </a>

                        </li>

                    <?php endif; ?>

                </ul>

            </div>

        </div>

    </nav>


    <!-- =========================================================
         FLASH MESSAGES
    ========================================================= -->

    <div class="header-alert-wrapper">

        <?php if ($msg = flash('success')): ?>

            <div class="container mt-3">

                <div
                    class="alert header-alert header-alert-success alert-dismissible fade show"
                    role="alert"
                >

                    <div class="header-alert-icon">
                        <i class="bi bi-check-circle-fill"></i>
                    </div>

                    <div class="flex-grow-1">
                        <?= $msg ?>
                    </div>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Close"
                    ></button>

                </div>

            </div>

        <?php endif; ?>


        <?php if ($msg = flash('error')): ?>

            <div class="container mt-3">

                <div
                    class="alert header-alert header-alert-danger alert-dismissible fade show"
                    role="alert"
                >

                    <div class="header-alert-icon">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                    </div>

                    <div class="flex-grow-1">
                        <?= $msg ?>
                    </div>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Close"
                    ></button>

                </div>

            </div>

        <?php endif; ?>

    </div>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>


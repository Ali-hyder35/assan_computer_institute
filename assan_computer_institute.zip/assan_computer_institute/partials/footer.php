<footer class="site-footer mt-5">
    <div class="container py-5">
        <div class="row g-4">
            <div class="col-lg-5">
                <h4><i class="bi bi-cpu"></i> Assan Computer Institute</h4>
                <p class="text-white-50">Practical computer education, professional skills and project-based learning
                    for students and working professionals.</p>
            </div>
            <div class="col-6 col-lg-2">
                <h6>Quick Links</h6><a href="<?= e(base_url()) ?>">Home</a><a
                    href="<?= e(base_url('#courses')) ?>">Courses</a><a
                    href="<?= e(base_url('student/register.php')) ?>">Register</a>
            </div>
            <div class="col-6 col-lg-2">
                <h6>Student</h6><a href="<?= e(base_url('student/login.php')) ?>">Login</a><a
                    href="<?= e(base_url('student/dashboard.php')) ?>">Dashboard</a>
            </div>
            <div class="col-lg-3">
                <h6>Contact</h6>
                <p class="text-white-50 mb-1"><i class="bi bi-telephone"></i> +92 300 0000000</p>
                <p class="text-white-50"><i class="bi bi-envelope"></i> info@example.com</p>
            </div>
        </div>
        <hr class="border-light opacity-25">
        <div class="d-flex justify-content-between flex-wrap gap-2 small text-white-50"><span>© <?= date('Y') ?> Assan
                Computer Institute</span><span>Professional Learning • Practical Skills • Career Growth</span></div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(base_url('assan_computer_institute/assets/js/app.js')) ?>"></script>
</body>

</html>
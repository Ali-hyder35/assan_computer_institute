<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Admin - Manage Exam Questions
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$examId =
    isset($_GET['id'])
        ? (int) $_GET['id']
        : 0;

if ($examId <= 0) {

    flash(
        'error',
        'Invalid exam selected.'
    );

    redirect(
        base_url('assan_computer_institute/admin/exams.php')
    );
}

/*
|--------------------------------------------------------------------------
| Load Exam
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        e.*,
        c.title AS course_title
    FROM exams e
    INNER JOIN courses c
        ON c.id = e.course_id
    WHERE e.id = ?
    LIMIT 1
");

$stmt->execute(array($examId));

$exam = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$exam) {

    flash(
        'error',
        'Exam not found.'
    );

    redirect(
        base_url('assan_computer_institute/admin/exams.php')
    );
}

$pageTitle =
    'Questions - ' . $exam['title'];

/*
|--------------------------------------------------------------------------
| Add / Delete Question
|--------------------------------------------------------------------------
*/

$errors = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $action =
            isset($_POST['action'])
                ? trim($_POST['action'])
                : '';

        /*
        |--------------------------------------------------------------------------
        | Delete
        |--------------------------------------------------------------------------
        */

        if ($action === 'delete') {

            $questionId =
                isset($_POST['question_id'])
                    ? (int) $_POST['question_id']
                    : 0;

            if ($questionId <= 0) {
                throw new Exception('Invalid question selected.');
            }

            $stmt = $pdo->prepare("
                DELETE FROM exam_questions
                WHERE id = ?
                  AND exam_id = ?
            ");

            $stmt->execute(array(
                $questionId,
                $examId
            ));

            flash(
                'success',
                'Question deleted successfully.'
            );

            redirect(
                base_url(
                    'assan_computer_institute/admin/exam_questions.php?id=' .
                    $examId
                )
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Add Question
        |--------------------------------------------------------------------------
        */

        if ($action === 'add') {

            $questionText =
                isset($_POST['question_text'])
                    ? trim($_POST['question_text'])
                    : '';

            $optionA =
                isset($_POST['option_a'])
                    ? trim($_POST['option_a'])
                    : '';

            $optionB =
                isset($_POST['option_b'])
                    ? trim($_POST['option_b'])
                    : '';

            $optionC =
                isset($_POST['option_c'])
                    ? trim($_POST['option_c'])
                    : '';

            $optionD =
                isset($_POST['option_d'])
                    ? trim($_POST['option_d'])
                    : '';

            $correctOption =
                isset($_POST['correct_option'])
                    ? strtoupper(trim($_POST['correct_option']))
                    : '';

            $marks =
                isset($_POST['marks'])
                    ? (float) $_POST['marks']
                    : 1;

            $questionOrder =
                isset($_POST['question_order'])
                    ? (int) $_POST['question_order']
                    : 0;

            if ($questionText === '') {
                $errors[] =
                    'Question text is required.';
            }

            if ($optionA === '') {
                $errors[] =
                    'Option A is required.';
            }

            if ($optionB === '') {
                $errors[] =
                    'Option B is required.';
            }

            if (
                !in_array(
                    $correctOption,
                    array('A', 'B', 'C', 'D'),
                    true
                )
            ) {
                $errors[] =
                    'Please select a valid correct option.';
            }

            if ($marks <= 0) {
                $errors[] =
                    'Question marks must be greater than zero.';
            }

            /*
            |--------------------------------------------------------------------------
            | Calculate Question Order
            |--------------------------------------------------------------------------
            */

            if (
                $questionOrder <= 0 &&
                empty($errors)
            ) {

                $stmt = $pdo->prepare("
                    SELECT
                        COALESCE(
                            MAX(question_order),
                            0
                        ) + 1
                    FROM exam_questions
                    WHERE exam_id = ?
                ");

                $stmt->execute(array($examId));

                $questionOrder =
                    (int) $stmt->fetchColumn();
            }

            /*
            |--------------------------------------------------------------------------
            | Insert
            |--------------------------------------------------------------------------
            */

            if (empty($errors)) {

                $stmt = $pdo->prepare("
                    INSERT INTO exam_questions
                    (
                        exam_id,
                        question_text,
                        option_a,
                        option_b,
                        option_c,
                        option_d,
                        correct_option,
                        marks,
                        question_order,
                        active
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        1
                    )
                ");

                $stmt->execute(array(
                    $examId,
                    $questionText,
                    $optionA,
                    $optionB,
                    $optionC !== '' ? $optionC : null,
                    $optionD !== '' ? $optionD : null,
                    $correctOption,
                    $marks,
                    $questionOrder
                ));

                /*
                |--------------------------------------------------------------------------
                | Update Exam Total Marks
                |--------------------------------------------------------------------------
                */

                $stmt = $pdo->prepare("
                    SELECT
                        COALESCE(SUM(marks), 0)
                    FROM exam_questions
                    WHERE exam_id = ?
                      AND active = 1
                ");

                $stmt->execute(array($examId));

                $newTotalMarks =
                    (float) $stmt->fetchColumn();

                $stmt = $pdo->prepare("
                    UPDATE exams
                    SET
                        total_marks = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ");

                $stmt->execute(array(
                    $newTotalMarks,
                    $examId
                ));

                flash(
                    'success',
                    'Question added successfully.'
                );

                redirect(
                    base_url(
                        'assan_computer_institute/admin/exam_questions.php?id=' .
                        $examId
                    )
                );
            }
        }

    } catch (Exception $e) {

        $errors[] =
            $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| Load Questions
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM exam_questions
    WHERE exam_id = ?
    ORDER BY question_order ASC, id ASC
");

$stmt->execute(array($examId));

$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$flashSuccess = flash('success');
$flashError = flash('error');

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
body {
    background: #f5f7fb;
}

.questions-page {
    padding: 30px 0 60px;
}

.exam-header {
    background: linear-gradient(
        135deg,
        #0f2a5f,
        #1e4b8f
    );
    color: #fff;
    border-radius: 18px;
    padding: 27px;
    margin-bottom: 25px;
}

.question-form,
.question-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 8px 25px rgba(15,42,95,.08);
    margin-bottom: 20px;
}

.form-control,
.form-select {
    border-radius: 10px;
}

.question-number {
    width: 38px;
    height: 38px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #eff6ff;
    color: #2563eb;
    border-radius: 10px;
    font-weight: 800;
    margin-right: 10px;
}

.question-text {
    font-size: 16px;
    font-weight: 700;
    color: #1e293b;
    line-height: 1.6;
}

.option-row {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 9px;
    padding: 9px 12px;
    margin-top: 8px;
}

.correct-option {
    background: #f0fdf4;
    border-color: #86efac;
}

.btn-add {
    background: #2563eb;
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 11px 20px;
    font-weight: 700;
}

.btn-add:hover {
    background: #1d4ed8;
    color: #fff;
}
</style>

<div class="container questions-page">

    <div class="exam-header">

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">

            <div>

                <h2 class="mb-1">
                    <?= e($exam['title']) ?>
                </h2>

                <p class="mb-0 text-white-50">
                    <?= e($exam['course_title']) ?>
                    &nbsp;•&nbsp;
                    <?= count($questions) ?> Questions
                </p>

            </div>

            <div>

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/exams.php')) ?>"
                    class="btn btn-light"
                >
                    <i class="bi bi-arrow-left me-1"></i>
                    Back to Exams
                </a>

            </div>

        </div>

    </div>

    <?php if ($flashSuccess): ?>

        <div class="alert alert-success">
            <?= e($flashSuccess) ?>
        </div>

    <?php endif; ?>

    <?php if ($flashError): ?>

        <div class="alert alert-danger">
            <?= e($flashError) ?>
        </div>

    <?php endif; ?>

    <?php if (!empty($errors)): ?>

        <div class="alert alert-danger">

            <ul class="mb-0">

                <?php foreach ($errors as $error): ?>

                    <li><?= e($error) ?></li>

                <?php endforeach; ?>

            </ul>

        </div>

    <?php endif; ?>

    <!-- ADD QUESTION -->

    <div class="question-form">

        <h5 class="fw-bold mb-1">
            <i class="bi bi-plus-circle me-1"></i>
            Add Question
        </h5>

        <p class="text-muted small mb-4">
            Add an MCQ question to this examination.
        </p>

        <form method="post">

            <?= csrf_field() ?>

            <input
                type="hidden"
                name="action"
                value="add"
            >

            <div class="row g-3">

                <div class="col-12">

                    <label class="form-label fw-semibold">
                        Question
                    </label>

                    <textarea
                        name="question_text"
                        class="form-control"
                        rows="3"
                        placeholder="Enter your question..."
                        required
                    ></textarea>

                </div>

                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Option A
                    </label>

                    <input
                        type="text"
                        name="option_a"
                        class="form-control"
                        required
                    >

                </div>

                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Option B
                    </label>

                    <input
                        type="text"
                        name="option_b"
                        class="form-control"
                        required
                    >

                </div>

                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Option C
                    </label>

                    <input
                        type="text"
                        name="option_c"
                        class="form-control"
                    >

                </div>

                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Option D
                    </label>

                    <input
                        type="text"
                        name="option_d"
                        class="form-control"
                    >

                </div>

                <div class="col-md-4">

                    <label class="form-label fw-semibold">
                        Correct Option
                    </label>

                    <select
                        name="correct_option"
                        class="form-select"
                        required
                    >

                        <option value="">
                            Select Correct Answer
                        </option>

                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>

                    </select>

                </div>

                <div class="col-md-4">

                    <label class="form-label fw-semibold">
                        Marks
                    </label>

                    <input
                        type="number"
                        name="marks"
                        class="form-control"
                        value="1"
                        min="0.01"
                        step="0.01"
                        required
                    >

                </div>

                <div class="col-md-4">

                    <label class="form-label fw-semibold">
                        Question Order
                    </label>

                    <input
                        type="number"
                        name="question_order"
                        class="form-control"
                        min="1"
                        placeholder="Auto"
                    >

                </div>

            </div>

            <div class="mt-4">

                <button
                    type="submit"
                    class="btn-add"
                >
                    <i class="bi bi-plus-lg me-1"></i>
                    Add Question
                </button>

            </div>

        </form>

    </div>

    <!-- QUESTIONS -->

    <div>

        <div class="d-flex justify-content-between align-items-center mb-3">

            <h5 class="fw-bold mb-0">
                Exam Questions
            </h5>

            <span class="badge bg-primary">
                <?= count($questions) ?>
                Questions
            </span>

        </div>

        <?php if (empty($questions)): ?>

            <div class="question-card text-center py-5">

                <i
                    class="bi bi-question-circle"
                    style="font-size:45px;color:#2563eb;"
                ></i>

                <h5 class="mt-3">
                    No Questions Yet
                </h5>

                <p class="text-muted">
                    Add questions using the form above.
                </p>

            </div>

        <?php else: ?>

            <?php foreach ($questions as $index => $question): ?>

                <div class="question-card">

                    <div class="d-flex justify-content-between align-items-start">

                        <div class="flex-grow-1">

                            <div class="question-text">

                                <span class="question-number">
                                    <?= $index + 1 ?>
                                </span>

                                <?= nl2br(e($question['question_text'])) ?>

                            </div>

                        </div>

                        <div>

                            <form
                                method="post"
                                onsubmit="return confirm('Delete this question?');"
                            >

                                <?= csrf_field() ?>

                                <input
                                    type="hidden"
                                    name="action"
                                    value="delete"
                                >

                                <input
                                    type="hidden"
                                    name="question_id"
                                    value="<?= (int) $question['id'] ?>"
                                >

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    <i class="bi bi-trash"></i>
                                </button>

                            </form>

                        </div>

                    </div>

                    <div class="mt-3">

                        <div
                            class="option-row <?= $question['correct_option'] === 'A' ? 'correct-option' : '' ?>"
                        >
                            <strong>A.</strong>
                            <?= e($question['option_a']) ?>
                        </div>

                        <div
                            class="option-row <?= $question['correct_option'] === 'B' ? 'correct-option' : '' ?>"
                        >
                            <strong>B.</strong>
                            <?= e($question['option_b']) ?>
                        </div>

                        <?php if (!empty($question['option_c'])): ?>

                            <div
                                class="option-row <?= $question['correct_option'] === 'C' ? 'correct-option' : '' ?>"
                            >
                                <strong>C.</strong>
                                <?= e($question['option_c']) ?>
                            </div>

                        <?php endif; ?>

                        <?php if (!empty($question['option_d'])): ?>

                            <div
                                class="option-row <?= $question['correct_option'] === 'D' ? 'correct-option' : '' ?>"
                            >
                                <strong>D.</strong>
                                <?= e($question['option_d']) ?>
                            </div>

                        <?php endif; ?>

                    </div>

                    <div class="d-flex justify-content-between mt-3">

                        <small class="text-muted">
                            Question Order:
                            <?= (int) $question['question_order'] ?>
                        </small>

                        <small class="text-muted">
                            Marks:
                            <?= e($question['marks']) ?>
                            &nbsp; | &nbsp;
                            Correct:
                            <strong class="text-success">
                                <?= e($question['correct_option']) ?>
                            </strong>
                        </small>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
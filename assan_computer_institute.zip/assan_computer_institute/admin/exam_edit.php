<?php /* |-------------------------------------------------------------------------- | Assan Computer Institute | Admin - Edit Exam |-------------------------------------------------------------------------- */ require_once dirname(__DIR__) . '/config/bootstrap.php';
require_admin();
$pageTitle = 'Edit Exam';
$examId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($examId <= 0) {
    flash('error', 'Invalid exam selected.');
    redirect(base_url('assan_computer_institute/admin/exams.php'));
} /* |-------------------------------------------------------------------------- | Load Exam |-------------------------------------------------------------------------- */
$stmt = $pdo->prepare(" SELECT * FROM exams WHERE id = ? LIMIT 1 ");
$stmt->execute(array($examId));
$exam = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$exam) {
    flash('error', 'Exam not found.');
    redirect(base_url('assan_computer_institute/admin/exams.php'));
}
$errors = array();
$title = $exam['title'];
$description = $exam['description'];
$courseId = (int) $exam['course_id'];
$durationMinutes = (int) $exam['duration_minutes'];
$totalMarks = (float) $exam['total_marks'];
$passMarks = (float) $exam['pass_marks'];
$attemptsAllowed = (int) $exam['attempts_allowed'];
$active = (int) $exam['active']; /* |-------------------------------------------------------------------------- | Courses |-------------------------------------------------------------------------- */
$stmt = $pdo->query(" SELECT id, title, active FROM courses ORDER BY title ASC ");
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC); /* |-------------------------------------------------------------------------- | Update |-------------------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();
        $title = isset($_POST['title']) ? trim($_POST['title']) : '';
        $description = isset($_POST['description']) ? trim($_POST['description']) : '';
        $courseId = isset($_POST['course_id']) ? (int) $_POST['course_id'] : 0;
        $durationMinutes = isset($_POST['duration_minutes']) ? (int) $_POST['duration_minutes'] : 30;
        $totalMarks = isset($_POST['total_marks']) ? (float) $_POST['total_marks'] : 0;
        $passMarks = isset($_POST['pass_marks']) ? (float) $_POST['pass_marks'] : 0;
        $attemptsAllowed = isset($_POST['attempts_allowed']) ? (int) $_POST['attempts_allowed'] : 1;
        $active = isset($_POST['active']) ? 1 : 0;
        if ($title === '') {
            $errors[] = 'Exam title is required.';
        }
        if ($courseId <= 0) {
            $errors[] = 'Please select a course.';
        }
        if ($durationMinutes <= 0) {
            $errors[] = 'Duration must be greater than zero.';
        }
        if ($totalMarks < 0) {
            $errors[] = 'Total marks cannot be negative.';
        }
        if ($passMarks < 0) {
            $errors[] = 'Pass marks cannot be negative.';
        }
        if ($totalMarks > 0 && $passMarks > $totalMarks) {
            $errors[] = 'Pass marks cannot be greater than total marks.';
        }
        if ($attemptsAllowed < 0) {
            $errors[] = 'Attempts allowed cannot be negative.';
        }
        if (empty($errors)) {
            $stmt = $pdo->prepare(" SELECT id FROM courses WHERE id = ? LIMIT 1 ");
            $stmt->execute(array($courseId));
            if (!$stmt->fetchColumn()) {
                $errors[] = 'Selected course does not exist.';
            }
        }
        if (empty($errors)) {
            $stmt = $pdo->prepare(" UPDATE exams SET course_id = ?, title = ?, description = ?, duration_minutes = ?, total_marks = ?, pass_marks = ?, attempts_allowed = ?, active = ?, updated_at = NOW() WHERE id = ? ");
            $stmt->execute(array($courseId, $title, $description !== '' ? $description : null, $durationMinutes, $totalMarks, $passMarks, $attemptsAllowed, $active, $examId));
            flash('success', 'Exam updated successfully.');
            redirect(base_url('assan_computer_institute/admin/exams.php'));
        }
    } catch (Exception $e) {
        $errors[] = $e->getMessage();
    }
}
require_once dirname(__DIR__) . '/partials/header.php'; ?>
<style>
    body {
        background: #f5f7fb;
    }

    .exam-edit-page {
        padding: 30px 0 60px;
    }

    .form-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 18px;
        padding: 28px;
        margin-bottom: 25px;
    }

    .form-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 28px;
        box-shadow: 0 8px 25px rgba(15, 42, 95, .08);
    }

    .form-label {
        color: #334155;
        font-weight: 600;
    }

    .form-control,
    .form-select {
        border-color: #dbe3ef;
        border-radius: 10px;
        padding: 11px 13px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 .2rem rgba(37, 99, 235, .12);
    }

    .btn-save {
        background: #2563eb;
        color: #fff;
        border: none;
        border-radius: 10px;
        padding: 12px 22px;
        font-weight: 700;
    }
</style>
<div class="container exam-edit-page">
    <div class="form-header">
        <h2 class="mb-1"> <i class="bi bi-pencil-square me-2"></i> Edit Exam </h2>
        <p class="mb-0 text-white-50"> Update examination settings and publication status. </p>
    </div> <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0"> <?php foreach ($errors as $error): ?>
                    <li><?= e($error) ?></li> <?php endforeach; ?>
            </ul>
        </div> <?php endif; ?>
    <div class="form-card">
        <form method="post"> <?= csrf_field() ?>
            <div class="row g-4">
                <div class="col-md-8"> <label class="form-label"> Exam Title </label> <input type="text" name="title"
                        class="form-control" value="<?= e($title) ?>" required> </div>
                <div class="col-md-4"> <label class="form-label"> Course </label> <select name="course_id"
                        class="form-select" required> <?php foreach ($courses as $course): ?>
                            <option value="<?= (int) $course['id'] ?>" <?= $courseId === (int) $course['id'] ? 'selected' : '' ?>> <?= e($course['title']) ?> </option> <?php endforeach; ?>
                    </select> </div>
                <div class="col-12"> <label class="form-label"> Description </label> <textarea name="description"
                        class="form-control" rows="4"><?= e($description) ?></textarea> </div>
                <div class="col-md-3"> <label class="form-label"> Duration </label> <input type="number"
                        name="duration_minutes" class="form-control" min="1" value="<?= (int) $durationMinutes ?>"
                        required> </div>
                <div class="col-md-3"> <label class="form-label"> Total Marks </label> <input type="number"
                        name="total_marks" class="form-control" min="0" step="0.01" value="<?= e($totalMarks) ?>">
                </div>
                <div class="col-md-3"> <label class="form-label"> Pass Marks </label> <input type="number"
                        name="pass_marks" class="form-control" min="0" step="0.01" value="<?= e($passMarks) ?>"> </div>
                <div class="col-md-3"> <label class="form-label"> Attempts Allowed </label> <input type="number"
                        name="attempts_allowed" class="form-control" min="0" value="<?= (int) $attemptsAllowed ?>">
                    <small class="text-muted"> 0 = unlimited </small> </div>
                <div class="col-12">
                    <div class="form-check"> <input class="form-check-input" type="checkbox" name="active" id="active"
                            <?= $active ? 'checked' : '' ?>> <label class="form-check-label" for="active"> Published /
                            Active </label> </div>
                </div>
            </div>
            <hr class="my-4">
            <div class="d-flex justify-content-between"> <a
                    href="<?= e(base_url('assan_computer_institute/admin/exams.php')) ?>"
                    class="btn btn-outline-secondary"> Back </a> <button type="submit" class="btn-save"> <i
                        class="bi bi-save me-1"></i> Save Changes </button> </div>
        </form>
    </div>
</div> <?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
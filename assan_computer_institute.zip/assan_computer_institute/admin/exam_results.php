<?php /* |-------------------------------------------------------------------------- | Assan Computer Institute | Admin - Exam Results / Student Marks |-------------------------------------------------------------------------- */ require_once dirname(__DIR__) . '/config/bootstrap.php';
require_admin();
$pageTitle = 'Exam Results';
$examId = isset($_GET['exam_id']) ? (int) $_GET['exam_id'] : 0;
$courseId = isset($_GET['course_id']) ? (int) $_GET['course_id'] : 0; /* |-------------------------------------------------------------------------- | Exam Filter |-------------------------------------------------------------------------- */
$selectedExam = null;
if ($examId > 0) {
    $stmt = $pdo->prepare(" SELECT e.id, e.title, c.title AS course_title FROM exams e INNER JOIN courses c ON c.id = e.course_id WHERE e.id = ? LIMIT 1 ");
    $stmt->execute(array($examId));
    $selectedExam = $stmt->fetch(PDO::FETCH_ASSOC);
} /* |-------------------------------------------------------------------------- | Courses |-------------------------------------------------------------------------- */
$stmt = $pdo->query(" SELECT id, title FROM courses ORDER BY title ASC ");
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC); /* |-------------------------------------------------------------------------- | Build Results Query |-------------------------------------------------------------------------- */
$sql = " SELECT ea.id, ea.exam_id, ea.user_id, ea.started_at, ea.submitted_at, ea.score, ea.total_marks, ea.percentage, ea.status, ea.result, e.title AS exam_title, e.pass_marks, c.title AS course_title, u.full_name, u.email, u.mobile FROM exam_attempts ea INNER JOIN exams e ON e.id = ea.exam_id INNER JOIN courses c ON c.id = e.course_id INNER JOIN users u ON u.id = ea.user_id WHERE 1 = 1 ";
$params = array();
if ($examId > 0) {
    $sql .= " AND ea.exam_id = ? ";
    $params[] = $examId;
}
if ($courseId > 0) {
    $sql .= " AND e.course_id = ? ";
    $params[] = $courseId;
}
$sql .= " ORDER BY COALESCE(ea.submitted_at, ea.started_at) DESC, ea.id DESC ";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC); /* |-------------------------------------------------------------------------- | Statistics |-------------------------------------------------------------------------- */
$totalAttempts = count($results);
$passed = 0;
$failed = 0;
$inProgress = 0;
$totalMarksObtained = 0;
$totalMarksPossible = 0;
foreach ($results as $result) {
    if ($result['result'] === 'passed') {
        $passed++;
    }
    if ($result['result'] === 'failed') {
        $failed++;
    }
    if ($result['status'] === 'in_progress') {
        $inProgress++;
    }
    $totalMarksObtained += (float) $result['score'];
    $totalMarksPossible += (float) $result['total_marks'];
}
$overallPercentage = $totalMarksPossible > 0 ? ($totalMarksObtained / $totalMarksPossible) * 100 : 0;
$flashSuccess = flash('success');
$flashError = flash('error');
require_once dirname(__DIR__) . '/partials/header.php'; ?>
<style>
    body {
        background: #f5f7fb;
    }

    .results-page {
        padding: 30px 0 60px;
    }

    .page-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 18px;
        padding: 28px;
        margin-bottom: 25px;
    }

    .summary-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 15px;
        padding: 20px;
        box-shadow: 0 8px 25px rgba(15, 42, 95, .08);
    }

    .summary-card strong {
        display: block;
        font-size: 27px;
        color: #1e293b;
    }

    .summary-card span {
        color: #64748b;
        font-size: 13px;
    }

    .results-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 20px;
        margin-top: 25px;
        box-shadow: 0 8px 25px rgba(15, 42, 95, .08);
    }

    .filter-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 20px;
        box-shadow: 0 8px 25px rgba(15, 42, 95, .08);
    }

    .student-name {
        font-weight: 700;
        color: #1e293b;
    }

    .student-email {
        color: #64748b;
        font-size: 12px;
    }

    .result-badge {
        display: inline-block;
        padding: 6px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 800;
    }

    .passed {
        background: #dcfce7;
        color: #166534;
    }

    .failed {
        background: #fee2e2;
        color: #991b1b;
    }

    .progress {
        background: #fef3c7;
        color: #92400e;
    }

    .view-btn {
        background: #eff6ff;
        color: #1d4ed8;
        border-radius: 8px;
        padding: 7px 11px;
        text-decoration: none;
        font-size: 12px;
        font-weight: 700;
    }
</style>
<div class="container results-page">
    <div class="page-header">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h2 class="mb-1"> <i class="bi bi-bar-chart-line me-2"></i> Exam Results & Student Marks </h2>
                <p class="mb-0 text-white-50"> Monitor student examination performance and marks. </p>
            </div>
            <div> <a href="<?= e(base_url('assan_computer_institute/admin/exams.php')) ?>" class="btn btn-light"> <i
                        class="bi bi-journal-check me-1"></i> Manage Exams </a> </div>
        </div>
    </div> <?php if ($flashSuccess): ?>
        <div class="alert alert-success"> <?= e($flashSuccess) ?> </div> <?php endif; ?> <?php if ($flashError): ?>
        <div class="alert alert-danger"> <?= e($flashError) ?> </div> <?php endif; ?> <!-- FILTER -->
    <div class="filter-card">
        <form method="get">
            <div class="row g-3 align-items-end">
                <div class="col-md-5"> <label class="form-label fw-semibold"> Exam </label> <select name="exam_id"
                        class="form-select">
                        <option value=""> All Exams </option>
                        <?php $stmt = $pdo->query(" SELECT e.id, e.title, c.title AS course_title FROM exams e INNER JOIN courses c ON c.id = e.course_id ORDER BY e.title ASC ");
                        $allExams = $stmt->fetchAll(PDO::FETCH_ASSOC); ?>
                        <?php foreach ($allExams as $exam): ?>
                            <option value="<?= (int) $exam['id'] ?>" <?= $examId === (int) $exam['id'] ? 'selected' : '' ?>>
                                <?= e($exam['title']) ?> - <?= e($exam['course_title']) ?> </option> <?php endforeach; ?>
                    </select> </div>
                <div class="col-md-4"> <label class="form-label fw-semibold"> Course </label> <select name="course_id"
                        class="form-select">
                        <option value=""> All Courses </option> <?php foreach ($courses as $course): ?>
                            <option value="<?= (int) $course['id'] ?>" <?= $courseId === (int) $course['id'] ? 'selected' : '' ?>> <?= e($course['title']) ?> </option> <?php endforeach; ?>
                    </select> </div>
                <div class="col-md-3"> <button type="submit" class="btn btn-primary w-100"> <i
                            class="bi bi-search me-1"></i> Filter Results </button> </div>
            </div>
        </form>
    </div> <!-- SUMMARY -->
    <div class="row g-3 mt-1">
        <div class="col-lg-3 col-md-6">
            <div class="summary-card"> <strong> <?= $totalAttempts ?> </strong> <span> Total Attempts </span> </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="summary-card"> <strong style="color:#16a34a;"> <?= $passed ?> </strong> <span> Passed </span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="summary-card"> <strong style="color:#dc2626;"> <?= $failed ?> </strong> <span> Failed </span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="summary-card"> <strong style="color:#2563eb;"> <?= number_format($overallPercentage, 1) ?>%
                </strong> <span> Overall Marks </span> </div>
        </div>
    </div> <!-- RESULTS TABLE -->
    <div class="results-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h5 class="fw-bold mb-1"> Student Marks </h5> <small class="text-muted"> Complete examination
                    performance records. </small>
            </div>
        </div> <?php if (empty($results)): ?>
            <div class="text-center py-5"> <i class="bi bi-bar-chart" style="font-size:50px;color:#2563eb;"></i>
                <h5 class="mt-3"> No Results Found </h5>
                <p class="text-muted"> No student exam attempts match your filters. </p>
            </div> <?php else: ?>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Exam</th>
                            <th>Course</th>
                            <th>Marks</th>
                            <th>Percentage</th>
                            <th>Result</th>
                            <th>Submitted</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody> <?php foreach ($results as $result): ?>
                            <tr>
                                <td>
                                    <div class="student-name"> <?= e($result['full_name']) ?> </div>
                                    <div class="student-email"> <?= e($result['email']) ?> </div>
                                </td>
                                <td> <?= e($result['exam_title']) ?> </td>
                                <td> <?= e($result['course_title']) ?> </td>
                                <td> <strong> <?= e($result['score']) ?> / <?= e($result['total_marks']) ?> </strong> </td>
                                <td> <strong> <?= number_format((float) $result['percentage'], 1) ?>% </strong> </td>
                                <td> <?php if ($result['result'] === 'passed'): ?> <span class="result-badge passed"> PASSED
                                        </span> <?php elseif ($result['result'] === 'failed'): ?> <span class="result-badge failed">
                                            FAILED </span> <?php else: ?> <span class="result-badge progress"> IN PROGRESS </span>
                                    <?php endif; ?> </td>
                                <td> <small class="text-muted">
                                        <?= e($result['submitted_at'] ? $result['submitted_at'] : $result['started_at']) ?>
                                    </small> </td>
                                <td> <a href="<?= e(base_url('assan_computer_institute/admin/exam_result.php?id=' . (int) $result['id'])) ?>"
                                        class="view-btn"> <i class="bi bi-eye me-1"></i> Details </a> </td>
                            </tr> <?php endforeach; ?>
                    </tbody>
                </table>
            </div> <?php endif; ?>
    </div>
</div> <?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  verify_csrf();
  if (login_user($pdo, trim(isset($_POST['email']) ? $_POST['email'] : ''), isset($_POST['password']) ? $_POST['password'] : '')) {
    if (current_user()['role'] === 'admin')
      redirect('assan_computer_institute/admin/dashboard.php');
    logout_user();
    $error = 'This account is not an administrator.';
  }
  else
    $error = 'Invalid administrator credentials.';
}
$pageTitle = 'Admin Login';
include dirname(__DIR__) . '/partials/header.php';
?>
<div class="auth-wrap">
  <div class="container">
    <div class="auth-card">
      <div class="text-center mb-4">
        <div class="icon-box mx-auto mb-3"><i class="bi bi-shield-lock"></i></div>
        <h2 class="section-title">Administrator Login</h2>
        <p class="text-secondary">Secure management portal.</p>
      </div><?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
      <form method="post"><?= csrf_field() ?>
        <div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email"
            required></div>
        <div class="mb-4"><label class="form-label">Password</label><input class="form-control" type="password"
            name="password" required></div><button class="btn btn-primary w-100">Sign In</button>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__) . '/partials/footer.php'; ?>
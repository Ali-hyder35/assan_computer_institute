<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Certificate Requests';
$admin = current_user();
$adminId = (int) $admin['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();

        $requestId = isset($_POST['request_id'])
            ? (int) $_POST['request_id']
            : 0;

        $action = isset($_POST['action'])
            ? trim($_POST['action'])
            : '';

        $note = isset($_POST['admin_note'])
            ? trim($_POST['admin_note'])
            : '';

        if ($requestId <= 0) {
            throw new Exception('Invalid certificate request.');
        }

        if (!in_array($action, array('approve', 'reject'), true)) {
            throw new Exception('Invalid review action.');
        }

        if ($action === 'reject' && $note === '') {
            throw new Exception(
                'Please provide a reason before rejecting the request.'
            );
        }

        $stmt = $pdo->prepare("
            SELECT id, user_id, course_id, status
            FROM certificate_requests
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->execute(array($requestId));
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            throw new Exception('Certificate request not found.');
        }

        if ($request['status'] !== 'pending') {
            throw new Exception(
                'This request has already been reviewed.'
            );
        }

        $certificateNumber = null;

        if ($action === 'approve') {
            $userId = (int) $request['user_id'];
            $courseId = (int) $request['course_id'];

            // Recheck paid, active enrollment.
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM enrollments
                WHERE user_id = ?
                  AND course_id = ?
                  AND payment_status = 'paid'
                  AND access_status = 'active'
            ");
            $stmt->execute(array($userId, $courseId));

            if ((int) $stmt->fetchColumn() < 1) {
                throw new Exception(
                    'Cannot approve: the student has no active, paid enrollment.'
                );
            }

            // Recheck course completion.
            $stmt = $pdo->prepare("
                SELECT
                    COUNT(cv.id) AS total_videos,
                    COALESCE(SUM(
                        CASE WHEN p.completed = 1 THEN 1 ELSE 0 END
                    ), 0) AS completed_videos
                FROM course_videos cv
                LEFT JOIN student_video_progress p
                  ON p.video_id = cv.id
                 AND p.course_id = cv.course_id
                 AND p.user_id = ?
                WHERE cv.course_id = ?
                  AND cv.active = 1
            ");
            $stmt->execute(array($userId, $courseId));
            $videoStats = $stmt->fetch(PDO::FETCH_ASSOC);

            $totalVideos = (int) $videoStats['total_videos'];
            $completedVideos = (int) $videoStats['completed_videos'];

            if ($totalVideos === 0 || $completedVideos < $totalVideos) {
                throw new Exception(
                    'Cannot approve: the student has not completed all active course videos.'
                );
            }

            // Recheck passed exam.
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM exam_attempts ea
                INNER JOIN exams e ON e.id = ea.exam_id
                WHERE ea.user_id = ?
                  AND e.course_id = ?
                  AND e.active = 1
                  AND ea.status = 'submitted'
                  AND ea.result = 'passed'
            ");
            $stmt->execute(array($userId, $courseId));

            if ((int) $stmt->fetchColumn() < 1) {
                throw new Exception(
                    'Cannot approve: the student has not passed an exam for this course.'
                );
            }

            $certificateNumber = 'ACI-' .
                date('Y') . '-' .
                strtoupper(bin2hex(random_bytes(5)));

            $stmt = $pdo->prepare("
                UPDATE certificate_requests
                SET status = 'approved',
                    certificate_number = ?,
                    admin_note = ?,
                    reviewed_at = NOW(),
                    reviewed_by = ?
                WHERE id = ? AND status = 'pending'
            ");
            $stmt->execute(array(
                $certificateNumber,
                ($note !== '' ? $note : null),
                $adminId,
                $requestId
            ));

            if ($stmt->rowCount() !== 1) {
                throw new Exception(
                    'The request was changed by another administrator. Refresh and try again.'
                );
            }

            flash(
                'success',
                'Certificate approved. Number: ' . $certificateNumber
            );

        } else {
            $stmt = $pdo->prepare("
                UPDATE certificate_requests
                SET status = 'rejected',
                    certificate_number = NULL,
                    admin_note = ?,
                    reviewed_at = NOW(),
                    reviewed_by = ?
                WHERE id = ? AND status = 'pending'
            ");
            $stmt->execute(array($note, $adminId, $requestId));

            if ($stmt->rowCount() !== 1) {
                throw new Exception(
                    'The request was changed by another administrator. Refresh and try again.'
                );
            }

            flash('success', 'Certificate request rejected.');
        }

    } catch (Throwable $e) {
        if ($e instanceof PDOException) {
            error_log('Certificate review database error: ' . $e->getMessage());
            flash('error', 'A database error occurred while reviewing the request.');
        } else {
            flash('error', $e->getMessage());
        }
    }

    redirect(base_url(
        'assan_computer_institute/admin/certificate_requests.php'
    ));
}

$successMessage = flash('success');
$errorMessage = flash('error');

$stmt = $pdo->query("
    SELECT
        cr.id,
        cr.user_id,
        cr.course_id,
        cr.status,
        cr.certificate_number,
        cr.admin_note,
        cr.requested_at,
        cr.reviewed_at,
        u.full_name,
        u.email,
        u.mobile,
        c.title AS course_title
    FROM certificate_requests cr
    INNER JOIN users u ON u.id = cr.user_id
    INNER JOIN courses c ON c.id = cr.course_id
    ORDER BY
        CASE WHEN cr.status = 'pending' THEN 0 ELSE 1 END,
        cr.requested_at DESC
");
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
body { background: #f5f7fb; }
.cert-admin-page { padding: 28px 0 55px; }
.cert-admin-hero {
    background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
    color: white; border-radius: 18px;
    padding: 26px; margin-bottom: 22px;
}
.cert-admin-card {
    background: white; border: 1px solid #e2e8f0;
    border-radius: 15px; padding: 22px;
    margin-bottom: 18px;
    box-shadow: 0 8px 25px rgba(15,42,95,.05);
}
.muted { color: #64748b; }
.status-pill {
    display: inline-block; border-radius: 25px;
    padding: 6px 11px; font-size: 12px; font-weight: 700;
}
.pending { background: #fef3c7; color: #92400e; }
.approved { background: #dcfce7; color: #166534; }
.rejected { background: #fee2e2; color: #991b1b; }
</style>

<div class="container cert-admin-page">
    <div class="cert-admin-hero">
        <h2 class="mb-2">Certificate Requests</h2>
        <p class="mb-0">
            Review student eligibility and approve or reject course certificates.
        </p>
    </div>

    <?php if ($successMessage): ?>
        <div class="alert alert-success">
            <?= e($successMessage) ?>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage): ?>
        <div class="alert alert-danger">
            <?= e($errorMessage) ?>
        </div>
    <?php endif; ?>

    <?php if (!$requests): ?>
        <div class="alert alert-info">No certificate requests found.</div>
    <?php endif; ?>

    <?php foreach ($requests as $item): ?>
        <div class="cert-admin-card">
            <div class="d-flex flex-wrap justify-content-between gap-3">
                <div>
                    <h5 class="fw-bold mb-1">
                        <?= e($item['course_title']) ?>
                    </h5>
                    <div class="fw-semibold">
                        <?= e($item['full_name']) ?>
                    </div>
                    <div class="muted small">
                        <?= e($item['email']) ?>
                        <?php if ($item['mobile']): ?>
                            · <?= e($item['mobile']) ?>
                        <?php endif; ?>
                    </div>
                    <div class="muted small mt-2">
                        Requested: <?= e($item['requested_at']) ?>
                    </div>
                </div>

                <div>
                    <span class="status-pill <?= e($item['status']) ?>">
                        <?= e(strtoupper($item['status'])) ?>
                    </span>
                </div>
            </div>

            <?php if ($item['status'] === 'approved'): ?>
                <hr>
                <div class="text-success fw-semibold">
                    Certificate: <?= e($item['certificate_number']) ?>
                </div>
                <?php if (!empty($item['admin_note'])): ?>
                    <div class="muted small mt-1">
                        Admin note: <?= e($item['admin_note']) ?>
                    </div>
                <?php endif; ?>

            <?php elseif ($item['status'] === 'rejected'): ?>
                <hr>
                <div class="text-danger">
                    <strong>Rejection reason:</strong>
                    <?= e($item['admin_note']) ?>
                </div>

            <?php else: ?>
                <hr>

                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="request_id"
                           value="<?= (int) $item['id'] ?>">

                    <div class="mb-3">
                        <label class="form-label fw-semibold">
                            Admin note / rejection reason
                        </label>
                        <textarea name="admin_note" class="form-control"
                                  rows="2" maxlength="500"
                                  placeholder="Required when rejecting; optional when approving"></textarea>
                    </div>

                    <div class="d-flex flex-wrap gap-2">
                        <button type="submit" name="action" value="approve"
                                class="btn btn-success"
                                onclick="return confirm('Approve and issue this certificate?');">
                            Approve Certificate
                        </button>

                        <button type="submit" name="action" value="reject"
                                class="btn btn-outline-danger"
                                onclick="return confirm('Reject this certificate request?');">
                            Reject Request
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>

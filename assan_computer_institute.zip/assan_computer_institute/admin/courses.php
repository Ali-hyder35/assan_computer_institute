
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Manage Courses';

$message = '';
$messageType = '';

/*
|--------------------------------------------------------------------------
| Toggle Course
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $action = isset($_POST['action']) ? trim($_POST['action']) : '';
        $courseId = isset($_POST['course_id']) ? (int) $_POST['course_id'] : 0;

        if ($courseId <= 0) {
            throw new Exception('Invalid course selected.');
        }

        if ($action === 'toggle') {

            $stmt = $pdo->prepare("
                UPDATE courses
                SET active = IF(active = 1, 0, 1)
                WHERE id = ?
            ");

            $stmt->execute(array($courseId));

            $message = 'Course status updated successfully.';
            $messageType = 'success';

        } else {

            throw new Exception('Invalid action.');

        }

    } catch (Exception $e) {

        $message = $e->getMessage();
        $messageType = 'danger';

    }
}

/*
|--------------------------------------------------------------------------
| Courses
|--------------------------------------------------------------------------
*/
$stmt = $pdo->query("
    SELECT
        c.*,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            WHERE cv.course_id = c.id
        ) AS video_count,

        (
            SELECT COUNT(*)
            FROM enrollments e
            WHERE e.course_id = c.id
        ) AS enrollment_count

    FROM courses c
    ORDER BY c.created_at DESC
");

$courses = $stmt->fetchAll();

?>
<?php include dirname(__DIR__) . '/partials/header.php'; ?>
<style>

/* =========================================================
   ASSAN COMPUTER INSTITUTE
   PROFESSIONAL LMS - COURSES PAGE
   Scoped CSS
   ========================================================= */

.acip-courses-page {

    --acip-primary: #0f2a5f;
    --acip-primary-2: #1e4b8f;

    --acip-blue: #2563eb;
    --acip-blue-dark: #1d4ed8;

    --acip-bg: #f5f7fb;
    --acip-white: #ffffff;

    --acip-text: #172033;
    --acip-muted: #64748b;

    --acip-border: #e2e8f0;

    --acip-green: #16a34a;
    --acip-green-bg: #ecfdf3;

    --acip-red: #dc2626;
    --acip-red-bg: #fef2f2;

    width: 100%;
    min-height: auto;

    color: var(--acip-text);

    box-sizing: border-box;
}

.acip-courses-page *,
.acip-courses-page *::before,
.acip-courses-page *::after {
    box-sizing: border-box;
}


/* =========================================================
   MAIN CONTAINER
   ========================================================= */

.acip-courses-page .acip-container {

    width: 100%;
    max-width: 1500px;

    margin: 0 auto;

    padding: 28px 24px 35px;
}


/* =========================================================
   PAGE HEADER
   ========================================================= */

.acip-courses-page .acip-header {

    position: relative;

    width: 100%;

    margin-bottom: 25px;

    padding: 25px 27px;

    border-radius: 16px;

    overflow: hidden;

    background:
        linear-gradient(
            135deg,
            #0f2a5f 0%,
            #173d7a 48%,
            #2563eb 100%
        );

    box-shadow:
        0 8px 25px rgba(15, 42, 95, 0.12);
}


/* Decorative circle */

.acip-courses-page .acip-header::before {

    content: "";

    position: absolute;

    width: 280px;
    height: 280px;

    right: -120px;
    top: -175px;

    border-radius: 50%;

    background: rgba(255,255,255,0.05);

    pointer-events: none;
}

.acip-courses-page .acip-header::after {

    content: "";

    position: absolute;

    width: 200px;
    height: 200px;

    right: 150px;
    bottom: -155px;

    border-radius: 50%;

    background: rgba(255,255,255,0.035);

    pointer-events: none;
}


/* Header inner */

.acip-courses-page .acip-header-inner {

    position: relative;

    z-index: 2;

    width: 100%;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 25px;
}


/* Header title */

.acip-courses-page .acip-header-title {

    min-width: 0;

    display: flex;

    align-items: center;

    gap: 15px;
}


/* Header icon */

.acip-courses-page .acip-header-icon {

    width: 50px;
    height: 50px;

    flex: 0 0 50px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: rgba(255,255,255,0.12);

    border: 1px solid rgba(255,255,255,0.16);

    color: #ffffff;

    font-size: 21px;
}


/* Header text */

.acip-courses-page .acip-header-text {

    min-width: 0;
}

.acip-courses-page .acip-header-text h1 {

    margin: 0;

    color: #ffffff;

    font-size: 25px;

    font-weight: 700;

    line-height: 1.3;
}

.acip-courses-page .acip-header-text p {

    margin: 5px 0 0;

    color: #dbeafe;

    font-size: 13px;

    line-height: 1.55;
}


/* Add course button */

.acip-courses-page .acip-add-btn {

    flex: 0 0 auto;

    min-height: 43px;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 8px;

    padding: 10px 18px;

    border: 0;

    border-radius: 9px;

    background: #ffffff;

    color: var(--acip-primary);

    font-size: 13px;

    font-weight: 600;

    text-decoration: none;

    white-space: nowrap;

    transition:
        background 0.2s ease,
        color 0.2s ease,
        transform 0.2s ease,
        box-shadow 0.2s ease;
}

.acip-courses-page .acip-add-btn:hover {

    background: #eff6ff;

    color: var(--acip-blue);

    transform: translateY(-2px);

    box-shadow:
        0 6px 15px rgba(0,0,0,0.12);
}


/* =========================================================
   ALERT
   ========================================================= */

.acip-courses-page .acip-alert {

    display: flex;

    align-items: center;

    gap: 10px;

    width: 100%;

    margin-bottom: 20px;

    padding: 12px 15px;

    border-radius: 10px;

    font-size: 13px;

    line-height: 1.5;
}

.acip-courses-page .acip-alert-success {

    background: var(--acip-green-bg);

    border: 1px solid #bbf7d0;

    color: #166534;
}

.acip-courses-page .acip-alert-danger {

    background: var(--acip-red-bg);

    border: 1px solid #fecaca;

    color: #991b1b;
}


/* =========================================================
   COURSE GRID
   ========================================================= */

.acip-courses-page .acip-course-grid {

    width: 100%;

    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 22px;

    align-items: stretch;
}


/* =========================================================
   COURSE CARD
   ========================================================= */

.acip-courses-page .acip-course-card {

    position: relative;

    width: 100%;
    min-width: 0;

    display: flex;

    flex-direction: column;

    background: #ffffff;

    border: 1px solid var(--acip-border);

    border-radius: 15px;

    overflow: hidden;

    box-shadow:
        0 4px 16px rgba(15,42,95,0.055);

    transition:
        transform 0.2s ease,
        box-shadow 0.2s ease,
        border-color 0.2s ease;
}

.acip-courses-page .acip-course-card:hover {

    transform: translateY(-3px);

    border-color: #cbd5e1;

    box-shadow:
        0 12px 30px rgba(15,42,95,0.10);
}


/* =========================================================
   COURSE HEADER
   ========================================================= */

.acip-courses-page .acip-course-header {

    width: 100%;

    padding: 17px 18px;

    background:
        linear-gradient(
            135deg,
            #0f2a5f,
            #1e4b8f
        );
}

.acip-courses-page .acip-course-header-row {

    width: 100%;

    display: grid;

    grid-template-columns:
        40px minmax(0, 1fr) auto;

    align-items: start;

    gap: 11px;
}


/* Course icon */

.acip-courses-page .acip-course-icon {

    width: 40px;
    height: 40px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: rgba(255,255,255,0.12);

    border: 1px solid rgba(255,255,255,0.13);

    color: #ffffff;

    font-size: 15px;
}


/* Course title */

.acip-courses-page .acip-course-title {

    min-width: 0;

    margin: 0;

    padding-top: 2px;

    color: #ffffff;

    font-size: 16px;

    font-weight: 700;

    line-height: 1.4;

    overflow-wrap: anywhere;
}


/* =========================================================
   STATUS
   ========================================================= */

.acip-courses-page .acip-status {

    display: inline-flex;

    align-items: center;

    gap: 5px;

    padding: 6px 9px;

    border-radius: 30px;

    font-size: 10px;

    font-weight: 700;

    line-height: 1;

    white-space: nowrap;
}

.acip-courses-page .acip-status-active {

    color: #15803d;

    background: #dcfce7;
}

.acip-courses-page .acip-status-inactive {

    color: #b91c1c;

    background: #fee2e2;
}

.acip-courses-page .acip-status-dot {

    width: 6px;
    height: 6px;

    flex: 0 0 6px;

    border-radius: 50%;

    background: currentColor;
}


/* =========================================================
   COURSE CONTENT
   ========================================================= */

.acip-courses-page .acip-course-content {

    flex: 1;

    display: flex;

    flex-direction: column;

    min-width: 0;

    padding: 20px;
}


/* =========================================================
   PRICE / DURATION
   ========================================================= */

.acip-courses-page .acip-course-meta {

    width: 100%;

    display: flex;

    align-items: flex-start;

    justify-content: space-between;

    gap: 15px;

    margin-bottom: 15px;
}

.acip-courses-page .acip-price-label {

    margin-bottom: 3px;

    color: var(--acip-muted);

    font-size: 9px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 0.8px;
}

.acip-courses-page .acip-price {

    color: var(--acip-blue);

    font-size: 22px;

    font-weight: 800;

    line-height: 1.2;

    white-space: nowrap;
}

.acip-courses-page .acip-duration {

    display: flex;

    align-items: center;

    gap: 6px;

    padding-top: 7px;

    color: var(--acip-muted);

    font-size: 12px;

    white-space: nowrap;
}

.acip-courses-page .acip-duration i {

    color: var(--acip-blue);

    font-size: 12px;
}


/* =========================================================
   DESCRIPTION
   ========================================================= */

.acip-courses-page .acip-description {

    min-height: 54px;

    margin-bottom: 17px;

    color: var(--acip-muted);

    font-size: 12px;

    line-height: 1.65;

    overflow-wrap: anywhere;
}

.acip-courses-page .acip-description-empty {

    color: #94a3b8;

    font-style: italic;
}


/* =========================================================
   STATISTICS
   ========================================================= */

.acip-courses-page .acip-stats {

    width: 100%;

    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 9px;

    margin-bottom: 18px;
}

.acip-courses-page .acip-stat {

    min-width: 0;

    display: flex;

    align-items: center;

    gap: 8px;

    padding: 10px;

    border: 1px solid var(--acip-border);

    border-radius: 10px;

    background: #f8fafc;
}

.acip-courses-page .acip-stat-icon {

    width: 31px;
    height: 31px;

    flex: 0 0 31px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background: #dbeafe;

    color: var(--acip-blue);

    font-size: 12px;
}

.acip-courses-page .acip-stat-text {

    min-width: 0;
}

.acip-courses-page .acip-stat-number {

    margin: 0;

    color: var(--acip-primary);

    font-size: 16px;

    font-weight: 700;

    line-height: 1.2;
}

.acip-courses-page .acip-stat-label {

    margin-top: 2px;

    color: var(--acip-muted);

    font-size: 9px;

    line-height: 1.2;
}


/* =========================================================
   ACTIONS
   ========================================================= */

.acip-courses-page .acip-actions {

    width: 100%;

    margin-top: auto;
}


/* Manage videos */

.acip-courses-page .acip-manage-btn {

    width: 100%;

    min-height: 40px;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    padding: 9px 12px;

    border: 1px solid var(--acip-blue);

    border-radius: 9px;

    background: var(--acip-blue);

    color: #ffffff;

    font-size: 12px;

    font-weight: 600;

    text-decoration: none;

    transition:
        background 0.2s ease,
        border-color 0.2s ease,
        box-shadow 0.2s ease,
        transform 0.2s ease;
}

.acip-courses-page .acip-manage-btn:hover {

    background: var(--acip-blue-dark);

    border-color: var(--acip-blue-dark);

    color: #ffffff;

    transform: translateY(-1px);

    box-shadow:
        0 5px 13px rgba(37,99,235,0.20);
}


/* =========================================================
   SECONDARY ACTIONS
   ========================================================= */

.acip-courses-page .acip-secondary-actions {

    width: 100%;

    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 8px;

    margin-top: 8px;
}

.acip-courses-page .acip-secondary-actions form {

    width: 100%;

    margin: 0;
}

.acip-courses-page .acip-secondary-btn {

    width: 100%;

    min-height: 38px;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 6px;

    padding: 7px 9px;

    border-radius: 8px;

    font-size: 11px;

    font-weight: 600;

    line-height: 1.2;

    text-decoration: none;

    cursor: pointer;

    transition:
        background 0.2s ease,
        color 0.2s ease,
        border-color 0.2s ease,
        box-shadow 0.2s ease;
}


/* Edit */

.acip-courses-page .acip-edit-btn {

    background: #ffffff;

    color: var(--acip-blue);

    border: 1px solid #bfdbfe;
}

.acip-courses-page .acip-edit-btn:hover {

    background: var(--acip-blue);

    color: #ffffff;

    border-color: var(--acip-blue);
}


/* Toggle */

.acip-courses-page .acip-toggle-btn {

    background: #ffffff;

    color: #475569;

    border: 1px solid #cbd5e1;
}

.acip-courses-page .acip-toggle-btn:hover {

    background: #475569;

    color: #ffffff;

    border-color: #475569;
}


/* =========================================================
   DELETE
   ========================================================= */

.acip-courses-page .acip-delete-area {

    width: 100%;

    margin-top: 9px;

    padding-top: 9px;

    border-top: 1px solid #f1f5f9;
}

.acip-courses-page .acip-delete-area form {

    width: 100%;

    margin: 0;
}

.acip-courses-page .acip-delete-btn {

    width: 100%;

    min-height: 34px;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 6px;

    padding: 6px 9px;

    border: 1px solid #fecaca;

    border-radius: 8px;

    background: #ffffff;

    color: var(--acip-red);

    font-size: 10px;

    font-weight: 600;

    cursor: pointer;

    transition:
        background 0.2s ease,
        color 0.2s ease,
        border-color 0.2s ease;
}

.acip-courses-page .acip-delete-btn:hover {

    background: var(--acip-red);

    border-color: var(--acip-red);

    color: #ffffff;
}


/* =========================================================
   EMPTY STATE
   ========================================================= */

.acip-courses-page .acip-empty {

    width: 100%;

    padding: 70px 25px;

    text-align: center;

    background: #ffffff;

    border: 1px solid var(--acip-border);

    border-radius: 15px;

    box-shadow:
        0 4px 16px rgba(15,42,95,0.055);
}

.acip-courses-page .acip-empty-icon {

    width: 70px;
    height: 70px;

    margin: 0 auto 16px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 16px;

    background: #eff6ff;

    color: var(--acip-primary-2);

    font-size: 27px;
}

.acip-courses-page .acip-empty h3 {

    margin: 0 0 7px;

    color: var(--acip-text);

    font-size: 19px;

    font-weight: 700;
}

.acip-courses-page .acip-empty p {

    max-width: 430px;

    margin: 0 auto 20px;

    color: var(--acip-muted);

    font-size: 13px;

    line-height: 1.6;
}

.acip-courses-page .acip-empty-btn {

    width: auto;

    max-width: 220px;

    margin: 0 auto;
}


/* =========================================================
   GENERAL LINK PROTECTION
   ========================================================= */

.acip-courses-page a {

    text-decoration: none;
}

.acip-courses-page a:hover {

    text-decoration: none;
}

.acip-courses-page button {

    font-family: inherit;
}


/* =========================================================
   TABLET
   ========================================================= */

@media (max-width: 1200px) {

    .acip-courses-page .acip-course-grid {

        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }
}


/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 767px) {

    .acip-courses-page .acip-container {

        padding: 18px 15px 28px;
    }

    .acip-courses-page .acip-header {

        padding: 20px;

        margin-bottom: 18px;

        border-radius: 13px;
    }

    .acip-courses-page .acip-header-inner {

        flex-direction: column;

        align-items: stretch;

        gap: 18px;
    }

    .acip-courses-page .acip-header-title {

        gap: 11px;
    }

    .acip-courses-page .acip-header-icon {

        width: 43px;
        height: 43px;

        flex-basis: 43px;

        font-size: 18px;
    }

    .acip-courses-page .acip-header-text h1 {

        font-size: 20px;
    }

    .acip-courses-page .acip-header-text p {

        font-size: 11px;
    }

    .acip-courses-page .acip-add-btn {

        width: 100%;
    }

    .acip-courses-page .acip-course-grid {

        grid-template-columns:
            minmax(0, 1fr);

        gap: 16px;
    }

    .acip-courses-page .acip-course-content {

        padding: 17px;
    }
}


/* =========================================================
   SMALL MOBILE
   ========================================================= */

@media (max-width: 480px) {

    .acip-courses-page .acip-container {

        padding: 12px 10px 24px;
    }

    .acip-courses-page .acip-header {

        padding: 17px;

        border-radius: 12px;
    }

    .acip-courses-page .acip-header-title {

        gap: 10px;
    }

    .acip-courses-page .acip-header-icon {

        width: 40px;
        height: 40px;

        flex-basis: 40px;

        font-size: 16px;
    }

    .acip-courses-page .acip-header-text h1 {

        font-size: 19px;
    }

    .acip-courses-page .acip-header-text p {

        font-size: 11px;
    }

    .acip-courses-page .acip-course-header {

        padding: 15px;
    }

    .acip-courses-page .acip-course-header-row {

        grid-template-columns:
            36px minmax(0, 1fr);
    }

    .acip-courses-page .acip-course-icon {

        width: 36px;
        height: 36px;
    }

    .acip-courses-page .acip-course-title {

        font-size: 14px;
    }

    .acip-courses-page .acip-status {

        grid-column: 2;

        justify-self: start;

        margin-top: 1px;
    }

    .acip-courses-page .acip-course-meta {

        flex-direction: column;

        gap: 6px;
    }

    .acip-courses-page .acip-duration {

        padding-top: 0;
    }

    .acip-courses-page .acip-stats {

        gap: 7px;
    }

    .acip-courses-page .acip-stat {

        padding: 8px;
    }

    .acip-courses-page .acip-stat-icon {

        width: 28px;
        height: 28px;

        flex-basis: 28px;
    }
}


/* =========================================================
   REDUCE MOTION
   ========================================================= */

@media (prefers-reduced-motion: reduce) {

    .acip-courses-page *,
    .acip-courses-page *::before,
    .acip-courses-page *::after {

        transition: none !important;

        animation: none !important;
    }
}

</style>


<div class="acip-courses-page">

    <div class="acip-container">

        <?php if ($message !== ''): ?>

            <div class="acip-alert
                <?php
                echo $messageType === 'success'
                    ? 'acip-alert-success'
                    : 'acip-alert-danger';
                ?>">

                <?php if ($messageType === 'success'): ?>

                    <i class="fa-solid fa-circle-check"></i>

                <?php else: ?>

                    <i class="fa-solid fa-circle-exclamation"></i>

                <?php endif; ?>

                <span>
                    <?php echo e($message); ?>
                </span>

            </div>

        <?php endif; ?>


        <!-- =====================================================
             PAGE HEADER
             ===================================================== -->

        <div class="acip-header">

            <div class="acip-header-inner">

                <div class="acip-header-title">

                    <div class="acip-header-icon">

                        <i class="fa-solid fa-graduation-cap"></i>

                    </div>

                    <div class="acip-header-text">

                        <h1>Manage Courses</h1>

                        <p>
                            Create courses, manage lessons and control course availability.
                        </p>

                    </div>

                </div>


                <a
                    href="<?php echo e(base_url('assan_computer_institute/admin/add_course.php')); ?>"
                    class="acip-add-btn"
                >

                    <i class="fa-solid fa-plus"></i>

                    Add New Course

                </a>

            </div>

        </div>


        <!-- =====================================================
             COURSE LIST
             ===================================================== -->

        <?php if (!$courses): ?>

            <div class="acip-empty">

                <div class="acip-empty-icon">

                    <i class="fa-solid fa-book-open"></i>

                </div>

                <h3>
                    No Courses Found
                </h3>

                <p>
                    You have not added any courses yet.
                    Create your first course to start building your LMS.
                </p>

                <a
                    href="<?php echo e(base_url('assan_computer_institute/admin/course_add.php')); ?>"
                    class="acip-manage-btn acip-empty-btn"
                >

                    <i class="fa-solid fa-plus"></i>

                    Add First Course

                </a>

            </div>


        <?php else: ?>


            <div class="acip-course-grid">


                <?php foreach ($courses as $course): ?>


                    <div class="acip-course-card">


                        <!-- =================================================
                             COURSE HEADER
                             ================================================= -->

                        <div class="acip-course-header">

                            <div class="acip-course-header-row">


                                <div class="acip-course-icon">

                                    <i class="fa-solid fa-book"></i>

                                </div>


                                <h2 class="acip-course-title">

                                    <?php echo e($course['title']); ?>

                                </h2>


                                <?php if ((int) $course['active'] === 1): ?>

                                    <span class="acip-status acip-status-active">

                                        <span class="acip-status-dot"></span>

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="acip-status acip-status-inactive">

                                        <span class="acip-status-dot"></span>

                                        Inactive

                                    </span>

                                <?php endif; ?>


                            </div>

                        </div>


                        <!-- =================================================
                             COURSE CONTENT
                             ================================================= -->

                        <div class="acip-course-content">


                            <!-- PRICE / DURATION -->

                            <div class="acip-course-meta">


                                <div>

                                    <div class="acip-price-label">
                                        Course Fee
                                    </div>

                                    <div class="acip-price">

                                        <?php echo e(money($course['price'])); ?>

                                    </div>

                                </div>


                                <?php if (!empty($course['duration'])): ?>

                                    <div class="acip-duration">

                                        <i class="fa-regular fa-clock"></i>

                                        <span>
                                            <?php echo e($course['duration']); ?>
                                        </span>

                                    </div>

                                <?php endif; ?>


                            </div>


                            <!-- DESCRIPTION -->

                            <?php if (!empty($course['description'])): ?>

                                <div class="acip-description">

                                    <?php

                                    $description = trim($course['description']);

                                    if (strlen($description) > 120) {

                                        $description =
                                            substr($description, 0, 120) . '...';

                                    }

                                    echo e($description);

                                    ?>

                                </div>

                            <?php else: ?>

                                <div class="acip-description acip-description-empty">

                                    No course description available.

                                </div>

                            <?php endif; ?>


                            <!-- =================================================
                                 STATISTICS
                                 ================================================= -->

                            <div class="acip-stats">


                                <!-- Lessons -->

                                <div class="acip-stat">

                                    <div class="acip-stat-icon">

                                        <i class="fa-solid fa-video"></i>

                                    </div>

                                    <div class="acip-stat-text">

                                        <div class="acip-stat-number">

                                            <?php
                                            echo (int) $course['video_count'];
                                            ?>

                                        </div>

                                        <div class="acip-stat-label">

                                            Lessons

                                        </div>

                                    </div>

                                </div>


                                <!-- Students -->

                                <div class="acip-stat">

                                    <div class="acip-stat-icon">

                                        <i class="fa-solid fa-users"></i>

                                    </div>

                                    <div class="acip-stat-text">

                                        <div class="acip-stat-number">

                                            <?php
                                            echo (int) $course['enrollment_count'];
                                            ?>

                                        </div>

                                        <div class="acip-stat-label">

                                            Students

                                        </div>

                                    </div>

                                </div>


                            </div>


                            <!-- =================================================
                                 ACTIONS
                                 ================================================= -->

                            <div class="acip-actions">


                                <!-- Manage Videos -->

                                <a
                                    href="<?php
                                    echo e(
                                        base_url(
                                            'assan_computer_institute/admin/course_videos.php?course_id=' .
                                            (int) $course['id']
                                        )
                                    );
                                    ?>"
                                    class="acip-manage-btn"
                                >

                                    <i class="fa-solid fa-video"></i>

                                    Manage Videos

                                </a>


                                <!-- Edit / Toggle -->

                                <div class="acip-secondary-actions">


                                    <!-- Edit -->

                                    <a
                                        href="<?php
                                        echo e(
                                            base_url(
                                                'assan_computer_institute/admin/course_edit.php?id=' .
                                                (int) $course['id']
                                            )
                                        );
                                        ?>"
                                        class="acip-secondary-btn acip-edit-btn"
                                    >

                                        <i class="fa-solid fa-pen"></i>

                                        Edit

                                    </a>


                                    <!-- Toggle -->

                                    <form method="post">

                                        <?php echo csrf_field(); ?>

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="toggle"
                                        >

                                        <input
                                            type="hidden"
                                            name="course_id"
                                            value="<?php
                                            echo (int) $course['id'];
                                            ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="acip-secondary-btn acip-toggle-btn"
                                        >

                                            <?php if (
                                                (int) $course['active'] === 1
                                            ): ?>

                                                <i class="fa-solid fa-toggle-off"></i>

                                                Disable

                                            <?php else: ?>

                                                <i class="fa-solid fa-toggle-on"></i>

                                                Activate

                                            <?php endif; ?>

                                        </button>

                                    </form>


                                </div>


                                <!-- Delete -->

                                <div class="acip-delete-area">

                                    <form
                                        method="post"
                                        action="<?php
                                        echo e(
                                            base_url(
                                                'assan_computer_institute/admin/course_delete.php'
                                            )
                                        );
                                        ?>"
                                        onsubmit="return confirm('Are you sure you want to delete this course? All course videos will also be deleted.');"
                                    >

                                        <?php echo csrf_field(); ?>


                                        <input
                                            type="hidden"
                                            name="course_id"
                                            value="<?php
                                            echo (int) $course['id'];
                                            ?>"
                                        >


                                        <button
                                            type="submit"
                                            class="acip-delete-btn"
                                        >

                                            <i class="fa-solid fa-trash"></i>

                                            Delete Course

                                        </button>

                                    </form>

                                </div>


                            </div>


                        </div>

                    </div>


                <?php endforeach; ?>


            </div>


        <?php endif; ?>


    </div>

</div>


<?php include dirname(__DIR__) . '/partials/footer.php'; ?>


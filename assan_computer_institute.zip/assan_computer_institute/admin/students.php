
<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Admin - Student Management
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Manage Students';

$message = '';
$messageType = 'success';

/*
|--------------------------------------------------------------------------
| Handle Student Status Updates
|--------------------------------------------------------------------------
| Only account status is changed. Student records are not deleted.
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();

        $action = isset($_POST['action'])
            ? trim($_POST['action'])
            : '';

        $studentId = isset($_POST['student_id'])
            ? (int) $_POST['student_id']
            : 0;

        if ($studentId <= 0) {
            throw new Exception('Invalid student selected.');
        }

        if (!in_array($action, array('activate', 'block'), true)) {
            throw new Exception('Invalid action.');
        }

        /*
        | Confirm this is a student account.
        | Admin accounts cannot be modified through this page.
        */

        $checkStmt = $pdo->prepare("
            SELECT id, full_name, status
            FROM users
            WHERE id = ?
              AND role = 'student'
            LIMIT 1
        ");

        $checkStmt->execute(array($studentId));
        $studentToUpdate = $checkStmt->fetch();

        if (!$studentToUpdate) {
            throw new Exception('Student account not found.');
        }

        $newStatus = ($action === 'activate')
            ? 'active'
            : 'blocked';

        $updateStmt = $pdo->prepare("
            UPDATE users
            SET status = ?
            WHERE id = ?
              AND role = 'student'
        ");

        $updateStmt->execute(array($newStatus, $studentId));

        $message = ($newStatus === 'active')
            ? 'Student account activated successfully.'
            : 'Student account blocked successfully.';

        $messageType = 'success';

    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'danger';
    }
}

/*
|--------------------------------------------------------------------------
| Search, Filter and Pagination
|--------------------------------------------------------------------------
*/

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$statusFilter = isset($_GET['status'])
    ? trim($_GET['status'])
    : 'all';

$allowedStatuses = array('all', 'active', 'blocked');

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = 'all';
}

$page = isset($_GET['page'])
    ? max(1, (int) $_GET['page'])
    : 1;

$perPage = 10;

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

$statsStmt = $pdo->query("
    SELECT
        COUNT(*) AS total_students,
        COALESCE(SUM(status = 'active'), 0) AS active_students,
        COALESCE(SUM(status = 'blocked'), 0) AS blocked_students
    FROM users
    WHERE role = 'student'
");

$stats = $statsStmt->fetch();

$totalStudents = (int) $stats['total_students'];
$activeStudents = (int) $stats['active_students'];
$blockedStudents = (int) $stats['blocked_students'];

/*
|--------------------------------------------------------------------------
| Build Student Filters
|--------------------------------------------------------------------------
*/

$where = array("u.role = 'student'");
$params = array();

if ($search !== '') {
    $where[] = "(
        u.full_name LIKE ?
        OR u.email LIKE ?
        OR u.mobile LIKE ?
    )";

    $searchTerm = '%' . $search . '%';

    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if ($statusFilter !== 'all') {
    $where[] = 'u.status = ?';
    $params[] = $statusFilter;
}

$whereSql = implode(' AND ', $where);

/*
|--------------------------------------------------------------------------
| Count Filtered Students
|--------------------------------------------------------------------------
*/

$countSql = "
    SELECT COUNT(*)
    FROM users u
    WHERE {$whereSql}
";

$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);

$filteredStudents = (int) $countStmt->fetchColumn();

$totalPages = max(
    1,
    (int) ceil($filteredStudents / $perPage)
);

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| Fetch Students and Enrollment Statistics
|--------------------------------------------------------------------------
*/

$studentsSql = "
    SELECT
        u.id,
        u.full_name,
        u.email,
        u.mobile,
        u.status,
        u.created_at,

        (
            SELECT COUNT(*)
            FROM enrollments e
            WHERE e.user_id = u.id
        ) AS total_enrollments,

        (
            SELECT COUNT(*)
            FROM enrollments e
            WHERE e.user_id = u.id
              AND e.payment_status = 'paid'
              AND e.access_status = 'active'
        ) AS active_enrollments

    FROM users u

    WHERE {$whereSql}

    ORDER BY u.created_at DESC, u.id DESC

    LIMIT {$perPage} OFFSET {$offset}
";

$studentsStmt = $pdo->prepare($studentsSql);
$studentsStmt->execute($params);

$students = $studentsStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Pagination URL Helper
|--------------------------------------------------------------------------
*/

function students_page_url($pageNumber)
{
    $query = $_GET;
    $query['page'] = (int) $pageNumber;

    return base_url(
        'assan_computer_institute/admin/students.php'
    ) . '?' . http_build_query($query);
}

include dirname(__DIR__) . '/partials/header.php';

?>

<style>
    .acip-students-page {
        background: #f5f7fb;
        min-height: calc(100vh - 80px);
        padding: 30px 0 50px;
    }

    .acip-students-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 18px;
        padding: 28px 30px;
        margin-bottom: 25px;
        box-shadow: 0 10px 30px rgba(15, 42, 95, .12);
    }

    .acip-students-header h2 {
        margin: 0;
        font-size: 25px;
        font-weight: 750;
    }

    .acip-students-header p {
        margin: 8px 0 0;
        color: rgba(255,255,255,.78);
        font-size: 14px;
    }

    .acip-header-button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: rgba(255,255,255,.12);
        border: 1px solid rgba(255,255,255,.25);
        color: #fff;
        border-radius: 10px;
        padding: 11px 16px;
        font-size: 13px;
        font-weight: 650;
        text-decoration: none;
    }

    .acip-header-button:hover {
        background: rgba(255,255,255,.2);
        color: #fff;
    }

    .acip-stat-card {
        height: 100%;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 21px;
        box-shadow: 0 5px 20px rgba(15,42,95,.04);
    }

    .acip-stat-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 18px;
    }

    .acip-stat-label {
        color: #64748b;
        font-size: 13px;
        font-weight: 600;
    }

    .acip-stat-icon {
        width: 45px;
        height: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 13px;
        font-size: 19px;
    }

    .acip-icon-blue {
        background: #eff6ff;
        color: #2563eb;
    }

    .acip-icon-green {
        background: #dcfce7;
        color: #15803d;
    }

    .acip-icon-orange {
        background: #fff7ed;
        color: #c2410c;
    }

    .acip-stat-number {
        color: #0f2a5f;
        font-size: 30px;
        font-weight: 800;
        line-height: 1.2;
    }

    .acip-stat-note {
        margin-top: 6px;
        color: #94a3b8;
        font-size: 12px;
    }

    .acip-panel {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        box-shadow: 0 5px 20px rgba(15,42,95,.04);
        overflow: hidden;
        margin-top: 25px;
    }

    .acip-panel-heading {
        padding: 22px 24px;
        border-bottom: 1px solid #edf0f5;
    }

    .acip-panel-heading h3 {
        color: #0f2a5f;
        font-size: 18px;
        font-weight: 750;
        margin: 0;
    }

    .acip-panel-heading p {
        color: #64748b;
        font-size: 13px;
        margin: 6px 0 0;
    }

    .acip-filter-area {
        padding: 20px 24px;
        border-bottom: 1px solid #edf0f5;
        background: #fcfdff;
    }

    .acip-filter-label {
        display: block;
        margin-bottom: 7px;
        color: #334155;
        font-size: 12px;
        font-weight: 700;
    }

    .acip-filter-control {
        width: 100%;
        min-height: 43px;
        border: 1px solid #dbe3ef;
        border-radius: 10px;
        background: #fff;
        padding: 9px 12px;
        color: #334155;
        font-size: 13px;
        outline: none;
    }

    .acip-filter-control:focus {
        border-color: #60a5fa;
        box-shadow: 0 0 0 3px rgba(37,99,235,.1);
    }

    .acip-filter-button {
        width: 100%;
        min-height: 43px;
        border: 0;
        border-radius: 10px;
        padding: 10px 14px;
        background: #2563eb;
        color: #fff;
        font-size: 13px;
        font-weight: 700;
    }

    .acip-filter-button:hover {
        background: #1d4ed8;
    }

    .acip-reset-link {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 43px;
        padding: 10px 14px;
        border-radius: 10px;
        background: #f1f5f9;
        color: #475569;
        font-size: 13px;
        font-weight: 650;
        text-decoration: none;
    }

    .acip-reset-link:hover {
        background: #e2e8f0;
        color: #0f2a5f;
    }

    .acip-table-wrap {
        width: 100%;
        overflow-x: auto;
    }

    .acip-students-table {
        width: 100%;
        min-width: 900px;
        border-collapse: separate;
        border-spacing: 0;
        margin: 0;
    }

    .acip-students-table thead th {
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
        padding: 14px 16px;
        color: #64748b;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .45px;
        white-space: nowrap;
    }

    .acip-students-table tbody td {
        padding: 16px;
        border-bottom: 1px solid #edf0f5;
        vertical-align: middle;
        color: #334155;
        font-size: 13px;
    }

    .acip-students-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .acip-students-table tbody tr:hover {
        background: #fbfdff;
    }

    .acip-student-identity {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 200px;
    }

    .acip-student-avatar {
        width: 43px;
        height: 43px;
        border-radius: 13px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        background: #eaf1ff;
        color: #1d4ed8;
        font-size: 16px;
        font-weight: 800;
        text-transform: uppercase;
    }

    .acip-student-name {
        color: #0f2a5f;
        font-size: 13px;
        font-weight: 750;
        overflow-wrap: anywhere;
    }

    .acip-student-id {
        margin-top: 4px;
        color: #94a3b8;
        font-size: 11px;
    }

    .acip-contact {
        overflow-wrap: anywhere;
        min-width: 170px;
    }

    .acip-contact-email {
        color: #334155;
        font-weight: 550;
    }

    .acip-contact-mobile {
        margin-top: 5px;
        color: #94a3b8;
        font-size: 12px;
    }

    .acip-status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border-radius: 20px;
        padding: 6px 10px;
        font-size: 11px;
        font-weight: 750;
        white-space: nowrap;
    }

    .acip-status-active {
        background: #dcfce7;
        color: #166534;
    }

    .acip-status-blocked {
        background: #fee2e2;
        color: #991b1b;
    }

    .acip-status-unknown {
        background: #f1f5f9;
        color: #64748b;
    }

    .acip-enrollment-count {
        color: #0f2a5f;
        font-size: 15px;
        font-weight: 800;
    }

    .acip-enrollment-caption {
        color: #94a3b8;
        font-size: 11px;
        margin-top: 3px;
    }

    .acip-student-action {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        border: 0;
        border-radius: 8px;
        padding: 9px 11px;
        font-size: 11px;
        font-weight: 750;
        cursor: pointer;
        white-space: nowrap;
    }

    .acip-action-block {
        background: #fff7ed;
        color: #c2410c;
    }

    .acip-action-block:hover {
        background: #ffedd5;
    }

    .acip-action-activate {
        background: #dcfce7;
        color: #166534;
    }

    .acip-action-activate:hover {
        background: #bbf7d0;
    }

    .acip-no-results {
        padding: 55px 20px;
        text-align: center;
    }

    .acip-no-results-icon {
        width: 65px;
        height: 65px;
        border-radius: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        background: #eff6ff;
        color: #2563eb;
        font-size: 25px;
    }

    .acip-no-results h4 {
        color: #0f2a5f;
        font-size: 17px;
        font-weight: 750;
    }

    .acip-no-results p {
        color: #64748b;
        font-size: 13px;
    }

    .acip-pagination {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        flex-wrap: wrap;
        padding: 18px 24px;
        border-top: 1px solid #edf0f5;
    }

    .acip-pagination-info {
        color: #64748b;
        font-size: 12px;
    }

    .acip-pagination-links {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
    }

    .acip-page-link {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 35px;
        height: 35px;
        padding: 0 10px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        background: #fff;
        color: #475569;
        font-size: 12px;
        font-weight: 700;
        text-decoration: none;
    }

    .acip-page-link:hover {
        border-color: #93c5fd;
        color: #1d4ed8;
    }

    .acip-page-link-current {
        border-color: #2563eb;
        background: #2563eb;
        color: #fff;
    }

    .acip-page-link-disabled {
        opacity: .4;
        pointer-events: none;
    }

    @media (max-width: 767px) {
        .acip-students-page {
            padding-top: 20px;
        }

        .acip-students-header {
            padding: 22px;
        }

        .acip-students-header h2 {
            font-size: 22px;
        }

        .acip-panel-heading,
        .acip-filter-area {
            padding: 18px;
        }

        .acip-pagination {
            padding: 16px 18px;
        }
    }
</style>

<div class="acip-students-page">
    <div class="container-fluid px-3 px-lg-4">

        <!-- Page Header -->

        <div class="acip-students-header">
            <div class="row align-items-center g-3">

                <div class="col-lg-8">
                    <h2>
                        <i class="fa-solid fa-users me-2"></i>
                        Student Management
                    </h2>

                    <p>
                        View student accounts, monitor enrollments,
                        and manage account access.
                    </p>
                </div>

                <div class="col-lg-4">
                    <div class="d-flex justify-content-lg-end">
                        <a href="<?= e(base_url(
                            'assan_computer_institute/admin/dashboard.php'
                        )) ?>"
                           class="acip-header-button">
                            <i class="fa-solid fa-arrow-left"></i>
                            Back to Dashboard
                        </a>
                    </div>
                </div>

            </div>
        </div>

        <!-- Flash / Action Message -->

        <?php if ($message !== ''): ?>
            <div class="alert alert-<?= e($messageType) ?> alert-dismissible fade show"
                 role="alert">
                <i class="fa-solid <?= $messageType === 'success'
                    ? 'fa-circle-check'
                    : 'fa-circle-exclamation' ?> me-2"></i>

                <?= e($message) ?>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Statistics -->

        <div class="row g-3">

            <div class="col-12 col-md-4">
                <div class="acip-stat-card">
                    <div class="acip-stat-top">
                        <span class="acip-stat-label">Total Students</span>

                        <span class="acip-stat-icon acip-icon-blue">
                            <i class="fa-solid fa-users"></i>
                        </span>
                    </div>

                    <div class="acip-stat-number">
                        <?= number_format($totalStudents) ?>
                    </div>

                    <div class="acip-stat-note">
                        All registered student accounts
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="acip-stat-card">
                    <div class="acip-stat-top">
                        <span class="acip-stat-label">Active Students</span>

                        <span class="acip-stat-icon acip-icon-green">
                            <i class="fa-solid fa-user-check"></i>
                        </span>
                    </div>

                    <div class="acip-stat-number">
                        <?= number_format($activeStudents) ?>
                    </div>

                    <div class="acip-stat-note">
                        Accounts currently marked active
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="acip-stat-card">
                    <div class="acip-stat-top">
                        <span class="acip-stat-label">Blocked Students</span>

                        <span class="acip-stat-icon acip-icon-orange">
                            <i class="fa-solid fa-user-lock"></i>
                        </span>
                    </div>

                    <div class="acip-stat-number">
                        <?= number_format($blockedStudents) ?>
                    </div>

                    <div class="acip-stat-note">
                        Accounts with access blocked
                    </div>
                </div>
            </div>

        </div>

        <!-- Student Management Table -->

        <div class="acip-panel">

            <div class="acip-panel-heading">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <h3>
                            <i class="fa-solid fa-address-book me-2"></i>
                            Registered Students
                        </h3>

                        <p>
                            Search student records and manage account status.
                        </p>
                    </div>

                    <span class="badge text-bg-light border">
                        <?= number_format($filteredStudents) ?> results
                    </span>
                </div>
            </div>

            <!-- Search and Filters -->

            <div class="acip-filter-area">
                <form method="get"
                      action="<?= e(base_url(
                          'assan_computer_institute/admin/students.php'
                      )) ?>">

                    <div class="row g-3 align-items-end">

                        <div class="col-12 col-lg-6">
                            <label for="studentSearch"
                                   class="acip-filter-label">
                                Search Students
                            </label>

                            <input type="text"
                                   id="studentSearch"
                                   name="search"
                                   class="acip-filter-control"
                                   placeholder="Search name, email or mobile..."
                                   value="<?= e($search) ?>">
                        </div>

                        <div class="col-12 col-sm-6 col-lg-3">
                            <label for="studentStatus"
                                   class="acip-filter-label">
                                Account Status
                            </label>

                            <select id="studentStatus"
                                    name="status"
                                    class="acip-filter-control">

                                <option value="all"
                                    <?= $statusFilter === 'all'
                                        ? 'selected'
                                        : '' ?>>
                                    All Students
                                </option>

                                <option value="active"
                                    <?= $statusFilter === 'active'
                                        ? 'selected'
                                        : '' ?>>
                                    Active
                                </option>

                                <option value="blocked"
                                    <?= $statusFilter === 'blocked'
                                        ? 'selected'
                                        : '' ?>>
                                    Blocked
                                </option>

                            </select>
                        </div>

                        <div class="col-6 col-sm-3 col-lg-1">
                            <button type="submit"
                                    class="acip-filter-button">
                                <i class="fa-solid fa-search"></i>
                            </button>
                        </div>

                        <div class="col-6 col-sm-3 col-lg-2">
                            <a href="<?= e(base_url(
                                'assan_computer_institute/admin/students.php'
                            )) ?>"
                               class="acip-reset-link w-100">
                                <i class="fa-solid fa-rotate-left me-2"></i>
                                Reset
                            </a>
                        </div>

                    </div>
                </form>
            </div>

            <!-- Students Table -->

            <?php if (empty($students)): ?>

                <div class="acip-no-results">
                    <div class="acip-no-results-icon">
                        <i class="fa-solid fa-user-slash"></i>
                    </div>

                    <h4>No Students Found</h4>

                    <p class="mb-3">
                        No student records match your current search or filters.
                    </p>

                    <a href="<?= e(base_url(
                        'assan_computer_institute/admin/students.php'
                    )) ?>"
                       class="acip-reset-link">
                        <i class="fa-solid fa-rotate-left me-2"></i>
                        View All Students
                    </a>
                </div>

            <?php else: ?>

                <div class="acip-table-wrap">
                    <table class="acip-students-table">

                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Contact Information</th>
                                <th>Enrollments</th>
                                <th>Account Status</th>
                                <th>Registration Date</th>
                                <th>Account Action</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($students as $student): ?>

                                <?php
                                $studentStatus = isset($student['status'])
                                    ? $student['status']
                                    : '';

                                $studentName = trim(
                                    (string) $student['full_name']
                                );

                                $avatarLetter = $studentName !== ''
                                    ? function_exists('mb_substr')
                                        ? mb_substr($studentName, 0, 1, 'UTF-8')
                                        : substr($studentName, 0, 1)
                                    : '?';

                                $avatarLetter = function_exists('mb_strtoupper')
                                    ? mb_strtoupper($avatarLetter, 'UTF-8')
                                    : strtoupper($avatarLetter);
                                ?>

                                <tr>

                                    <!-- Student Identity -->

                                    <td>
                                        <div class="acip-student-identity">

                                            <div class="acip-student-avatar">
                                                <?= e($avatarLetter) ?>
                                            </div>

                                            <div>
                                                <div class="acip-student-name">
                                                    <?= e($studentName) ?>
                                                </div>

                                                <div class="acip-student-id">
                                                    Student ID:
                                                    #<?= (int) $student['id'] ?>
                                                </div>
                                            </div>

                                        </div>
                                    </td>

                                    <!-- Contact -->

                                    <td>
                                        <div class="acip-contact">

                                            <div class="acip-contact-email">
                                                <i class="fa-regular fa-envelope me-1"></i>
                                                <?= e($student['email']) ?>
                                            </div>

                                            <div class="acip-contact-mobile">
                                                <i class="fa-solid fa-phone me-1"></i>

                                                <?= !empty($student['mobile'])
                                                    ? e($student['mobile'])
                                                    : 'Not provided' ?>
                                            </div>

                                        </div>
                                    </td>

                                    <!-- Enrollment Counts -->

                                    <td>
                                        <div class="acip-enrollment-count">
                                            <?= (int) $student['total_enrollments'] ?>
                                        </div>

                                        <div class="acip-enrollment-caption">
                                            Total enrollments
                                        </div>

                                        <div class="acip-enrollment-caption">
                                            <?= (int) $student['active_enrollments'] ?>
                                            active paid course(s)
                                        </div>
                                    </td>

                                    <!-- Account Status -->

                                    <td>
                                        <?php if ($studentStatus === 'active'): ?>

                                            <span class="acip-status acip-status-active">
                                                <i class="fa-solid fa-circle-check"></i>
                                                Active
                                            </span>

                                        <?php elseif ($studentStatus === 'blocked'): ?>

                                            <span class="acip-status acip-status-blocked">
                                                <i class="fa-solid fa-ban"></i>
                                                Blocked
                                            </span>

                                        <?php else: ?>

                                            <span class="acip-status acip-status-unknown">
                                                <?= e($studentStatus ?: 'Unknown') ?>
                                            </span>

                                        <?php endif; ?>
                                    </td>

                                    <!-- Registration Date -->

                                    <td>
                                        <?php if (!empty($student['created_at'])): ?>

                                            <div>
                                                <?= e(date(
                                                    'd M Y',
                                                    strtotime($student['created_at'])
                                                )) ?>
                                            </div>

                                            <div class="acip-enrollment-caption">
                                                <?= e(date(
                                                    'h:i A',
                                                    strtotime($student['created_at'])
                                                )) ?>
                                            </div>

                                        <?php else: ?>

                                            <span class="text-muted">N/A</span>

                                        <?php endif; ?>
                                    </td>

                                    <!-- Account Action -->

                                    <td>
                                        <?php if ($studentStatus === 'active'): ?>

                                            <form method="post"
                                                  action="<?= e(base_url(
                                                      'assan_computer_institute/admin/students.php'
                                                  )) ?>"
                                                  onsubmit="return confirm('Block this student account? The student may lose access to protected areas if your login checks enforce the blocked status.');">

                                                <?= csrf_field() ?>

                                                <input type="hidden"
                                                       name="student_id"
                                                       value="<?= (int) $student['id'] ?>">

                                                <input type="hidden"
                                                       name="action"
                                                       value="block">

                                                <button type="submit"
                                                        class="acip-student-action acip-action-block">
                                                    <i class="fa-solid fa-lock"></i>
                                                    Block Account
                                                </button>

                                            </form>

                                        <?php elseif ($studentStatus === 'blocked'): ?>

                                            <form method="post"
                                                  action="<?= e(base_url(
                                                      'assan_computer_institute/admin/students.php'
                                                  )) ?>"
                                                  onsubmit="return confirm('Activate this student account?');">

                                                <?= csrf_field() ?>

                                                <input type="hidden"
                                                       name="student_id"
                                                       value="<?= (int) $student['id'] ?>">

                                                <input type="hidden"
                                                       name="action"
                                                       value="activate">

                                                <button type="submit"
                                                        class="acip-student-action acip-action-activate">
                                                    <i class="fa-solid fa-unlock"></i>
                                                    Activate
                                                </button>

                                            </form>

                                        <?php else: ?>

                                            <span class="text-muted small">
                                                No action available
                                            </span>

                                        <?php endif; ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>
                </div>

                <!-- Pagination -->

                <div class="acip-pagination">

                    <?php
                    $firstResult = $filteredStudents > 0
                        ? $offset + 1
                        : 0;

                    $lastResult = min(
                        $offset + $perPage,
                        $filteredStudents
                    );
                    ?>

                    <div class="acip-pagination-info">
                        Showing
                        <strong><?= $firstResult ?></strong>
                        to
                        <strong><?= $lastResult ?></strong>
                        of
                        <strong><?= number_format($filteredStudents) ?></strong>
                        students
                    </div>

                    <?php if ($totalPages > 1): ?>

                        <div class="acip-pagination-links">

                            <a href="<?= e(students_page_url(max(1, $page - 1))) ?>"
                               class="acip-page-link <?= $page <= 1
                                   ? 'acip-page-link-disabled'
                                   : '' ?>">
                                <i class="fa-solid fa-chevron-left"></i>
                            </a>

                            <?php
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            ?>

                            <?php if ($startPage > 1): ?>

                                <a href="<?= e(students_page_url(1)) ?>"
                                   class="acip-page-link">1</a>

                                <?php if ($startPage > 2): ?>
                                    <span class="px-1 text-muted">...</span>
                                <?php endif; ?>

                            <?php endif; ?>

                            <?php for (
                                $pageNumber = $startPage;
                                $pageNumber <= $endPage;
                                $pageNumber++
                            ): ?>

                                <a href="<?= e(students_page_url($pageNumber)) ?>"
                                   class="acip-page-link <?= $pageNumber === $page
                                       ? 'acip-page-link-current'
                                       : '' ?>">
                                    <?= $pageNumber ?>
                                </a>

                            <?php endfor; ?>

                            <?php if ($endPage < $totalPages): ?>

                                <?php if ($endPage < $totalPages - 1): ?>
                                    <span class="px-1 text-muted">...</span>
                                <?php endif; ?>

                                <a href="<?= e(students_page_url($totalPages)) ?>"
                                   class="acip-page-link">
                                    <?= $totalPages ?>
                                </a>

                            <?php endif; ?>

                            <a href="<?= e(students_page_url(min(
                                $totalPages,
                                $page + 1
                            ))) ?>"
                               class="acip-page-link <?= $page >= $totalPages
                                   ? 'acip-page-link-disabled'
                                   : '' ?>">
                                <i class="fa-solid fa-chevron-right"></i>
                            </a>

                        </div>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </div>

    </div>
</div>

<?php include dirname(__DIR__) . '/partials/footer.php'; ?>

```php
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Delete Course Lesson';

$videoId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($videoId <= 0) {
    flash('error', 'Invalid video selected.');
    header('Location: ' . base_url('assan_computer_institute/admin/courses.php'));
    exit;
}

/*
|--------------------------------------------------------------------------
| Get Video
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare("
    SELECT
        v.id,
        v.course_id,
        v.title,
        v.description,
        v.video_url,
        v.lesson_no,
        v.duration,
        v.active,
        c.title AS course_title
    FROM course_videos v
    INNER JOIN courses c ON c.id = v.course_id
    WHERE v.id = ?
    LIMIT 1
");

$stmt->execute(array($videoId));

$video = $stmt->fetch();

if (!$video) {
    flash('error', 'Course video not found.');
    header('Location: ' . base_url('assan_computer_institute/admin/courses.php'));
    exit;
}

$courseId = (int) $video['course_id'];

include dirname(__DIR__) . '/partials/header.php';
?>

<style>
    .acip-delete-page {
        background: #f5f7fb;
        min-height: calc(100vh - 80px);
        padding: 50px 0;
    }

    .acip-delete-card {
        max-width: 650px;
        margin: 0 auto;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 35px;
        box-shadow: 0 10px 35px rgba(15,42,95,.08);
        text-align: center;
    }

    .acip-danger-icon {
        width: 75px;
        height: 75px;
        margin: 0 auto 20px;
        border-radius: 20px;
        background: #fef2f2;
        color: #dc2626;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
    }

    .acip-delete-card h2 {
        color: #0f2a5f;
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 10px;
    }

    .acip-delete-card .lead-text {
        color: #64748b;
        font-size: 14px;
        line-height: 1.7;
    }

    .acip-video-info {
        text-align: left;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 13px;
        padding: 18px;
        margin: 25px 0;
    }

    .acip-video-info-row {
        display: flex;
        justify-content: space-between;
        gap: 15px;
        padding: 8px 0;
        border-bottom: 1px solid #e2e8f0;
        font-size: 13px;
    }

    .acip-video-info-row:last-child {
        border-bottom: 0;
    }

    .acip-video-info-label {
        color: #64748b;
        font-weight: 600;
    }

    .acip-video-info-value {
        color: #0f2a5f;
        font-weight: 600;
        text-align: right;
        word-break: break-word;
    }

    .acip-warning {
        background: #fff7ed;
        border: 1px solid #fed7aa;
        color: #9a3412;
        border-radius: 12px;
        padding: 13px 16px;
        font-size: 13px;
        text-align: left;
        margin-bottom: 25px;
    }

    .acip-actions {
        display: flex;
        justify-content: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .acip-btn {
        border: 0;
        border-radius: 10px;
        padding: 11px 18px;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        cursor: pointer;
    }

    .acip-btn-secondary {
        background: #f1f5f9;
        color: #475569;
    }

    .acip-btn-danger {
        background: #dc2626;
        color: #fff;
    }

    .acip-btn-danger:hover {
        background: #b91c1c;
        color: #fff;
    }
</style>

<div class="acip-delete-page">
    <div class="container">

        <div class="acip-delete-card">

            <div class="acip-danger-icon">
                <i class="fa-solid fa-trash-can"></i>
            </div>

            <h2>Delete Lesson?</h2>

            <p class="lead-text">
                You are about to permanently delete this lesson from the course.
                This action cannot be undone.
            </p>

            <div class="acip-video-info">

                <div class="acip-video-info-row">
                    <span class="acip-video-info-label">
                        Course
                    </span>

                    <span class="acip-video-info-value">
                        <?= e($video['course_title']) ?>
                    </span>
                </div>

                <div class="acip-video-info-row">
                    <span class="acip-video-info-label">
                        Lesson
                    </span>

                    <span class="acip-video-info-value">
                        #<?= (int) $video['lesson_no'] ?>
                    </span>
                </div>

                <div class="acip-video-info-row">
                    <span class="acip-video-info-label">
                        Title
                    </span>

                    <span class="acip-video-info-value">
                        <?= e($video['title']) ?>
                    </span>
                </div>

                <?php if (!empty($video['duration'])): ?>
                    <div class="acip-video-info-row">
                        <span class="acip-video-info-label">
                            Duration
                        </span>

                        <span class="acip-video-info-value">
                            <?= e($video['duration']) ?>
                        </span>
                    </div>
                <?php endif; ?>

            </div>

            <div class="acip-warning">
                <i class="fa-solid fa-triangle-exclamation me-2"></i>

                The lesson record and its video information will be permanently
                removed from this course.
            </div>

            <div class="acip-actions">

                <a href="<?= e(base_url(
                    'assan_computer_institute/admin/course_videos.php?course_id=' . $courseId
                )) ?>"
                   class="acip-btn acip-btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i>
                    Cancel
                </a>

                <form method="post"
                      action="<?= e(base_url('assan_computer_institute/admin/course_video_delete.php')) ?>">

                    <?= csrf_field() ?>

                    <input type="hidden"
                           name="id"
                           value="<?= $videoId ?>">

                    <input type="hidden"
                           name="course_id"
                           value="<?= $courseId ?>">

                    <button type="submit"
                            class="acip-btn acip-btn-danger"
                            onclick="return confirm('Permanently delete this lesson?');">

                        <i class="fa-solid fa-trash"></i>
                        Delete Permanently

                    </button>

                </form>

            </div>

        </div>

    </div>
</div>

<?php

/*
|--------------------------------------------------------------------------
| Actual POST Delete
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $postVideoId = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        $postCourseId = isset($_POST['course_id']) ? (int) $_POST['course_id'] : 0;

        if ($postVideoId <= 0 || $postCourseId <= 0) {
            throw new Exception('Invalid lesson information.');
        }

        /*
        |--------------------------------------------------------------------------
        | Verify Video Belongs To Course
        |--------------------------------------------------------------------------
        */
        $checkStmt = $pdo->prepare("
            SELECT id
            FROM course_videos
            WHERE id = ?
              AND course_id = ?
            LIMIT 1
        ");

        $checkStmt->execute(array(
            $postVideoId,
            $postCourseId
        ));

        if (!$checkStmt->fetch()) {
            throw new Exception('Lesson not found.');
        }

        /*
        |--------------------------------------------------------------------------
        | Delete
        |--------------------------------------------------------------------------
        */
        $deleteStmt = $pdo->prepare("
            DELETE FROM course_videos
            WHERE id = ?
              AND course_id = ?
        ");

        $deleteStmt->execute(array(
            $postVideoId,
            $postCourseId
        ));

        if ($deleteStmt->rowCount() < 1) {
            throw new Exception('Lesson could not be deleted.');
        }

        flash('success', 'Lesson deleted successfully.');

        header(
            'Location: ' .
            base_url('assan_computer_institute/admin/course_videos.php?course_id=' . $postCourseId)
        );

        exit;

    } catch (Exception $e) {

        flash('error', $e->getMessage());

        header(
            'Location: ' .
            base_url('assan_computer_institute/admin/course_videos.php?course_id=' . $courseId)
        );

        exit;

    } catch (PDOException $e) {

        flash('error', 'Database error. The lesson could not be deleted.');

        header(
            'Location: ' .
            base_url('assan_computer_institute/admin/course_videos.php?course_id=' . $courseId)
        );

        exit;
    }
}

?>


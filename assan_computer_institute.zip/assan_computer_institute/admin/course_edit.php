```php
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Edit Course';

$message = '';
$messageType = '';

$courseId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($courseId <= 0) {

    header(
        'Location: ' .
        base_url('assan_computer_institute/admin/courses.php')
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Load Course
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM courses
    WHERE id = ?
    LIMIT 1
");

$stmt->execute(array($courseId));

$course = $stmt->fetch();

if (!$course) {

    header(
        'Location: ' .
        base_url('assan_computer_institute/admin/courses.php')
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Form Values
|--------------------------------------------------------------------------
*/

$title = $course['title'];
$slug = $course['slug'];
$description = $course['description'];
$price = $course['price'];
$duration = $course['duration'];
$active = (int) $course['active'];


/*
|--------------------------------------------------------------------------
| Generate Slug
|--------------------------------------------------------------------------
*/

function generate_edit_course_slug($text)
{
    $text = strtolower(trim($text));

    $text = preg_replace('/[^a-z0-9]+/', '-', $text);

    return trim($text, '-');
}


/*
|--------------------------------------------------------------------------
| Update Course
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $title = isset($_POST['title'])
            ? trim($_POST['title'])
            : '';

        $slug = isset($_POST['slug'])
            ? trim($_POST['slug'])
            : '';

        $description = isset($_POST['description'])
            ? trim($_POST['description'])
            : '';

        $price = isset($_POST['price'])
            ? trim($_POST['price'])
            : '';

        $duration = isset($_POST['duration'])
            ? trim($_POST['duration'])
            : '';

        $active = isset($_POST['active'])
            ? 1
            : 0;


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {
            throw new Exception('Course title is required.');
        }

        if (strlen($title) > 180) {
            throw new Exception(
                'Course title cannot exceed 180 characters.'
            );
        }

        if ($slug === '') {
            $slug = generate_edit_course_slug($title);
        } else {
            $slug = generate_edit_course_slug($slug);
        }

        if ($slug === '') {
            throw new Exception('Please enter a valid course slug.');
        }

        if (strlen($slug) > 190) {
            throw new Exception(
                'Course slug cannot exceed 190 characters.'
            );
        }

        if ($price === '' || !is_numeric($price)) {
            throw new Exception('Please enter a valid course price.');
        }

        $priceValue = (float) $price;

        if ($priceValue < 0) {
            throw new Exception(
                'Course price cannot be negative.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Duplicate Slug Check
        |--------------------------------------------------------------------------
        */

        $check = $pdo->prepare("
            SELECT id
            FROM courses
            WHERE slug = ?
            AND id <> ?
            LIMIT 1
        ");

        $check->execute(array(
            $slug,
            $courseId
        ));

        if ($check->fetch()) {

            throw new Exception(
                'This course slug is already being used by another course.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Update
        |--------------------------------------------------------------------------
        */

        $update = $pdo->prepare("
            UPDATE courses
            SET
                title = ?,
                slug = ?,
                description = ?,
                price = ?,
                duration = ?,
                active = ?
            WHERE id = ?
        ");

        $update->execute(array(
            $title,
            $slug,
            $description !== '' ? $description : null,
            $priceValue,
            $duration !== '' ? $duration : null,
            $active,
            $courseId
        ));


        /*
        |--------------------------------------------------------------------------
        | Redirect
        |--------------------------------------------------------------------------
        */

        header(
            'Location: ' .
            base_url('assan_computer_institute/admin/courses.php?success=course_updated')
        );

        exit;


    } catch (Exception $e) {

        $message = $e->getMessage();

        $messageType = 'danger';
    }
}

?>


<style>

/* =========================================================
   EDIT COURSE
   ========================================================= */

.acip-edit-page {

    --primary: #0f2a5f;
    --blue: #2563eb;
    --blue-dark: #1d4ed8;

    --text: #172033;
    --muted: #64748b;
    --border: #e2e8f0;

    width: 100%;

    color: var(--text);
}

.acip-edit-container {

    width: 100%;

    max-width: 1000px;

    margin: 0 auto;

    padding: 28px 24px 40px;
}


/* Header */

.acip-edit-header {

    margin-bottom: 22px;

    padding: 25px 27px;

    border-radius: 16px;

    background:
        linear-gradient(
            135deg,
            #0f2a5f,
            #173d7a,
            #2563eb
        );

    box-shadow:
        0 8px 25px rgba(15,42,95,.12);

    color: #fff;
}

.acip-edit-header-inner {

    display: flex;

    align-items: center;

    gap: 15px;
}

.acip-edit-header-icon {

    width: 50px;
    height: 50px;

    flex: 0 0 50px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: rgba(255,255,255,.12);

    border: 1px solid rgba(255,255,255,.15);
}

.acip-edit-header h1 {

    margin: 0;

    font-size: 24px;

    font-weight: 700;
}

.acip-edit-header p {

    margin: 5px 0 0;

    color: #dbeafe;

    font-size: 13px;
}


/* Alert */

.acip-edit-alert {

    display: flex;

    align-items: center;

    gap: 10px;

    margin-bottom: 20px;

    padding: 12px 15px;

    border-radius: 10px;

    color: #991b1b;

    background: #fef2f2;

    border: 1px solid #fecaca;

    font-size: 13px;
}


/* Card */

.acip-edit-card {

    background: #fff;

    border: 1px solid var(--border);

    border-radius: 15px;

    box-shadow:
        0 5px 20px rgba(15,42,95,.06);

    overflow: hidden;
}

.acip-edit-card-header {

    padding: 18px 22px;

    background: #f8fafc;

    border-bottom: 1px solid var(--border);
}

.acip-edit-card-header h2 {

    margin: 0;

    color: var(--primary);

    font-size: 16px;

    font-weight: 700;
}

.acip-edit-card-body {

    padding: 25px;
}


/* Form */

.acip-edit-group {

    margin-bottom: 20px;
}

.acip-edit-group label {

    display: block;

    margin-bottom: 7px;

    font-size: 12px;

    font-weight: 600;
}

.acip-edit-group label span {

    color: #dc2626;
}

.acip-edit-control {

    width: 100%;

    min-height: 43px;

    padding: 10px 12px;

    border: 1px solid #cbd5e1;

    border-radius: 8px;

    background: #fff;

    color: var(--text);

    font-family: inherit;

    font-size: 13px;

    outline: none;

    transition: all .2s ease;
}

.acip-edit-control:focus {

    border-color: var(--blue);

    box-shadow:
        0 0 0 3px rgba(37,99,235,.10);
}

textarea.acip-edit-control {

    min-height: 150px;

    resize: vertical;

    line-height: 1.6;
}

.acip-edit-row {

    display: grid;

    grid-template-columns:
        repeat(2,minmax(0,1fr));

    gap: 18px;
}


/* Status */

.acip-edit-status {

    display: flex;

    align-items: center;

    gap: 9px;

    color: var(--muted);

    font-size: 13px;
}

.acip-edit-status input {

    width: 17px;
    height: 17px;

    accent-color: var(--blue);
}


/* Actions */

.acip-edit-actions {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 12px;

    margin-top: 10px;

    padding-top: 20px;

    border-top: 1px solid var(--border);
}

.acip-edit-btn {

    min-height: 41px;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    padding: 9px 16px;

    border-radius: 8px;

    font-size: 12px;

    font-weight: 600;

    text-decoration: none;

    cursor: pointer;

    transition: all .2s ease;
}

.acip-edit-save {

    border: 1px solid var(--blue);

    background: var(--blue);

    color: #fff;
}

.acip-edit-save:hover {

    background: var(--blue-dark);

    color: #fff;
}

.acip-edit-back {

    border: 1px solid #cbd5e1;

    background: #fff;

    color: #475569;
}

.acip-edit-back:hover {

    background: #f8fafc;

    color: var(--primary);
}


/* Mobile */

@media(max-width:767px) {

    .acip-edit-container {

        padding: 18px 15px 30px;
    }

    .acip-edit-header {

        padding: 20px;
    }

    .acip-edit-header h1 {

        font-size: 20px;
    }

    .acip-edit-row {

        grid-template-columns: 1fr;

        gap: 0;
    }

    .acip-edit-card-body {

        padding: 18px;
    }

    .acip-edit-actions {

        flex-direction: column-reverse;

        align-items: stretch;
    }

    .acip-edit-btn {

        width: 100%;
    }
}

</style>


<div class="acip-edit-page">

    <div class="acip-edit-container">


        <div class="acip-edit-header">

            <div class="acip-edit-header-inner">

                <div class="acip-edit-header-icon">

                    <i class="fa-solid fa-pen-to-square"></i>

                </div>

                <div>

                    <h1>Edit Course</h1>

                    <p>
                        Update course information and availability.
                    </p>

                </div>

            </div>

        </div>


        <?php if ($message !== ''): ?>

            <div class="acip-edit-alert">

                <i class="fa-solid fa-circle-exclamation"></i>

                <?php echo e($message); ?>

            </div>

        <?php endif; ?>


        <div class="acip-edit-card">

            <div class="acip-edit-card-header">

                <h2>

                    <i class="fa-solid fa-book"></i>

                    Course Information

                </h2>

            </div>


            <div class="acip-edit-card-body">

                <form method="post">

                    <?php echo csrf_field(); ?>


                    <div class="acip-edit-group">

                        <label>
                            Course Title <span>*</span>
                        </label>

                        <input
                            type="text"
                            name="title"
                            class="acip-edit-control"
                            value="<?php echo e($title); ?>"
                            maxlength="180"
                            required
                        >

                    </div>


                    <div class="acip-edit-group">

                        <label>
                            Course Slug <span>*</span>
                        </label>

                        <input
                            type="text"
                            name="slug"
                            class="acip-edit-control"
                            value="<?php echo e($slug); ?>"
                            maxlength="190"
                            required
                        >

                    </div>


                    <div class="acip-edit-row">

                        <div class="acip-edit-group">

                            <label>
                                Course Fee <span>*</span>
                            </label>

                            <input
                                type="number"
                                name="price"
                                class="acip-edit-control"
                                value="<?php echo e($price); ?>"
                                min="0"
                                step="0.01"
                                required
                            >

                        </div>


                        <div class="acip-edit-group">

                            <label>
                                Duration
                            </label>

                            <input
                                type="text"
                                name="duration"
                                class="acip-edit-control"
                                value="<?php echo e($duration); ?>"
                                maxlength="80"
                                placeholder="e.g. 3 Months"
                            >

                        </div>

                    </div>


                    <div class="acip-edit-group">

                        <label>
                            Course Description
                        </label>

                        <textarea
                            name="description"
                            class="acip-edit-control"
                        ><?php echo e($description); ?></textarea>

                    </div>


                    <div class="acip-edit-group">

                        <label class="acip-edit-status">

                            <input
                                type="checkbox"
                                name="active"
                                value="1"
                                <?php echo $active === 1 ? 'checked' : ''; ?>
                            >

                            Course is active

                        </label>

                    </div>


                    <div class="acip-edit-actions">

                        <a
                            href="<?php echo e(base_url('admin/courses.php')); ?>"
                            class="acip-edit-btn acip-edit-back"
                        >

                            <i class="fa-solid fa-arrow-left"></i>

                            Back to Courses

                        </a>


                        <button
                            type="submit"
                            class="acip-edit-btn acip-edit-save"
                        >

                            <i class="fa-solid fa-floppy-disk"></i>

                            Save Changes

                        </button>

                    </div>


                </form>

            </div>

        </div>


    </div>

</div>


<?php include dirname(__DIR__) . '/partials/footer.php'; ?>
```

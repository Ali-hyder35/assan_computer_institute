<?php
/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Admin - Certificate Register / Issued Certificate Log
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';
require_admin();

$pageTitle = 'Certificate Register';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$status = isset($_GET['status'])
    ? trim($_GET['status'])
    : 'all';

$allowedStatuses = array(
    'all',
    'approved',
    'pending',
    'rejected'
);

if (!in_array($status, $allowedStatuses, true)) {
    $status = 'all';
}

/*
|--------------------------------------------------------------------------
| Summary Counts
|--------------------------------------------------------------------------
*/

$summary = array(
    'all' => 0,
    'approved' => 0,
    'pending' => 0,
    'rejected' => 0
);

$stmt = $pdo->query("
    SELECT status, COUNT(*) AS total
    FROM certificate_requests
    GROUP BY status
");

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $item) {
    $key = $item['status'];

    if (isset($summary[$key])) {
        $summary[$key] = (int) $item['total'];
    }
}

$summary['all'] =
    $summary['approved'] +
    $summary['pending'] +
    $summary['rejected'];

/*
|--------------------------------------------------------------------------
| Certificate Register Query
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        cr.id,
        cr.user_id,
        cr.course_id,
        cr.status,
        cr.certificate_number,
        cr.admin_note,
        cr.requested_at,
        cr.reviewed_at,
        cr.reviewed_by,

        u.full_name,
        u.email,
        u.mobile,

        c.title AS course_title,

        reviewer.full_name AS reviewer_name

    FROM certificate_requests cr

    INNER JOIN users u
        ON u.id = cr.user_id

    INNER JOIN courses c
        ON c.id = cr.course_id

    LEFT JOIN users reviewer
        ON reviewer.id = cr.reviewed_by

    WHERE 1 = 1
";

$params = array();

if ($status !== 'all') {
    $sql .= " AND cr.status = ?";
    $params[] = $status;
}

if ($search !== '') {
    $sql .= "
        AND (
            u.full_name LIKE ?
            OR u.email LIKE ?
            OR c.title LIKE ?
            OR cr.certificate_number LIKE ?
        )
    ";

    $searchTerm = '%' . $search . '%';

    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

$sql .= "
    ORDER BY
        CASE
            WHEN cr.status = 'pending' THEN 0
            WHEN cr.status = 'approved' THEN 1
            ELSE 2
        END,
        cr.reviewed_at DESC,
        cr.requested_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$certificates = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/partials/header.php';

?>

<style>
body {
    background: #f4f7fc;
    color: #172033;
}

.certificate-admin-page {
    padding: 30px 0 55px;
    min-height: 75vh;
}

.certificate-hero {
    background: linear-gradient(135deg, #14295f, #1f3c88, #376bc8);
    border-radius: 22px;
    padding: 30px;
    color: #fff;
    margin-bottom: 25px;
    box-shadow: 0 15px 35px rgba(31, 60, 136, .14);
}

.certificate-hero h2 {
    font-size: 26px;
    font-weight: 800;
}

.certificate-hero p {
    color: rgba(255,255,255,.75);
    font-size: 13px;
    margin-bottom: 0;
}

.certificate-stat {
    background: #fff;
    border: 1px solid #e5eaf2;
    border-radius: 17px;
    padding: 20px;
    height: 100%;
    box-shadow: 0 5px 18px rgba(25,40,75,.04);
}

.certificate-stat-label {
    color: #8992a4;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .6px;
}

.certificate-stat-number {
    display: block;
    font-size: 28px;
    font-weight: 800;
    color: #172033;
    margin-top: 7px;
}

.certificate-stat-icon {
    width: 43px;
    height: 43px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    margin-bottom: 15px;
}

.cert-card {
    background: #fff;
    border: 1px solid #e5eaf2;
    border-radius: 19px;
    overflow: hidden;
    box-shadow: 0 7px 25px rgba(25,40,75,.05);
}

.cert-card-header {
    padding: 22px;
    border-bottom: 1px solid #e9edf4;
}

.cert-card-header h5 {
    font-size: 15px;
    font-weight: 800;
    margin-bottom: 5px;
}

.cert-card-header p {
    color: #8992a4;
    font-size: 11px;
    margin-bottom: 0;
}

.cert-search {
    border: 1px solid #dfe5ef;
    border-radius: 10px;
    padding: 10px 13px;
    font-size: 12px;
}

.cert-search:focus {
    border-color: #1f3c88;
    box-shadow: 0 0 0 3px rgba(31,60,136,.08);
}

.cert-table {
    margin: 0;
}

.cert-table thead th {
    background: #f8faff;
    color: #697386;
    border-bottom: 1px solid #e5eaf2;
    padding: 14px 16px;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .55px;
    white-space: nowrap;
}

.cert-table tbody td {
    padding: 16px;
    border-bottom: 1px solid #edf0f5;
    vertical-align: middle;
    font-size: 11px;
}

.cert-table tbody tr:hover {
    background: #fafbff;
}

.cert-table tbody tr:last-child td {
    border-bottom: 0;
}

.cert-student {
    color: #172033;
    font-weight: 800;
    font-size: 12px;
}

.cert-muted {
    color: #8992a4;
    font-size: 10px;
    margin-top: 4px;
}

.cert-number {
    display: inline-block;
    font-family: monospace;
    font-size: 10px;
    font-weight: 700;
    color: #1f3c88;
    background: #edf2ff;
    padding: 7px 9px;
    border-radius: 7px;
    overflow-wrap: anywhere;
}

.cert-status {
    display: inline-block;
    border-radius: 30px;
    padding: 6px 10px;
    font-size: 9px;
    font-weight: 800;
    white-space: nowrap;
}

.cert-approved {
    color: #16834b;
    background: #eaf8ef;
}

.cert-pending {
    color: #ae6800;
    background: #fff4df;
}

.cert-rejected {
    color: #c0392b;
    background: #fff0ed;
}

.cert-empty {
    text-align: center;
    padding: 55px 20px;
    color: #8992a4;
}

.cert-empty i {
    font-size: 35px;
    color: #b9c4d6;
    margin-bottom: 15px;
}

.cert-filter-link {
    display: inline-block;
    text-decoration: none;
    border-radius: 8px;
    padding: 8px 11px;
    color: #596477;
    background: #f3f5f9;
    font-size: 10px;
    font-weight: 800;
}

.cert-filter-link.active {
    background: #1f3c88;
    color: #fff;
}

@media print {
    header,
    footer,
    .no-print {
        display: none !important;
    }

    body {
        background: #fff;
    }

    .certificate-admin-page {
        padding: 0;
    }

    .cert-card,
    .certificate-stat {
        box-shadow: none;
    }
}
</style>

<div class="container certificate-admin-page">

    <!-- PAGE HEADER -->

    <div class="certificate-hero">
        <div class="d-flex flex-wrap justify-content-between
                    align-items-center gap-3">

            <div>
                <h2>
                    <i class="fa-solid fa-certificate me-2"></i>
                    Certificate Register
                </h2>

                <p>
                    Track issued certificates, student applications,
                    approval history and rejection records.
                </p>
            </div>

            <a
                href="<?= e(base_url(
                    'assan_computer_institute/admin/certificate_requests.php'
                )) ?>"
                class="btn btn-light btn-sm fw-bold">

                <i class="fa-solid fa-clipboard-check me-1"></i>
                Review Requests

            </a>

        </div>
    </div>


    <!-- SUMMARY CARDS -->

    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-3">
            <div class="certificate-stat">

                <div class="certificate-stat-icon"
                     style="background:#edf2ff;color:#1f3c88;">

                    <i class="fa-solid fa-layer-group"></i>

                </div>

                <div class="certificate-stat-label">
                    Total Records
                </div>

                <span class="certificate-stat-number">
                    <?= (int) $summary['all'] ?>
                </span>

            </div>
        </div>


        <div class="col-6 col-lg-3">
            <div class="certificate-stat">

                <div class="certificate-stat-icon"
                     style="background:#eaf8ef;color:#16834b;">

                    <i class="fa-solid fa-certificate"></i>

                </div>

                <div class="certificate-stat-label">
                    Certificates Issued
                </div>

                <span class="certificate-stat-number">
                    <?= (int) $summary['approved'] ?>
                </span>

            </div>
        </div>


        <div class="col-6 col-lg-3">
            <div class="certificate-stat">

                <div class="certificate-stat-icon"
                     style="background:#fff4df;color:#ae6800;">

                    <i class="fa-solid fa-clock"></i>

                </div>

                <div class="certificate-stat-label">
                    Pending Review
                </div>

                <span class="certificate-stat-number">
                    <?= (int) $summary['pending'] ?>
                </span>

            </div>
        </div>


        <div class="col-6 col-lg-3">
            <div class="certificate-stat">

                <div class="certificate-stat-icon"
                     style="background:#fff0ed;color:#c0392b;">

                    <i class="fa-solid fa-ban"></i>

                </div>

                <div class="certificate-stat-label">
                    Rejected Requests
                </div>

                <span class="certificate-stat-number">
                    <?= (int) $summary['rejected'] ?>
                </span>

            </div>
        </div>

    </div>


    <!-- CERTIFICATE TABLE -->

    <div class="cert-card">

        <div class="cert-card-header">

            <div class="d-flex flex-wrap
                        justify-content-between
                        align-items-center gap-3">

                <div>
                    <h5>Certificate History</h5>
                    <p>
                        Approved records are the officially issued
                        certificates in this register.
                    </p>
                </div>

                <button
                    type="button"
                    onclick="window.print()"
                    class="btn btn-outline-primary btn-sm no-print">

                    <i class="fa-solid fa-print me-1"></i>
                    Print Register

                </button>

            </div>


            <!-- FILTERS -->

            <form method="get" class="row g-2 mt-3 no-print">

                <div class="col-12 col-md-5">
                    <input
                        type="text"
                        name="search"
                        class="form-control cert-search"
                        value="<?= e($search) ?>"
                        placeholder="Search student, course or certificate number">
                </div>

                <div class="col-8 col-md-3">

                    <select name="status"
                            class="form-select cert-search">

                        <option value="all"
                            <?= $status === 'all' ? 'selected' : '' ?>>
                            All Records
                        </option>

                        <option value="approved"
                            <?= $status === 'approved' ? 'selected' : '' ?>>
                            Issued Certificates
                        </option>

                        <option value="pending"
                            <?= $status === 'pending' ? 'selected' : '' ?>>
                            Pending Requests
                        </option>

                        <option value="rejected"
                            <?= $status === 'rejected' ? 'selected' : '' ?>>
                            Rejected Requests
                        </option>

                    </select>

                </div>

                <div class="col-4 col-md-2">

                    <button type="submit"
                            class="btn btn-primary w-100">

                        <i class="fa-solid fa-search me-1"></i>
                        Search

                    </button>

                </div>

                <div class="col-12 col-md-2">

                    <a
                        href="<?= e(base_url(
                            'assan_computer_institute/admin/certificates.php'
                        )) ?>"
                        class="btn btn-outline-secondary w-100">

                        Reset

                    </a>

                </div>

            </form>


            <div class="d-flex flex-wrap gap-2 mt-3 no-print">

                <?php
                $filters = array(
                    'all' => 'All',
                    'approved' => 'Issued',
                    'pending' => 'Pending',
                    'rejected' => 'Rejected'
                );

                foreach ($filters as $key => $label):
                    $filterUrl = base_url(
                        'assan_computer_institute/admin/certificates.php'
                    ) . '?status=' . urlencode($key);

                    if ($search !== '') {
                        $filterUrl .= '&search=' . urlencode($search);
                    }
                ?>

                    <a
                        href="<?= e($filterUrl) ?>"
                        class="cert-filter-link
                            <?= $status === $key ? 'active' : '' ?>">

                        <?= e($label) ?>

                    </a>

                <?php endforeach; ?>

            </div>

        </div>


        <div class="table-responsive">

            <table class="table cert-table">

                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Course</th>
                        <th>Certificate Number</th>
                        <th>Status</th>
                        <th>Requested</th>
                        <th>Reviewed / Issued</th>
                        <th>Reviewed By</th>
                        <th>Admin Note</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (empty($certificates)): ?>

                    <tr>
                        <td colspan="8">

                            <div class="cert-empty">

                                <i class="fa-solid fa-folder-open d-block"></i>

                                <h6 class="fw-bold text-dark">
                                    No Certificate Records Found
                                </h6>

                                <p class="mb-0">
                                    Try another search or status filter.
                                </p>

                            </div>

                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($certificates as $certificate): ?>

                        <?php
                        $recordStatus = $certificate['status'];

                        $statusClass = 'cert-pending';

                        if ($recordStatus === 'approved') {
                            $statusClass = 'cert-approved';
                        } elseif ($recordStatus === 'rejected') {
                            $statusClass = 'cert-rejected';
                        }
                        ?>

                        <tr>

                            <!-- STUDENT -->

                            <td>

                                <div class="cert-student">
                                    <?= e($certificate['full_name']) ?>
                                </div>

                                <div class="cert-muted">
                                    <?= e($certificate['email']) ?>
                                </div>

                                <?php if (!empty($certificate['mobile'])): ?>

                                    <div class="cert-muted">
                                        <?= e($certificate['mobile']) ?>
                                    </div>

                                <?php endif; ?>

                            </td>


                            <!-- COURSE -->

                            <td>
                                <div class="fw-bold">
                                    <?= e($certificate['course_title']) ?>
                                </div>
                            </td>


                            <!-- CERTIFICATE NUMBER -->

                            <td>

                                <?php if (
                                    $recordStatus === 'approved' &&
                                    !empty($certificate['certificate_number'])
                                ): ?>

                                    <span class="cert-number">
                                        <?= e($certificate['certificate_number']) ?>
                                    </span>

                                    <div class="mt-2">

                                        <a
                                            href="<?= e(base_url(
                                                'assan_computer_institute/student/certificate_view.php?id=' .
                                                (int) $certificate['id']
                                            )) ?>"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            class="btn btn-sm btn-outline-primary">

                                            <i class="fa-solid fa-eye me-1"></i>
                                            View

                                        </a>

                                    </div>

                                <?php else: ?>

                                    <span class="text-muted">
                                        Not issued
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- STATUS -->

                            <td>
                                <span class="cert-status <?= e($statusClass) ?>">
                                    <?= e(strtoupper($recordStatus)) ?>
                                </span>
                            </td>


                            <!-- REQUEST DATE -->

                            <td>
                                <?= e($certificate['requested_at']) ?>
                            </td>


                            <!-- REVIEW DATE -->

                            <td>
                                <?= !empty($certificate['reviewed_at'])
                                    ? e($certificate['reviewed_at'])
                                    : '—' ?>
                            </td>


                            <!-- REVIEWER -->

                            <td>
                                <?= !empty($certificate['reviewer_name'])
                                    ? e($certificate['reviewer_name'])
                                    : '—' ?>
                            </td>


                            <!-- ADMIN NOTE -->

                            <td>

                                <?php if (!empty($certificate['admin_note'])): ?>

                                    <span title="<?= e($certificate['admin_note']) ?>">
                                        <?= e(
                                            strlen($certificate['admin_note']) > 70
                                                ? substr($certificate['admin_note'], 0, 70) . '...'
                                                : $certificate['admin_note']
                                        ) ?>
                                    </span>

                                <?php else: ?>

                                    <span class="text-muted">—</span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

        <div class="px-4 py-3 border-top
                    d-flex justify-content-between
                    flex-wrap gap-2">

            <small class="text-muted">
                Showing <?= count($certificates) ?> record(s)
                matching the selected filters.
            </small>

            <small class="text-muted">
                Issued certificates:
                <strong><?= (int) $summary['approved'] ?></strong>
            </small>

        </div>

    </div>

</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>

<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash('error', 'Invalid request.');
    header('Location: ' . base_url('assan_computer_institute/admin/courses.php'));
    exit;
}

try {

    verify_csrf();

    $videoId = isset($_POST['id']) ? (int) $_POST['id'] : 0;
    $courseId = isset($_POST['course_id']) ? (int) $_POST['course_id'] : 0;

    if ($videoId <= 0 || $courseId <= 0) {
        throw new Exception('Invalid lesson information.');
    }

    /*
    |--------------------------------------------------------------------------
    | Get Current Status
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        SELECT id, active
        FROM course_videos
        WHERE id = ?
          AND course_id = ?
        LIMIT 1
    ");

    $stmt->execute(array(
        $videoId,
        $courseId
    ));

    $video = $stmt->fetch();

    if (!$video) {
        throw new Exception('Lesson not found.');
    }

    /*
    |--------------------------------------------------------------------------
    | Toggle Status
    |--------------------------------------------------------------------------
    */
    $newStatus = ((int) $video['active'] === 1) ? 0 : 1;

    $updateStmt = $pdo->prepare("
        UPDATE course_videos
        SET active = ?
        WHERE id = ?
          AND course_id = ?
    ");

    $updateStmt->execute(array(
        $newStatus,
        $videoId,
        $courseId
    ));

    if ($newStatus === 1) {
        flash('success', 'Lesson activated successfully.');
    } else {
        flash('success', 'Lesson deactivated successfully.');
    }

} catch (Exception $e) {

    flash('error', $e->getMessage());

} catch (PDOException $e) {

    flash('error', 'Database error. Lesson status could not be updated.');
}

header(
    'Location: ' .
    base_url('assan_computer_institute/admin/course_videos.php?course_id=' . $courseId)
);

exit;

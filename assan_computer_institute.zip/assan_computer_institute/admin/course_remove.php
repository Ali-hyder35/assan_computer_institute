
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();


/*
|--------------------------------------------------------------------------
| Only POST Allowed
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header(
        'Location: ' .
        ('assan_computer_institute/admin/courses.php')
    );

    exit;
}


try {

    verify_csrf();


    $courseId = isset($_POST['course_id'])
        ? (int) $_POST['course_id']
        : 0;


    if ($courseId <= 0) {

        throw new Exception(
            'Invalid course selected.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Check Course
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id, title, active
        FROM courses
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute(array($courseId));

    $course = $stmt->fetch();


    if (!$course) {

        throw new Exception(
            'Course not found.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Remove / Deactivate Course
    |--------------------------------------------------------------------------
    */

    $update = $pdo->prepare("
        UPDATE courses
        SET active = 0
        WHERE id = ?
    ");

    $update->execute(array($courseId));


    /*
    |--------------------------------------------------------------------------
    | Redirect
    |--------------------------------------------------------------------------
    */

    header(
        'Location: ' .
        base_url('assan_computer_institute/admin/courses.php?success=course_removed')
    );

    exit;


} catch (Exception $e) {

    header(
        'Location: ' .
        base_url(
            'assan_computer_institute/admin/courses.php?error=' .
            urlencode($e->getMessage())
        )
    );

    exit;
}

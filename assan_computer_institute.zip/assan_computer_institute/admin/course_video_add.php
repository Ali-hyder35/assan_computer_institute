<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Add Course Lesson';

$courseId = isset($_GET['course_id']) ? (int) $_GET['course_id'] : 0;

if ($courseId <= 0) {
    flash('error', 'Invalid course selected.');
    header('Location: ' . base_url('assan_computer_institute/admin/courses.php'));
    exit;
}

/*
|--------------------------------------------------------------------------
| Get Course
|--------------------------------------------------------------------------
*/
$courseStmt = $pdo->prepare("
    SELECT id, title, duration
    FROM courses
    WHERE id = ?
    LIMIT 1
");

$courseStmt->execute(array($courseId));

$course = $courseStmt->fetch();

if (!$course) {
    flash('error', 'Course not found.');
    header('Location: ' . base_url('assan_computer_institute/admin/courses.php'));
    exit;
}

/*
|--------------------------------------------------------------------------
| Default Lesson Number
|--------------------------------------------------------------------------
*/
$lessonStmt = $pdo->prepare("
    SELECT COALESCE(MAX(lesson_no), 0) + 1
    FROM course_videos
    WHERE course_id = ?
");

$lessonStmt->execute(array($courseId));

$nextLesson = (int) $lessonStmt->fetchColumn();

if ($nextLesson < 1) {
    $nextLesson = 1;
}

/*
|--------------------------------------------------------------------------
| Form Values
|--------------------------------------------------------------------------
*/
$title = '';
$description = '';
$videoUrl = '';
$lessonNo = $nextLesson;
$duration = '';
$active = 1;

$error = '';

/*
|--------------------------------------------------------------------------
| Submit
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $title = trim(isset($_POST['title']) ? $_POST['title'] : '');
        $description = trim(isset($_POST['description']) ? $_POST['description'] : '');
        $videoUrl = trim(isset($_POST['video_url']) ? $_POST['video_url'] : '');
        $lessonNo = isset($_POST['lesson_no']) ? (int) $_POST['lesson_no'] : 0;
        $duration = trim(isset($_POST['duration']) ? $_POST['duration'] : '');
        $active = isset($_POST['active']) ? (int) $_POST['active'] : 0;

        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {
            throw new Exception('Lesson title is required.');
        }

        if (strlen($title) > 180) {
            throw new Exception('Lesson title cannot exceed 180 characters.');
        }

        if ($videoUrl === '') {
            throw new Exception('Video URL is required.');
        }

        if (strlen($videoUrl) > 500) {
            throw new Exception('Video URL cannot exceed 500 characters.');
        }

        if (!filter_var($videoUrl, FILTER_VALIDATE_URL)) {
            throw new Exception('Please enter a valid video URL.');
        }

        if ($lessonNo < 1) {
            throw new Exception('Lesson number must be 1 or greater.');
        }

        if (strlen($duration) > 50) {
            throw new Exception('Duration cannot exceed 50 characters.');
        }

        $active = $active === 1 ? 1 : 0;

        /*
        |--------------------------------------------------------------------------
        | Check Duplicate Lesson Number
        |--------------------------------------------------------------------------
        */
        $duplicateStmt = $pdo->prepare("
            SELECT id
            FROM course_videos
            WHERE course_id = ?
              AND lesson_no = ?
            LIMIT 1
        ");

        $duplicateStmt->execute(array($courseId, $lessonNo));

        if ($duplicateStmt->fetch()) {
            throw new Exception(
                'Lesson number ' . $lessonNo . ' already exists for this course.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Insert
        |--------------------------------------------------------------------------
        */
        $stmt = $pdo->prepare("
            INSERT INTO course_videos
            (
                course_id,
                title,
                description,
                video_url,
                lesson_no,
                duration,
                active
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute(array(
            $courseId,
            $title,
            $description !== '' ? $description : null,
            $videoUrl,
            $lessonNo,
            $duration !== '' ? $duration : null,
            $active
        ));

        flash('success', 'Lesson added successfully.');

        header(
            'Location: ' .
            base_url('assan_computer_institute/admin/course_videos.php?course_id=' . $courseId)
        );

        exit;

    } catch (Exception $e) {

        $error = $e->getMessage();

    } catch (PDOException $e) {

        $error = 'Database error. Please check the course video table.';
    }
}

include dirname(__DIR__) . '/partials/header.php';
?>

<style>
    .acip-video-form-page {
        background: #f5f7fb;
        min-height: calc(100vh - 80px);
        padding: 30px 0 50px;
    }

    .acip-form-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        border-radius: 18px;
        padding: 28px 30px;
        color: #fff;
        margin-bottom: 25px;
        box-shadow: 0 10px 30px rgba(15,42,95,.12);
    }

    .acip-form-header h2 {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
    }

    .acip-form-header p {
        margin: 7px 0 0;
        color: rgba(255,255,255,.78);
    }

    .acip-form-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 18px;
        padding: 28px;
        box-shadow: 0 7px 25px rgba(15,42,95,.06);
    }

    .acip-section-title {
        color: #0f2a5f;
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 20px;
    }

    .acip-form-label {
        color: #334155;
        font-weight: 600;
        font-size: 13px;
        margin-bottom: 7px;
    }

    .acip-form-control {
        border: 1px solid #dbe3ee;
        border-radius: 10px;
        padding: 11px 13px;
        font-size: 14px;
    }

    .acip-form-control:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 .2rem rgba(37,99,235,.10);
    }

    .acip-help {
        color: #64748b;
        font-size: 12px;
        margin-top: 6px;
    }

    .acip-btn {
        border: 0;
        border-radius: 10px;
        padding: 11px 17px;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 7px;
    }

    .acip-btn-primary {
        background: #2563eb;
        color: #fff;
    }

    .acip-btn-primary:hover {
        background: #1d4ed8;
        color: #fff;
    }

    .acip-btn-secondary {
        background: #f1f5f9;
        color: #475569;
    }

    .acip-course-box {
        background: #eff6ff;
        border: 1px solid #dbeafe;
        border-radius: 13px;
        padding: 16px;
        margin-bottom: 25px;
    }

    .acip-course-box strong {
        color: #0f2a5f;
    }

    .acip-course-box span {
        color: #64748b;
        font-size: 13px;
    }

    .acip-alert {
        border-radius: 12px;
        padding: 13px 16px;
        margin-bottom: 20px;
        background: #fef2f2;
        border: 1px solid #fecaca;
        color: #991b1b;
        font-size: 14px;
    }

    .acip-checkbox {
        width: 18px;
        height: 18px;
        margin-right: 7px;
    }
</style>

<div class="acip-video-form-page">
    <div class="container">

        <div class="acip-form-header">
            <h2>
                <i class="fa-solid fa-plus-circle me-2"></i>
                Add Course Lesson
            </h2>

            <p>
                Add a new video lesson to
                <strong><?= e($course['title']) ?></strong>
            </p>
        </div>

        <?php if ($error !== ''): ?>
            <div class="acip-alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <div class="acip-form-card">

            <div class="acip-course-box">
                <strong>
                    <i class="fa-solid fa-book me-1"></i>
                    <?= e($course['title']) ?>
                </strong>

                <br>

                <span>
                    Course duration:
                    <?= e($course['duration'] ?: 'Not specified') ?>
                </span>
            </div>

            <form method="post">

                <?= csrf_field() ?>

                <div class="acip-section-title">
                    <i class="fa-solid fa-video me-2"></i>
                    Lesson Information
                </div>

                <div class="row g-4">

                    <div class="col-md-8">
                        <label class="acip-form-label">
                            Lesson Title *
                        </label>

                        <input type="text"
                               name="title"
                               class="form-control acip-form-control"
                               maxlength="180"
                               value="<?= e($title) ?>"
                               placeholder="Example: Introduction to HTML"
                               required>
                    </div>

                    <div class="col-md-4">
                        <label class="acip-form-label">
                            Lesson Number *
                        </label>

                        <input type="number"
                               name="lesson_no"
                               class="form-control acip-form-control"
                               min="1"
                               value="<?= (int) $lessonNo ?>"
                               required>

                        <div class="acip-help">
                            Used to order lessons inside the course.
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="acip-form-label">
                            Video URL *
                        </label>

                        <input type="url"
                               name="video_url"
                               class="form-control acip-form-control"
                               maxlength="500"
                               value="<?= e($videoUrl) ?>"
                               placeholder="https://www.youtube.com/watch?v=..."
                               required>

                        <div class="acip-help">
                            Enter a YouTube, Vimeo, or other valid HTTP/HTTPS video URL.
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="acip-form-label">
                            Duration
                        </label>

                        <input type="text"
                               name="duration"
                               class="form-control acip-form-control"
                               maxlength="50"
                               value="<?= e($duration) ?>"
                               placeholder="Example: 25 minutes">
                    </div>

                    <div class="col-md-8">
                        <label class="acip-form-label">
                            Status
                        </label>

                        <div class="form-control acip-form-control d-flex align-items-center">
                            <input type="checkbox"
                                   name="active"
                                   value="1"
                                   class="form-check-input acip-checkbox"
                                   <?= $active === 1 ? 'checked' : '' ?>>

                            <span>Make this lesson active for students</span>
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="acip-form-label">
                            Description
                        </label>

                        <textarea name="description"
                                  class="form-control acip-form-control"
                                  rows="5"
                                  placeholder="Write a short description of this lesson..."><?= e($description) ?></textarea>
                    </div>

                </div>

                <hr class="my-4">

                <div class="d-flex justify-content-between flex-wrap gap-2">

                    <a href="<?= e(base_url(
                        'assan_computer_institute/admin/course_videos.php?course_id=' . $courseId
                    )) ?>"
                       class="acip-btn acip-btn-secondary">
                        <i class="fa-solid fa-arrow-left"></i>
                        Cancel
                    </a>

                    <button type="submit"
                            class="acip-btn acip-btn-primary">
                        <i class="fa-solid fa-save"></i>
                        Save Lesson
                    </button>

                </div>

            </form>

        </div>

    </div>
</div>

<?php include dirname(__DIR__) . '/partials/footer.php'; ?>


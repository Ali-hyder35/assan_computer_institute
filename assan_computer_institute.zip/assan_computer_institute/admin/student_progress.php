
<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Admin - Student Learning Progress
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Student Progress';

$message = '';
$messageType = 'success';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$statusFilter = isset($_GET['status'])
    ? trim($_GET['status'])
    : 'all';

$courseFilter = isset($_GET['course_id'])
    ? (int) $_GET['course_id']
    : 0;

$page = isset($_GET['page'])
    ? max(1, (int) $_GET['page'])
    : 1;

$perPage = 10;

if (!in_array($statusFilter, array('all', 'active', 'blocked'), true)) {
    $statusFilter = 'all';
}

/*
|--------------------------------------------------------------------------
| Course List
|--------------------------------------------------------------------------
*/

$coursesStmt = $pdo->query("
    SELECT id, title
    FROM courses
    ORDER BY title ASC
");

$allCourses = $coursesStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

$totalStudents = (int) $pdo->query("
    SELECT COUNT(*)
    FROM users
    WHERE role = 'student'
")->fetchColumn();

$activeEnrollments = (int) $pdo->query("
    SELECT COUNT(*)
    FROM enrollments
    WHERE payment_status = 'paid'
      AND access_status = 'active'
")->fetchColumn();

$totalActiveLessons = (int) $pdo->query("
    SELECT COUNT(*)
    FROM course_videos
    WHERE active = 1
")->fetchColumn();

/*
|--------------------------------------------------------------------------
| Build Filters
|--------------------------------------------------------------------------
| Only paid and active course enrollments are included.
|--------------------------------------------------------------------------
*/

$where = array(
    "u.role = 'student'",
    "e.payment_status = 'paid'",
    "e.access_status = 'active'"
);

$params = array();

if ($search !== '') {
    $where[] = "(
        u.full_name LIKE ?
        OR u.email LIKE ?
        OR u.mobile LIKE ?
    )";

    $searchTerm = '%' . $search . '%';

    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if ($statusFilter !== 'all') {
    $where[] = 'u.status = ?';
    $params[] = $statusFilter;
}

if ($courseFilter > 0) {
    $where[] = 'c.id = ?';
    $params[] = $courseFilter;
}

$whereSql = implode(' AND ', $where);

/*
|--------------------------------------------------------------------------
| Count Matching Course Enrollments
|--------------------------------------------------------------------------
*/

$countSql = "
    SELECT COUNT(*)
    FROM enrollments e
    INNER JOIN users u
        ON u.id = e.user_id
    INNER JOIN courses c
        ON c.id = e.course_id
    WHERE {$whereSql}
";

$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);

$totalRecords = (int) $countStmt->fetchColumn();

$totalPages = max(
    1,
    (int) ceil($totalRecords / $perPage)
);

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| Fetch Course Progress
|--------------------------------------------------------------------------
| Progress = completed active lessons / total active lessons * 100.
|--------------------------------------------------------------------------
*/

$progressSql = "
    SELECT
        u.id AS student_id,
        u.full_name,
        u.email,
        u.mobile,
        u.status AS student_status,
        u.created_at AS registered_at,

        e.id AS enrollment_id,
        e.created_at AS enrollment_date,

        c.id AS course_id,
        c.title AS course_title,
        c.duration AS course_duration,

        (
            SELECT COUNT(*)
            FROM course_videos cv
            WHERE cv.course_id = c.id
              AND cv.active = 1
        ) AS total_lessons,

        (
            SELECT COUNT(*)
            FROM student_video_progress svp
            INNER JOIN course_videos cv
                ON cv.id = svp.video_id
               AND cv.course_id = c.id
               AND cv.active = 1
            WHERE svp.user_id = u.id
              AND svp.course_id = c.id
              AND svp.completed = 1
        ) AS completed_lessons,

        (
            SELECT COUNT(*)
            FROM student_video_progress svp
            INNER JOIN course_videos cv
                ON cv.id = svp.video_id
               AND cv.course_id = c.id
               AND cv.active = 1
            WHERE svp.user_id = u.id
              AND svp.course_id = c.id
        ) AS started_lessons

    FROM enrollments e

    INNER JOIN users u
        ON u.id = e.user_id

    INNER JOIN courses c
        ON c.id = e.course_id

    WHERE {$whereSql}

    ORDER BY u.full_name ASC, c.title ASC

    LIMIT {$perPage} OFFSET {$offset}
";

$progressStmt = $pdo->prepare($progressSql);
$progressStmt->execute($params);

$progressRows = $progressStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Calculate Display Statistics
|--------------------------------------------------------------------------
*/

$completedCourseCount = 0;
$notStartedCount = 0;
$inProgressCount = 0;
$completedLessonCount = 0;
$lessonCountForResults = 0;

foreach ($progressRows as $row) {
    $total = (int) $row['total_lessons'];
    $completed = (int) $row['completed_lessons'];

    $percentage = $total > 0
        ? (int) round(($completed / $total) * 100)
        : 0;

    if ($total > 0 && $completed >= $total) {
        $completedCourseCount++;
    } elseif ($completed === 0 && (int) $row['started_lessons'] === 0) {
        $notStartedCount++;
    } else {
        $inProgressCount++;
    }

    $completedLessonCount += $completed;
    $lessonCountForResults += $total;
}

$averageProgress = $lessonCountForResults > 0
    ? (int) round(
        ($completedLessonCount / $lessonCountForResults) * 100
    )
    : 0;

/*
|--------------------------------------------------------------------------
| Pagination URL
|--------------------------------------------------------------------------
*/

function student_progress_page_url($pageNumber)
{
    $query = $_GET;
    $query['page'] = (int) $pageNumber;

    return base_url(
        'assan_computer_institute/admin/student_progress.php'
    ) . '?' . http_build_query($query);
}

include dirname(__DIR__) . '/partials/header.php';

?>

<style>
    .acip-progress-page {
        background: #f5f7fb;
        min-height: calc(100vh - 80px);
        padding: 30px 0 50px;
    }

    .acip-progress-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 18px;
        padding: 28px 30px;
        margin-bottom: 25px;
        box-shadow: 0 10px 30px rgba(15,42,95,.12);
    }

    .acip-progress-header h2 {
        font-size: 25px;
        font-weight: 750;
        margin: 0;
    }

    .acip-progress-header p {
        color: rgba(255,255,255,.78);
        margin: 8px 0 0;
        font-size: 14px;
    }

    .acip-header-link {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 11px 16px;
        border-radius: 10px;
        background: rgba(255,255,255,.12);
        border: 1px solid rgba(255,255,255,.25);
        color: #fff;
        font-size: 13px;
        font-weight: 650;
        text-decoration: none;
    }

    .acip-header-link:hover {
        background: rgba(255,255,255,.2);
        color: #fff;
    }

    .acip-progress-stat {
        height: 100%;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 21px;
        box-shadow: 0 5px 20px rgba(15,42,95,.04);
    }

    .acip-stat-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 17px;
    }

    .acip-stat-label {
        color: #64748b;
        font-size: 13px;
        font-weight: 650;
    }

    .acip-stat-icon {
        width: 44px;
        height: 44px;
        border-radius: 13px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
    }

    .acip-stat-blue {
        background: #eff6ff;
        color: #2563eb;
    }

    .acip-stat-green {
        background: #dcfce7;
        color: #15803d;
    }

    .acip-stat-purple {
        background: #f3e8ff;
        color: #7e22ce;
    }

    .acip-stat-number {
        color: #0f2a5f;
        font-size: 30px;
        font-weight: 800;
        line-height: 1.2;
    }

    .acip-stat-description {
        color: #94a3b8;
        font-size: 12px;
        margin-top: 6px;
    }

    .acip-progress-panel {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        overflow: hidden;
        margin-top: 25px;
        box-shadow: 0 5px 20px rgba(15,42,95,.04);
    }

    .acip-panel-heading {
        padding: 22px 24px;
        border-bottom: 1px solid #edf0f5;
    }

    .acip-panel-heading h3 {
        color: #0f2a5f;
        font-size: 18px;
        font-weight: 750;
        margin: 0;
    }

    .acip-panel-heading p {
        color: #64748b;
        font-size: 13px;
        margin: 6px 0 0;
    }

    .acip-filters {
        padding: 20px 24px;
        background: #fcfdff;
        border-bottom: 1px solid #edf0f5;
    }

    .acip-filter-label {
        display: block;
        margin-bottom: 7px;
        color: #334155;
        font-size: 12px;
        font-weight: 700;
    }

    .acip-filter-control {
        width: 100%;
        min-height: 43px;
        padding: 9px 12px;
        border: 1px solid #dbe3ef;
        border-radius: 10px;
        background: #fff;
        color: #334155;
        font-size: 13px;
        outline: none;
    }

    .acip-filter-control:focus {
        border-color: #60a5fa;
        box-shadow: 0 0 0 3px rgba(37,99,235,.1);
    }

    .acip-filter-submit {
        width: 100%;
        min-height: 43px;
        border: 0;
        border-radius: 10px;
        background: #2563eb;
        color: #fff;
        font-size: 13px;
        font-weight: 700;
    }

    .acip-filter-submit:hover {
        background: #1d4ed8;
    }

    .acip-filter-reset {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        min-height: 43px;
        padding: 10px;
        border-radius: 10px;
        background: #f1f5f9;
        color: #475569;
        font-size: 13px;
        font-weight: 650;
        text-decoration: none;
    }

    .acip-filter-reset:hover {
        background: #e2e8f0;
        color: #0f2a5f;
    }

    .acip-table-wrap {
        width: 100%;
        overflow-x: auto;
    }

    .acip-progress-table {
        width: 100%;
        min-width: 1000px;
        border-collapse: separate;
        border-spacing: 0;
        margin: 0;
    }

    .acip-progress-table thead th {
        padding: 14px 16px;
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
        color: #64748b;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .4px;
        white-space: nowrap;
    }

    .acip-progress-table tbody td {
        padding: 16px;
        border-bottom: 1px solid #edf0f5;
        vertical-align: middle;
        color: #334155;
        font-size: 13px;
    }

    .acip-progress-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .acip-progress-table tbody tr:hover {
        background: #fbfdff;
    }

    .acip-student-cell {
        display: flex;
        align-items: center;
        gap: 11px;
        min-width: 195px;
    }

    .acip-student-avatar {
        width: 42px;
        height: 42px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        border-radius: 12px;
        background: #eaf1ff;
        color: #1d4ed8;
        font-size: 15px;
        font-weight: 800;
        text-transform: uppercase;
    }

    .acip-student-name {
        color: #0f2a5f;
        font-weight: 750;
        font-size: 13px;
        overflow-wrap: anywhere;
    }

    .acip-student-email {
        color: #94a3b8;
        font-size: 11px;
        margin-top: 4px;
        overflow-wrap: anywhere;
    }

    .acip-course-name {
        color: #0f2a5f;
        font-size: 13px;
        font-weight: 750;
        max-width: 220px;
        overflow-wrap: anywhere;
    }

    .acip-course-duration {
        color: #94a3b8;
        font-size: 11px;
        margin-top: 5px;
    }

    .acip-lesson-number {
        color: #0f2a5f;
        font-weight: 800;
        font-size: 14px;
    }

    .acip-lesson-subtext {
        color: #94a3b8;
        font-size: 11px;
        margin-top: 4px;
    }

    .acip-progress-track {
        width: 150px;
        height: 8px;
        border-radius: 20px;
        overflow: hidden;
        background: #e2e8f0;
        margin-bottom: 7px;
    }

    .acip-progress-fill {
        height: 100%;
        border-radius: 20px;
        background: #2563eb;
        transition: width .25s ease;
    }

    .acip-progress-fill-complete {
        background: #16a34a;
    }

    .acip-progress-percent {
        color: #0f2a5f;
        font-size: 12px;
        font-weight: 800;
    }

    .acip-progress-state {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 750;
        white-space: nowrap;
    }

    .acip-state-complete {
        background: #dcfce7;
        color: #166534;
    }

    .acip-state-progress {
        background: #dbeafe;
        color: #1d4ed8;
    }

    .acip-state-not-started {
        background: #f1f5f9;
        color: #64748b;
    }

    .acip-state-no-lessons {
        background: #fff7ed;
        color: #9a3412;
    }

    .acip-account-status {
        display: inline-flex;
        padding: 5px 9px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: 750;
    }

    .acip-account-active {
        background: #dcfce7;
        color: #166534;
    }

    .acip-account-blocked {
        background: #fee2e2;
        color: #991b1b;
    }

    .acip-empty {
        padding: 55px 20px;
        text-align: center;
    }

    .acip-empty-icon {
        width: 66px;
        height: 66px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        border-radius: 18px;
        background: #eff6ff;
        color: #2563eb;
        font-size: 25px;
    }

    .acip-empty h4 {
        color: #0f2a5f;
        font-size: 17px;
        font-weight: 750;
    }

    .acip-empty p {
        color: #64748b;
        font-size: 13px;
    }

    .acip-pagination {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 15px;
        padding: 18px 24px;
        border-top: 1px solid #edf0f5;
    }

    .acip-pagination-info {
        color: #64748b;
        font-size: 12px;
    }

    .acip-pagination-links {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
    }

    .acip-page-link {
        min-width: 35px;
        height: 35px;
        padding: 0 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        background: #fff;
        color: #475569;
        font-size: 12px;
        font-weight: 700;
        text-decoration: none;
    }

    .acip-page-link:hover {
        border-color: #93c5fd;
        color: #1d4ed8;
    }

    .acip-page-current {
        border-color: #2563eb;
        background: #2563eb;
        color: #fff;
    }

    .acip-page-disabled {
        opacity: .4;
        pointer-events: none;
    }

    @media (max-width: 767px) {
        .acip-progress-page {
            padding-top: 20px;
        }

        .acip-progress-header {
            padding: 22px;
        }

        .acip-progress-header h2 {
            font-size: 22px;
        }

        .acip-panel-heading,
        .acip-filters {
            padding: 18px;
        }

        .acip-pagination {
            padding: 16px 18px;
        }
    }
</style>

<div class="acip-progress-page">
    <div class="container-fluid px-3 px-lg-4">

        <!-- Header -->

        <div class="acip-progress-header">
            <div class="row align-items-center g-3">

                <div class="col-lg-8">
                    <h2>
                        <i class="fa-solid fa-chart-line me-2"></i>
                        Student Learning Progress
                    </h2>

                    <p>
                        Monitor completed lessons, course progress,
                        and student learning activity.
                    </p>
                </div>

                <div class="col-lg-4">
                    <div class="d-flex justify-content-lg-end">
                        <a href="<?= e(base_url(
                            'assan_computer_institute/admin/dashboard.php'
                        )) ?>"
                           class="acip-header-link">
                            <i class="fa-solid fa-arrow-left"></i>
                            Back to Dashboard
                        </a>
                    </div>
                </div>

            </div>
        </div>

        <!-- Summary Cards -->

        <div class="row g-3">

            <div class="col-12 col-md-4">
                <div class="acip-progress-stat">
                    <div class="acip-stat-top">
                        <span class="acip-stat-label">
                            Registered Students
                        </span>

                        <span class="acip-stat-icon acip-stat-blue">
                            <i class="fa-solid fa-users"></i>
                        </span>
                    </div>

                    <div class="acip-stat-number">
                        <?= number_format($totalStudents) ?>
                    </div>

                    <div class="acip-stat-description">
                        Student accounts in the LMS
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="acip-progress-stat">
                    <div class="acip-stat-top">
                        <span class="acip-stat-label">
                            Active Paid Enrollments
                        </span>

                        <span class="acip-stat-icon acip-stat-green">
                            <i class="fa-solid fa-book-open"></i>
                        </span>
                    </div>

                    <div class="acip-stat-number">
                        <?= number_format($activeEnrollments) ?>
                    </div>

                    <div class="acip-stat-description">
                        Courses with active student access
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="acip-progress-stat">
                    <div class="acip-stat-top">
                        <span class="acip-stat-label">
                            Active Lessons
                        </span>

                        <span class="acip-stat-icon acip-stat-purple">
                            <i class="fa-solid fa-circle-play"></i>
                        </span>
                    </div>

                    <div class="acip-stat-number">
                        <?= number_format($totalActiveLessons) ?>
                    </div>

                    <div class="acip-stat-description">
                        Active lessons across all courses
                    </div>
                </div>
            </div>

        </div>

        <!-- Progress Table -->

        <div class="acip-progress-panel">

            <div class="acip-panel-heading">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                    <div>
                        <h3>
                            <i class="fa-solid fa-chart-simple me-2"></i>
                            Course Progress Records
                        </h3>

                        <p>
                            Progress is based on completed active lessons
                            for paid and active course enrollments.
                        </p>
                    </div>

                    <span class="badge text-bg-light border">
                        <?= number_format($totalRecords) ?> records
                    </span>

                </div>
            </div>

            <!-- Filters -->

            <div class="acip-filters">
                <form method="get"
                      action="<?= e(base_url(
                          'assan_computer_institute/admin/student_progress.php'
                      )) ?>">

                    <div class="row g-3 align-items-end">

                        <div class="col-12 col-lg-4">
                            <label for="progressSearch"
                                   class="acip-filter-label">
                                Search Student
                            </label>

                            <input type="text"
                                   id="progressSearch"
                                   name="search"
                                   class="acip-filter-control"
                                   placeholder="Name, email or mobile..."
                                   value="<?= e($search) ?>">
                        </div>

                        <div class="col-12 col-sm-6 col-lg-3">
                            <label for="progressCourse"
                                   class="acip-filter-label">
                                Course
                            </label>

                            <select name="course_id"
                                    id="progressCourse"
                                    class="acip-filter-control">

                                <option value="0">All Courses</option>

                                <?php foreach ($allCourses as $courseOption): ?>
                                    <option
                                        value="<?= (int) $courseOption['id'] ?>"
                                        <?= $courseFilter === (int) $courseOption['id']
                                            ? 'selected'
                                            : '' ?>>

                                        <?= e($courseOption['title']) ?>

                                    </option>
                                <?php endforeach; ?>

                            </select>
                        </div>

                        <div class="col-12 col-sm-6 col-lg-2">
                            <label for="progressStatus"
                                   class="acip-filter-label">
                                Student Status
                            </label>

                            <select name="status"
                                    id="progressStatus"
                                    class="acip-filter-control">

                                <option value="all"
                                    <?= $statusFilter === 'all'
                                        ? 'selected'
                                        : '' ?>>
                                    All
                                </option>

                                <option value="active"
                                    <?= $statusFilter === 'active'
                                        ? 'selected'
                                        : '' ?>>
                                    Active
                                </option>

                                <option value="blocked"
                                    <?= $statusFilter === 'blocked'
                                        ? 'selected'
                                        : '' ?>>
                                    Blocked
                                </option>

                            </select>
                        </div>

                        <div class="col-6 col-lg-1">
                            <button type="submit"
                                    class="acip-filter-submit">
                                <i class="fa-solid fa-search"></i>
                            </button>
                        </div>

                        <div class="col-6 col-lg-2">
                            <a href="<?= e(base_url(
                                'assan_computer_institute/admin/student_progress.php'
                            )) ?>"
                               class="acip-filter-reset">
                                <i class="fa-solid fa-rotate-left me-2"></i>
                                Reset
                            </a>
                        </div>

                    </div>
                </form>
            </div>

            <!-- Table Results -->

            <?php if (empty($progressRows)): ?>

                <div class="acip-empty">
                    <div class="acip-empty-icon">
                        <i class="fa-solid fa-chart-line"></i>
                    </div>

                    <h4>No Progress Records Found</h4>

                    <p class="mb-3">
                        No paid, active course enrollments match these filters.
                        Students without an eligible enrollment will not appear here.
                    </p>

                    <a href="<?= e(base_url(
                        'assan_computer_institute/admin/student_progress.php'
                    )) ?>"
                       class="acip-filter-reset"
                       style="width:auto; display:inline-flex;">
                        <i class="fa-solid fa-rotate-left me-2"></i>
                        View All Progress
                    </a>
                </div>

            <?php else: ?>

                <div class="acip-table-wrap">
                    <table class="acip-progress-table">

                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Course</th>
                                <th>Completed Lessons</th>
                                <th>Learning Progress</th>
                                <th>Progress Status</th>
                                <th>Account</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($progressRows as $row): ?>

                                <?php
                                $studentName = trim(
                                    (string) $row['full_name']
                                );

                                $avatarLetter = $studentName !== ''
                                    ? (function_exists('mb_substr')
                                        ? mb_substr($studentName, 0, 1, 'UTF-8')
                                        : substr($studentName, 0, 1))
                                    : '?';

                                $avatarLetter = function_exists('mb_strtoupper')
                                    ? mb_strtoupper($avatarLetter, 'UTF-8')
                                    : strtoupper($avatarLetter);

                                $total = (int) $row['total_lessons'];
                                $completed = (int) $row['completed_lessons'];
                                $started = (int) $row['started_lessons'];

                                $percentage = $total > 0
                                    ? (int) round(
                                        ($completed / $total) * 100
                                    )
                                    : 0;

                                $percentage = min(100, max(0, $percentage));

                                if ($total === 0) {
                                    $progressLabel = 'No Lessons';
                                    $progressClass = 'acip-state-no-lessons';
                                    $progressIcon = 'fa-circle-info';
                                } elseif ($completed >= $total) {
                                    $progressLabel = 'Completed';
                                    $progressClass = 'acip-state-complete';
                                    $progressIcon = 'fa-circle-check';
                                } elseif ($completed === 0 && $started === 0) {
                                    $progressLabel = 'Not Started';
                                    $progressClass = 'acip-state-not-started';
                                    $progressIcon = 'fa-circle';
                                } else {
                                    $progressLabel = 'In Progress';
                                    $progressClass = 'acip-state-progress';
                                    $progressIcon = 'fa-spinner';
                                }

                                $studentStatus = isset($row['student_status'])
                                    ? $row['student_status']
                                    : '';
                                ?>

                                <tr>

                                    <!-- Student -->

                                    <td>
                                        <div class="acip-student-cell">

                                            <div class="acip-student-avatar">
                                                <?= e($avatarLetter) ?>
                                            </div>

                                            <div>
                                                <div class="acip-student-name">
                                                    <?= e($studentName) ?>
                                                </div>

                                                <div class="acip-student-email">
                                                    <?= e($row['email']) ?>
                                                </div>

                                                <div class="acip-student-email">
                                                    Student ID:
                                                    #<?= (int) $row['student_id'] ?>
                                                </div>
                                            </div>

                                        </div>
                                    </td>

                                    <!-- Course -->

                                    <td>
                                        <div class="acip-course-name">
                                            <?= e($row['course_title']) ?>
                                        </div>

                                        <div class="acip-course-duration">
                                            <i class="fa-regular fa-clock me-1"></i>
                                            <?= e(
                                                $row['course_duration']
                                                ?: 'Duration not specified'
                                            ) ?>
                                        </div>
                                    </td>

                                    <!-- Lessons -->

                                    <td>
                                        <div class="acip-lesson-number">
                                            <?= $completed ?> / <?= $total ?>
                                        </div>

                                        <div class="acip-lesson-subtext">
                                            Completed lessons
                                        </div>
                                    </td>

                                    <!-- Progress Bar -->

                                    <td>
                                        <div class="acip-progress-track"
                                             role="progressbar"
                                             aria-valuenow="<?= $percentage ?>"
                                             aria-valuemin="0"
                                             aria-valuemax="100"
                                             aria-label="Course progress">

                                            <div class="acip-progress-fill <?= $percentage >= 100
                                                && $total > 0
                                                ? 'acip-progress-fill-complete'
                                                : '' ?>"
                                                 style="width: <?= $percentage ?>%;"></div>

                                        </div>

                                        <div class="acip-progress-percent">
                                            <?= $percentage ?>% complete
                                        </div>
                                    </td>

                                    <!-- Progress Status -->

                                    <td>
                                        <span class="acip-progress-state <?= $progressClass ?>">
                                            <i class="fa-solid <?= $progressIcon ?>"></i>
                                            <?= e($progressLabel) ?>
                                        </span>
                                    </td>

                                    <!-- Account Status -->

                                    <td>
                                        <?php if ($studentStatus === 'active'): ?>

                                            <span class="acip-account-status acip-account-active">
                                                Active
                                            </span>

                                        <?php elseif ($studentStatus === 'blocked'): ?>

                                            <span class="acip-account-status acip-account-blocked">
                                                Blocked
                                            </span>

                                        <?php else: ?>

                                            <span class="acip-account-status bg-light text-secondary">
                                                <?= e($studentStatus ?: 'Unknown') ?>
                                            </span>

                                        <?php endif; ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>
                </div>

                <!-- Pagination -->

                <div class="acip-pagination">

                    <?php
                    $firstRecord = $totalRecords > 0
                        ? $offset + 1
                        : 0;

                    $lastRecord = min(
                        $offset + $perPage,
                        $totalRecords
                    );
                    ?>

                    <div class="acip-pagination-info">
                        Showing
                        <strong><?= $firstRecord ?></strong>
                        to
                        <strong><?= $lastRecord ?></strong>
                        of
                        <strong><?= number_format($totalRecords) ?></strong>
                        course progress records
                    </div>

                    <?php if ($totalPages > 1): ?>

                        <div class="acip-pagination-links">

                            <a href="<?= e(student_progress_page_url(
                                max(1, $page - 1)
                            )) ?>"
                               class="acip-page-link <?= $page <= 1
                                   ? 'acip-page-disabled'
                                   : '' ?>">
                                <i class="fa-solid fa-chevron-left"></i>
                            </a>

                            <?php
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            ?>

                            <?php if ($startPage > 1): ?>

                                <a href="<?= e(student_progress_page_url(1)) ?>"
                                   class="acip-page-link">1</a>

                                <?php if ($startPage > 2): ?>
                                    <span class="px-1 text-muted">...</span>
                                <?php endif; ?>

                            <?php endif; ?>

                            <?php for (
                                $pageNumber = $startPage;
                                $pageNumber <= $endPage;
                                $pageNumber++
                            ): ?>

                                <a href="<?= e(student_progress_page_url($pageNumber)) ?>"
                                   class="acip-page-link <?= $pageNumber === $page
                                       ? 'acip-page-current'
                                       : '' ?>">
                                    <?= $pageNumber ?>
                                </a>

                            <?php endfor; ?>

                            <?php if ($endPage < $totalPages): ?>

                                <?php if ($endPage < $totalPages - 1): ?>
                                    <span class="px-1 text-muted">...</span>
                                <?php endif; ?>

                                <a href="<?= e(student_progress_page_url($totalPages)) ?>"
                                   class="acip-page-link">
                                    <?= $totalPages ?>
                                </a>

                            <?php endif; ?>

                            <a href="<?= e(student_progress_page_url(
                                min($totalPages, $page + 1)
                            )) ?>"
                               class="acip-page-link <?= $page >= $totalPages
                                   ? 'acip-page-disabled'
                                   : '' ?>">
                                <i class="fa-solid fa-chevron-right"></i>
                            </a>

                        </div>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </div>

    </div>
</div>

<?php include dirname(__DIR__) . '/partials/footer.php'; ?>

<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Admin - Enrollment Management
|--------------------------------------------------------------------------
| Read-only enrollment register.
| Does not change enrollment, payment, or access logic.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Manage Enrollments';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$paymentStatus = isset($_GET['payment_status'])
    ? trim($_GET['payment_status'])
    : '';

$accessStatus = isset($_GET['access_status'])
    ? trim($_GET['access_status'])
    : '';

$allowedPaymentStatuses = array(
    'pending',
    'paid',
    'failed',
    'rejected',
    'refunded'
);

$allowedAccessStatuses = array(
    'pending',
    'active',
    'blocked',
    'inactive',
    'revoked'
);

if (!in_array($paymentStatus, $allowedPaymentStatuses, true)) {
    $paymentStatus = '';
}

if (!in_array($accessStatus, $allowedAccessStatuses, true)) {
    $accessStatus = '';
}

/*
|--------------------------------------------------------------------------
| Enrollment Statistics
|--------------------------------------------------------------------------
| Counts are based on the existing enrollments table.
|--------------------------------------------------------------------------
*/

$totalEnrollments = 0;
$pendingPayments = 0;
$paidEnrollments = 0;
$activeAccess = 0;

try {
    $totalEnrollments = (int) $pdo->query(
        "SELECT COUNT(*) FROM enrollments"
    )->fetchColumn();

    $pendingPayments = (int) $pdo->query(
        "SELECT COUNT(*)
         FROM enrollments
         WHERE payment_status = 'pending'"
    )->fetchColumn();

    $paidEnrollments = (int) $pdo->query(
        "SELECT COUNT(*)
         FROM enrollments
         WHERE payment_status = 'paid'"
    )->fetchColumn();

    $activeAccess = (int) $pdo->query(
        "SELECT COUNT(*)
         FROM enrollments
         WHERE payment_status = 'paid'
           AND access_status = 'active'"
    )->fetchColumn();

} catch (PDOException $e) {
    error_log('Enrollment statistics error: ' . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| Build Search Query
|--------------------------------------------------------------------------
*/

$where = array();
$params = array();

if ($search !== '') {
    $where[] = "(
        CAST(en.id AS CHAR) LIKE :enrollment_id
        OR u.full_name LIKE :student_name
        OR u.email LIKE :student_email
        OR c.title LIKE :course_title
    )";

    $searchTerm = '%' . $search . '%';

    $params[':enrollment_id'] = $searchTerm;
    $params[':student_name'] = $searchTerm;
    $params[':student_email'] = $searchTerm;
    $params[':course_title'] = $searchTerm;
}

if ($paymentStatus !== '') {
    $where[] = 'en.payment_status = :payment_status';
    $params[':payment_status'] = $paymentStatus;
}

if ($accessStatus !== '') {
    $where[] = 'en.access_status = :access_status';
    $params[':access_status'] = $accessStatus;
}

$whereSql = '';

if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

/*
|--------------------------------------------------------------------------
| Load Enrollments
|--------------------------------------------------------------------------
*/

$enrollments = array();
$totalFiltered = 0;
$pageError = '';

try {
    $countSql = "
        SELECT COUNT(*)
        FROM enrollments en
        INNER JOIN users u ON u.id = en.user_id
        INNER JOIN courses c ON c.id = en.course_id
        $whereSql
    ";

    $countStmt = $pdo->prepare($countSql);

    foreach ($params as $key => $value) {
        $countStmt->bindValue($key, $value, PDO::PARAM_STR);
    }

    $countStmt->execute();
    $totalFiltered = (int) $countStmt->fetchColumn();

    $sql = "
        SELECT
            en.*,
            u.full_name AS student_name,
            u.email AS student_email,
            u.mobile AS student_mobile,
            c.title AS course_title,
            c.price AS course_price
        FROM enrollments en
        INNER JOIN users u ON u.id = en.user_id
        INNER JOIN courses c ON c.id = en.course_id
        $whereSql
        ORDER BY en.id DESC
    ";

    $stmt = $pdo->prepare($sql);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value, PDO::PARAM_STR);
    }

    $stmt->execute();
    $enrollments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Enrollment listing error: ' . $e->getMessage());
    $pageError = 'Unable to load enrollments. Please check the database configuration and table columns.';
}

/*
|--------------------------------------------------------------------------
| Display Helpers
|--------------------------------------------------------------------------
*/

function enrollment_status_class($status)
{
    $status = strtolower((string) $status);

    if (in_array($status, array('paid', 'active', 'approved', 'completed'), true)) {
        return 'status-success';
    }

    if (in_array($status, array('pending', 'in_progress'), true)) {
        return 'status-pending';
    }

    if (in_array($status, array('failed', 'rejected', 'blocked', 'revoked', 'refunded', 'inactive'), true)) {
        return 'status-danger';
    }

    return 'status-neutral';
}

require_once dirname(__DIR__) . '/partials/header.php';

?>

<style>
    .enrollment-page {
        color: #1e293b;
        padding-bottom: 35px;
    }

    .enrollment-heading {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 25px;
    }

    .enrollment-heading h1 {
        color: #0f2a5f;
        font-size: 27px;
        font-weight: 750;
        margin: 0 0 7px;
    }

    .enrollment-heading p {
        color: #64748b;
        margin: 0;
        font-size: 14px;
    }

    .enrollment-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px 15px;
        border-radius: 9px;
        border: 1px solid #dbe4f0;
        background: #fff;
        color: #0f2a5f;
        font-weight: 600;
        font-size: 13px;
        text-decoration: none;
        cursor: pointer;
    }

    .enrollment-btn:hover {
        background: #f1f5f9;
        color: #0f2a5f;
    }

    .enrollment-btn-primary {
        background: #1d4ed8;
        color: #fff;
        border-color: #1d4ed8;
    }

    .enrollment-btn-primary:hover {
        background: #1e40af;
        color: #fff;
    }

    .enrollment-stats {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }

    .enrollment-stat {
        display: flex;
        align-items: center;
        gap: 14px;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 19px;
        box-shadow: 0 3px 12px rgba(15, 42, 95, 0.035);
        min-width: 0;
    }

    .enrollment-stat-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 45px;
        height: 45px;
        border-radius: 12px;
        background: #eff6ff;
        color: #2563eb;
        font-size: 18px;
        flex-shrink: 0;
    }

    .enrollment-stat:nth-child(2) .enrollment-stat-icon {
        background: #fff7ed;
        color: #ea580c;
    }

    .enrollment-stat:nth-child(3) .enrollment-stat-icon {
        background: #ecfdf5;
        color: #059669;
    }

    .enrollment-stat:nth-child(4) .enrollment-stat-icon {
        background: #eef2ff;
        color: #4f46e5;
    }

    .enrollment-stat-label {
        font-size: 12px;
        color: #64748b;
        margin-bottom: 5px;
    }

    .enrollment-stat-value {
        color: #0f2a5f;
        font-size: 25px;
        line-height: 1.15;
        font-weight: 750;
    }

    .enrollment-panel {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 3px 12px rgba(15, 42, 95, 0.035);
    }

    .enrollment-panel-header {
        padding: 20px;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
    }

    .enrollment-panel-header h2 {
        margin: 0;
        font-size: 17px;
        font-weight: 750;
        color: #0f2a5f;
    }

    .enrollment-result-count {
        font-size: 12px;
        color: #64748b;
        background: #f1f5f9;
        padding: 6px 10px;
        border-radius: 20px;
    }

    .enrollment-filters {
        display: grid;
        grid-template-columns: minmax(200px, 1.7fr) repeat(2, minmax(150px, 1fr)) auto auto;
        gap: 10px;
        padding: 18px 20px;
        border-bottom: 1px solid #e2e8f0;
        background: #f8fafc;
    }

    .enrollment-filters input,
    .enrollment-filters select {
        width: 100%;
        min-width: 0;
        height: 41px;
        border: 1px solid #dbe4f0;
        border-radius: 8px;
        background: #fff;
        color: #334155;
        padding: 0 11px;
        font-size: 13px;
        outline: none;
    }

    .enrollment-filters input:focus,
    .enrollment-filters select:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, .1);
    }

    .enrollment-table-wrap {
        width: 100%;
        overflow-x: auto;
    }

    .enrollment-table {
        width: 100%;
        min-width: 1050px;
        border-collapse: collapse;
        margin: 0;
    }

    .enrollment-table thead th {
        background: #f8fafc;
        color: #64748b;
        font-size: 11px;
        font-weight: 750;
        text-transform: uppercase;
        letter-spacing: .045em;
        padding: 14px 16px;
        border-bottom: 1px solid #e2e8f0;
        white-space: nowrap;
    }

    .enrollment-table tbody td {
        padding: 16px;
        border-bottom: 1px solid #edf2f7;
        vertical-align: middle;
        font-size: 13px;
    }

    .enrollment-table tbody tr:hover {
        background: #f8fbff;
    }

    .enrollment-table tbody tr:last-child td {
        border-bottom: none;
    }

    .enrollment-id {
        color: #64748b;
        font-weight: 700;
    }

    .enrollment-student-name {
        font-weight: 700;
        color: #0f2a5f;
        margin-bottom: 4px;
    }

    .enrollment-secondary {
        color: #64748b;
        font-size: 12px;
        overflow-wrap: anywhere;
    }

    .enrollment-course-name {
        font-weight: 650;
        color: #334155;
        max-width: 220px;
    }

    .enrollment-price {
        font-weight: 750;
        color: #0f2a5f;
        white-space: nowrap;
    }

    .enrollment-status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 750;
        text-transform: capitalize;
        white-space: nowrap;
    }

    .status-success {
        background: #dcfce7;
        color: #166534;
    }

    .status-pending {
        background: #fef3c7;
        color: #92400e;
    }

    .status-danger {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-neutral {
        background: #e2e8f0;
        color: #475569;
    }

    .enrollment-empty {
        padding: 55px 20px;
        text-align: center;
        color: #64748b;
    }

    .enrollment-empty i {
        display: block;
        font-size: 32px;
        margin-bottom: 12px;
        color: #94a3b8;
    }

    .enrollment-empty strong {
        display: block;
        color: #334155;
        margin-bottom: 6px;
        font-size: 15px;
    }

    .enrollment-alert {
        border: 1px solid #fecaca;
        background: #fef2f2;
        color: #991b1b;
        border-radius: 10px;
        padding: 13px 15px;
        margin-bottom: 18px;
        font-size: 13px;
    }

    @media (max-width: 1050px) {
        .enrollment-stats {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .enrollment-filters {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .enrollment-filters .search-field {
            grid-column: 1 / -1;
        }
    }

    @media (max-width: 576px) {
        .enrollment-stats {
            grid-template-columns: 1fr;
        }

        .enrollment-filters {
            grid-template-columns: 1fr;
            padding: 14px;
        }

        .enrollment-filters .search-field {
            grid-column: auto;
        }

        .enrollment-heading h1 {
            font-size: 23px;
        }

        .enrollment-panel-header {
            padding: 16px;
        }
    }

    @media print {
        .enrollment-heading-actions,
        .enrollment-filters,
        .enrollment-panel-header,
        .sidebar,
        .navbar,
        nav,
        footer {
            display: none !important;
        }

        .enrollment-page {
            padding: 0;
        }

        .enrollment-panel {
            border: none;
            box-shadow: none;
        }

        .enrollment-table {
            min-width: 0;
        }

        .enrollment-table thead th,
        .enrollment-table tbody td {
            padding: 8px 5px;
            font-size: 10px;
        }
    }
</style>

<div class="container-fluid enrollment-page">

    <div class="enrollment-heading">
        <div>
            <h1>
                <i class="fa-solid fa-user-graduate"></i>
                Enrollment Management
            </h1>
            <p>Monitor student enrollments, payment status, and course access.</p>
        </div>

        <div class="enrollment-heading-actions d-flex flex-wrap gap-2">
            <button type="button"
                    class="enrollment-btn"
                    onclick="window.print()">
                <i class="fa-solid fa-print"></i>
                Print Register
            </button>

            <a class="enrollment-btn"
               href="<?= e(base_url('assan_computer_institute/admin/dashboard.php')) ?>">
                <i class="fa-solid fa-arrow-left"></i>
                Dashboard
            </a>
        </div>
    </div>

    <?php if ($pageError !== ''): ?>
        <div class="enrollment-alert">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= e($pageError) ?>
        </div>
    <?php endif; ?>

    <div class="enrollment-stats">

        <div class="enrollment-stat">
            <div class="enrollment-stat-icon">
                <i class="fa-solid fa-users"></i>
            </div>
            <div>
                <div class="enrollment-stat-label">Total Enrollments</div>
                <div class="enrollment-stat-value">
                    <?= number_format($totalEnrollments) ?>
                </div>
            </div>
        </div>

        <div class="enrollment-stat">
            <div class="enrollment-stat-icon">
                <i class="fa-solid fa-clock"></i>
            </div>
            <div>
                <div class="enrollment-stat-label">Pending Payments</div>
                <div class="enrollment-stat-value">
                    <?= number_format($pendingPayments) ?>
                </div>
            </div>
        </div>

        <div class="enrollment-stat">
            <div class="enrollment-stat-icon">
                <i class="fa-solid fa-money-bill-wave"></i>
            </div>
            <div>
                <div class="enrollment-stat-label">Paid Enrollments</div>
                <div class="enrollment-stat-value">
                    <?= number_format($paidEnrollments) ?>
                </div>
            </div>
        </div>

        <div class="enrollment-stat">
            <div class="enrollment-stat-icon">
                <i class="fa-solid fa-circle-check"></i>
            </div>
            <div>
                <div class="enrollment-stat-label">Active Course Access</div>
                <div class="enrollment-stat-value">
                    <?= number_format($activeAccess) ?>
                </div>
            </div>
        </div>

    </div>

    <div class="enrollment-panel">

        <div class="enrollment-panel-header">
            <h2>
                <i class="fa-solid fa-list-check"></i>
                Enrollment Register
            </h2>

            <span class="enrollment-result-count">
                <?= number_format($totalFiltered) ?> record(s) found
            </span>
        </div>

        <form method="get"
              action="<?= e(base_url('assan_computer_institute/admin/enrollments.php')) ?>"
              class="enrollment-filters">

            <div class="search-field">
                <input
                    type="search"
                    name="search"
                    value="<?= e($search) ?>"
                    placeholder="Search student, email, course, or ID..."
                    aria-label="Search enrollments">
            </div>

            <div>
                <select name="payment_status" aria-label="Filter payment status">
                    <option value="">All Payment Statuses</option>
                    <?php foreach ($allowedPaymentStatuses as $status): ?>
                        <option value="<?= e($status) ?>"
                            <?= $paymentStatus === $status ? 'selected' : '' ?>>
                            <?= e(ucfirst($status)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <select name="access_status" aria-label="Filter access status">
                    <option value="">All Access Statuses</option>
                    <?php foreach ($allowedAccessStatuses as $status): ?>
                        <option value="<?= e($status) ?>"
                            <?= $accessStatus === $status ? 'selected' : '' ?>>
                            <?= e(ucfirst($status)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="enrollment-btn enrollment-btn-primary">
                <i class="fa-solid fa-filter"></i>
                Filter
            </button>

            <a class="enrollment-btn"
               href="<?= e(base_url('assan_computer_institute/admin/enrollments.php')) ?>">
                <i class="fa-solid fa-rotate-left"></i>
                Reset
            </a>

        </form>

        <?php if ($pageError === ''): ?>

            <div class="enrollment-table-wrap">
                <table class="enrollment-table">

                    <thead>
                        <tr>
                            <th>Enrollment</th>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Course Price</th>
                            <th>Payment</th>
                            <th>Course Access</th>
                            <th>Enrollment Date</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (empty($enrollments)): ?>

                        <tr>
                            <td colspan="7">
                                <div class="enrollment-empty">
                                    <i class="fa-solid fa-folder-open"></i>
                                    <strong>No enrollments found</strong>
                                    Try changing your search or filter settings.
                                </div>
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($enrollments as $enrollment): ?>

                            <?php
                            $payment = isset($enrollment['payment_status'])
                                ? $enrollment['payment_status']
                                : 'unknown';

                            $access = isset($enrollment['access_status'])
                                ? $enrollment['access_status']
                                : 'unknown';

                            $enrollmentDate = '';

                            if (!empty($enrollment['created_at'])) {
                                $timestamp = strtotime($enrollment['created_at']);

                                if ($timestamp !== false) {
                                    $enrollmentDate = date('d M Y', $timestamp);
                                }
                            }
                            ?>

                            <tr>
                                <td>
                                    <span class="enrollment-id">
                                        #<?= (int) $enrollment['id'] ?>
                                    </span>
                                </td>

                                <td>
                                    <div class="enrollment-student-name">
                                        <?= e($enrollment['student_name']) ?>
                                    </div>

                                    <div class="enrollment-secondary">
                                        <?= e($enrollment['student_email']) ?>
                                    </div>

                                    <?php if (!empty($enrollment['student_mobile'])): ?>
                                        <div class="enrollment-secondary">
                                            <?= e($enrollment['student_mobile']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="enrollment-course-name">
                                        <?= e($enrollment['course_title']) ?>
                                    </div>
                                </td>

                                <td>
                                    <span class="enrollment-price">
                                        Rs. <?= number_format(
                                            (float) $enrollment['course_price'],
                                            2
                                        ) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="enrollment-status <?= e(enrollment_status_class($payment)) ?>">
                                        <?= e(ucfirst(str_replace('_', ' ', $payment))) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="enrollment-status <?= e(enrollment_status_class($access)) ?>">
                                        <?= e(ucfirst(str_replace('_', ' ', $access))) ?>
                                    </span>
                                </td>

                                <td>
                                    <?php if ($enrollmentDate !== ''): ?>
                                        <?= e($enrollmentDate) ?>
                                    <?php else: ?>
                                        <span class="enrollment-secondary">Not available</span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </div>

</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>

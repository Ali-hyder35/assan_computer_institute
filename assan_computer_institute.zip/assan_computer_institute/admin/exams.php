<?php /* |-------------------------------------------------------------------------- | Assan Computer Institute | Admin - Exam Management |-------------------------------------------------------------------------- */ 
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_admin();
$pageTitle = 'Manage Exams'; /* |-------------------------------------------------------------------------- | Delete Exam |-------------------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();
        $action = isset($_POST['action']) ? trim($_POST['action']) : '';
        $examId = isset($_POST['exam_id']) ? (int) $_POST['exam_id'] : 0;
        if ($examId <= 0) {
            throw new Exception('Invalid exam selected.');
        }
        if ($action === 'delete') { /* |-------------------------------------------------------------------------- | Check Exam |-------------------------------------------------------------------------- */
            $stmt = $pdo->prepare(" SELECT id, title FROM exams WHERE id = ? LIMIT 1 ");
            $stmt->execute(array($examId));
            $exam = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$exam) {
                throw new Exception('Exam not found.');
            } /* |-------------------------------------------------------------------------- | Delete Exam |-------------------------------------------------------------------------- | | Foreign keys with ON DELETE CASCADE will remove: | - questions | - attempts | - answers |-------------------------------------------------------------------------- */
            $stmt = $pdo->prepare(" DELETE FROM exams WHERE id = ? ");
            $stmt->execute(array($examId));
            flash('success', 'Exam "' . $exam['title'] . '" deleted successfully.');
        }
        elseif ($action === 'toggle') {
            $stmt = $pdo->prepare(" SELECT active FROM exams WHERE id = ? LIMIT 1 ");
            $stmt->execute(array($examId));
            $exam = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$exam) {
                throw new Exception('Exam not found.');
            }
            $newStatus = ((int) $exam['active'] === 1) ? 0 : 1;
            $stmt = $pdo->prepare(" UPDATE exams SET active = ?, updated_at = NOW() WHERE id = ? ");
            $stmt->execute(array($newStatus, $examId));
            flash('success', $newStatus ? 'Exam published successfully.' : 'Exam unpublished successfully.');
        }
    } catch (Exception $e) {
        flash('error', $e->getMessage());
    }
    redirect(base_url('assan_computer_institute/admin/exams.php'));
} /* |-------------------------------------------------------------------------- | Load Exams |-------------------------------------------------------------------------- */
$stmt = $pdo->query(" SELECT e.id, e.course_id, e.title, e.description, e.duration_minutes, e.total_marks, e.pass_marks, e.attempts_allowed, e.active, e.created_at, e.updated_at, c.title AS course_title, COUNT(DISTINCT eq.id) AS question_count, COUNT( DISTINCT CASE WHEN ea.status IN ('submitted', 'expired') THEN ea.id END ) AS completed_attempts, COUNT( DISTINCT ea.user_id ) AS students_attempted FROM exams e INNER JOIN courses c ON c.id = e.course_id LEFT JOIN exam_questions eq ON eq.exam_id = e.id AND eq.active = 1 LEFT JOIN exam_attempts ea ON ea.exam_id = e.id GROUP BY e.id, e.course_id, e.title, e.description, e.duration_minutes, e.total_marks, e.pass_marks, e.attempts_allowed, e.active, e.created_at, e.updated_at, c.title ORDER BY e.id DESC ");
$exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
$flashSuccess = flash('success');
$flashError = flash('error');
require_once dirname(__DIR__) . '/partials/header.php'; ?>
<style>
    :root {
        --lms-primary: #0f2a5f;
        --lms-primary-light: #1e4b8f;
        --lms-accent: #2563eb;
        --lms-accent-hover: #1d4ed8;
        --lms-bg: #f5f7fb;
        --lms-text: #1e293b;
        --lms-muted: #64748b;
        --lms-border: #e2e8f0;
        --lms-success: #16a34a;
        --lms-danger: #dc2626;
        --lms-warning: #d97706;
        --lms-shadow: 0 8px 25px rgba(15, 42, 95, .08);
    }

    body {
        background: var(--lms-bg);
    }

    .admin-exams-page {
        padding: 30px 0 60px;
    }

    .page-header {
        background: linear-gradient(135deg, var(--lms-primary), var(--lms-primary-light));
        color: #fff;
        border-radius: 18px;
        padding: 28px;
        margin-bottom: 25px;
        box-shadow: var(--lms-shadow);
    }

    .page-header h2 {
        margin: 0 0 6px;
        font-weight: 700;
    }

    .page-header p {
        margin: 0;
        color: rgba(255, 255, 255, .8);
    }

    .btn-create {
        background: #fff;
        color: var(--lms-primary);
        border: none;
        border-radius: 10px;
        padding: 11px 17px;
        font-weight: 700;
        text-decoration: none;
    }

    .btn-create:hover {
        color: var(--lms-primary);
        background: #f8fafc;
    }

    .exam-table-card {
        background: #fff;
        border: 1px solid var(--lms-border);
        border-radius: 16px;
        padding: 20px;
        box-shadow: var(--lms-shadow);
    }

    .exam-table th {
        color: var(--lms-muted);
        font-size: 12px;
        text-transform: uppercase;
        white-space: nowrap;
    }

    .exam-table td {
        vertical-align: middle;
        color: var(--lms-text);
    }

    .exam-name {
        font-weight: 700;
    }

    .course-name {
        font-size: 13px;
        color: var(--lms-muted);
    }

    .status-badge {
        display: inline-block;
        padding: 6px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 800;
    }

    .status-active {
        background: #dcfce7;
        color: #166534;
    }

    .status-inactive {
        background: #fee2e2;
        color: #991b1b;
    }

    .action-btn {
        border: 1px solid var(--lms-border);
        background: #fff;
        border-radius: 8px;
        padding: 7px 10px;
        text-decoration: none;
        color: var(--lms-text);
        font-size: 13px;
    }

    .action-btn:hover {
        background: #f8fafc;
        color: var(--lms-accent);
    }

    .action-primary {
        color: var(--lms-accent);
    }

    .action-danger {
        color: var(--lms-danger);
    }

    .empty-box {
        padding: 60px 20px;
        text-align: center;
    }

    .empty-box i {
        font-size: 50px;
        color: var(--lms-accent);
    }

    .empty-box h4 {
        margin-top: 15px;
    }
</style>
<div class="container admin-exams-page">
    <div class="page-header">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h2> <i class="bi bi-journal-check me-2"></i> Exam Management </h2>
                <p> Create, manage and monitor student examinations. </p>
            </div>
            <div> <a href="<?= e(base_url('assan_computer_institute/admin/exam_create.php')) ?>" class="btn-create"> <i
                        class="bi bi-plus-circle me-1"></i> Create Exam </a> </div>
        </div>
    </div> <?php if ($flashSuccess): ?>
        <div class="alert alert-success"> <?= e($flashSuccess) ?> </div> <?php endif; ?> <?php if ($flashError): ?>
        <div class="alert alert-danger"> <?= e($flashError) ?> </div> <?php endif; ?>
    <div class="exam-table-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h5 class="fw-bold mb-1"> All Exams </h5> <small class="text-muted"> Manage your institute examinations.
                </small>
            </div> <span class="badge bg-primary"> <?= count($exams) ?> Exams </span>
        </div> <?php if (empty($exams)): ?>
            <div class="empty-box"> <i class="bi bi-journal-x"></i>
                <h4> No Exams Created </h4>
                <p class="text-muted"> Create your first exam to start evaluating students. </p> <a
                    href="<?= e(base_url('assan_computer_institute/admin/exam_create.php')) ?>" class="btn btn-primary">
                    Create First Exam </a>
            </div> <?php else: ?>
            <div class="table-responsive">
                <table class="table exam-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Exam</th>
                            <th>Course</th>
                            <th>Questions</th>
                            <th>Marks</th>
                            <th>Duration</th>
                            <th>Attempts</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody> <?php foreach ($exams as $exam): ?>
                            <tr>
                                <td> #<?= (int) $exam['id'] ?> </td>
                                <td>
                                    <div class="exam-name"> <?= e($exam['title']) ?> </div>
                                </td>
                                <td>
                                    <div class="course-name"> <?= e($exam['course_title']) ?> </div>
                                </td>
                                <td> <?= (int) $exam['question_count'] ?> </td>
                                <td> <?= e($exam['total_marks']) ?> <small class="text-muted"> / Pass
                                        <?= e($exam['pass_marks']) ?> </small> </td>
                                <td> <?= (int) $exam['duration_minutes'] ?> min </td>
                                <td> <?= (int) $exam['students_attempted'] ?> </td>
                                <td> <?php if ((int) $exam['active'] === 1): ?> <span class="status-badge status-active">
                                            Published </span> <?php else: ?> <span class="status-badge status-inactive"> Unpublished
                                        </span> <?php endif; ?> </td>
                                <td>
                                    <div class="d-flex flex-wrap gap-1"> <a
                                            href="<?= e(base_url('assan_computer_institute/admin/exam_questions.php?id=' . (int) $exam['id'])) ?>"
                                            class="action-btn action-primary" title="Questions"> <i
                                                class="bi bi-list-check"></i> </a> <a
                                            href="<?= e(base_url('assan_computer_institute/admin/exam_edit.php?id=' . (int) $exam['id'])) ?>"
                                            class="action-btn" title="Edit"> <i class="bi bi-pencil"></i> </a> <a
                                            href="<?= e(base_url('assan_computer_institute/admin/exam_results.php?exam_id=' . (int) $exam['id'])) ?>"
                                            class="action-btn" title="Results"> <i class="bi bi-bar-chart"></i> </a>
                                        <form method="post" style="display:inline;"> <?= csrf_field() ?> <input type="hidden"
                                                name="action" value="toggle"> <input type="hidden" name="exam_id"
                                                value="<?= (int) $exam['id'] ?>"> <button type="submit" class="action-btn"
                                                title="<?= (int) $exam['active'] ? 'Unpublish' : 'Publish' ?>">
                                                <?php if ((int) $exam['active']): ?> <i class="bi bi-eye-slash"></i>
                                                <?php else: ?> <i class="bi bi-eye"></i> <?php endif; ?> </button> </form>
                                        <form method="post" style="display:inline;"
                                            onsubmit="return confirm('Delete this exam and all its questions, attempts and answers?');">
                                            <?= csrf_field() ?> <input type="hidden" name="action" value="delete"> <input
                                                type="hidden" name="exam_id" value="<?= (int) $exam['id'] ?>"> <button
                                                type="submit" class="action-btn action-danger" title="Delete"> <i
                                                    class="bi bi-trash"></i> </button> </form>
                                    </div>
                                </td>
                            </tr> <?php endforeach; ?>
                    </tbody>
                </table>
            </div> <?php endif; ?>
    </div>
</div> <?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
```php
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();


/*
|--------------------------------------------------------------------------
| Only POST Allowed
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header(
        'Location: ' .
        base_url('assan_computer_institute/admin/courses.php')
    );

    exit;
}


try {

    verify_csrf();


    $courseId = isset($_POST['course_id'])
        ? (int) $_POST['course_id']
        : 0;


    if ($courseId <= 0) {

        throw new Exception(
            'Invalid course selected.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Check Course
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id, title
        FROM courses
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute(array($courseId));

    $course = $stmt->fetch();


    if (!$course) {

        throw new Exception(
            'Course not found.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Check Enrollments
    |--------------------------------------------------------------------------
    */

    $check = $pdo->prepare("
        SELECT COUNT(*)
        FROM enrollments
        WHERE course_id = ?
    ");

    $check->execute(array($courseId));

    $enrollmentCount = (int) $check->fetchColumn();


    if ($enrollmentCount > 0) {

        throw new Exception(
            'This course cannot be deleted because students are enrolled in it. Disable the course instead.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Delete Course
    |--------------------------------------------------------------------------
    |
    | course_videos should have ON DELETE CASCADE.
    |
    */

    $delete = $pdo->prepare("
        DELETE FROM courses
        WHERE id = ?
    ");

    $delete->execute(array($courseId));


    header(
        'Location: ' .
        base_url('assan_computer_institute/admin/courses.php?success=course_deleted')
    );

    exit;


} catch (Exception $e) {

    header(
        'Location: ' .
        base_url(
            'assan_computer_institute/admin/courses.php?error=' .
            urlencode($e->getMessage())
        )
    );

    exit;
}


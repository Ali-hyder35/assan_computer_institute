<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

/*
|--------------------------------------------------------------------------
| Flash Messages
|--------------------------------------------------------------------------
| Payment verification messages are displayed ONLY on admin dashboard.
|--------------------------------------------------------------------------
*/

$flashSuccess = '';
$flashError   = '';

if (function_exists('flash')) {
    $flashSuccess = flash('success');
    $flashError   = flash('error');
}

/*
|--------------------------------------------------------------------------
| Shared Header Variables
|--------------------------------------------------------------------------
*/

if (!isset($pageTitle)) {
    $pageTitle = 'Assan Computer Institute';
}

$navUser = null;

if (function_exists('current_user')) {
    $navUser = current_user();
}

$isAdmin = $navUser &&
    isset($navUser['role']) &&
    $navUser['role'] === 'admin';

$isStudent = $navUser &&
    isset($navUser['role']) &&
    $navUser['role'] === 'student';

$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));

/*
|--------------------------------------------------------------------------
| Dashboard Data
|--------------------------------------------------------------------------
*/

$students = (int) $pdo->query("
    SELECT COUNT(*)
    FROM users
    WHERE role = 'student'
")->fetchColumn();

$courses = (int) $pdo->query("
    SELECT COUNT(*)
    FROM courses
    WHERE active = 1
")->fetchColumn();

$orders = (int) $pdo->query("
    SELECT COUNT(*)
    FROM enrollments
")->fetchColumn();

$paid = (float) $pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM enrollments
    WHERE payment_status = 'paid'
")->fetchColumn();

$pending = (int) $pdo->query("
    SELECT COUNT(*)
    FROM enrollments
    WHERE payment_status = 'pending'
")->fetchColumn();

$activeAccess = (int) $pdo->query("
    SELECT COUNT(*)
    FROM enrollments
    WHERE access_status = 'active'
")->fetchColumn();

/*
|--------------------------------------------------------------------------
| Recent Enrollments
|--------------------------------------------------------------------------
*/

$rows = $pdo->query("
    SELECT
        e.*,
        u.full_name,
        u.email,
        c.title
    FROM enrollments e
    INNER JOIN users u
        ON u.id = e.user_id
    INNER JOIN courses c
        ON c.id = e.course_id
    ORDER BY e.created_at DESC
    LIMIT 100
")->fetchAll();

$adminUser = current_user();

$pageTitle = 'Admin Dashboard';

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        <?= e($pageTitle) ?> | Assan Computer Institute
    </title>

    <meta
        name="description"
        content="Assan Computer Institute - Online Learning Management System">

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

    <style>

        :root {
            --aci-blue: #1f3c88;
            --aci-blue-dark: #14295f;
            --aci-blue-light: #edf2ff;
            --aci-red: #c0392b;
            --aci-bg: #f4f7fc;
            --aci-border: #e5eaf2;
            --aci-text: #172033;
            --aci-muted: #7d8799;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--aci-bg);
            color: var(--aci-text);
            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Arial,
                sans-serif;
        }

        /* =====================================================
           ADMIN NAVBAR
        ===================================================== */

        .aci-admin-navbar {
            min-height: 76px;
            background: #ffffff;
            border-bottom: 1px solid #e7ebf2;
            box-shadow: 0 4px 18px rgba(20, 41, 95, .06);
            position: sticky;
            top: 0;
            z-index: 1030;
        }

        .aci-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: var(--aci-text);
        }

        .aci-brand-logo {
            width: 45px;
            height: 45px;
            border-radius: 13px;
            background: linear-gradient(
                135deg,
                var(--aci-blue-dark),
                var(--aci-blue)
            );
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 20px;
            box-shadow: 0 7px 18px rgba(31, 60, 136, .22);
            overflow: hidden;
        }

        .aci-brand-logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .aci-brand-name {
            font-size: 17px;
            font-weight: 800;
            line-height: 1.1;
        }

        .aci-brand-subtitle {
            display: block;
            color: #929bad;
            font-size: 10px;
            font-weight: 600;
            margin-top: 3px;
        }

        /* =====================================================
           NAV LINKS
        ===================================================== */

        .aci-nav-link {
            position: relative;
            display: inline-flex !important;
            align-items: center;
            gap: 7px;
            color: #596477 !important;
            font-size: 12px;
            font-weight: 700;
            padding: 10px 12px !important;
            border-radius: 10px;
            transition: all .2s ease;
        }

        .aci-nav-link:hover {
            color: var(--aci-blue) !important;
            background: var(--aci-blue-light);
        }

        .aci-nav-link.active {
            color: var(--aci-blue) !important;
            background: #edf2ff;
        }

        .aci-nav-link i {
            font-size: 12px;
        }

        /* =====================================================
           DROPDOWN
        ===================================================== */

        .aci-dropdown {
            border: 1px solid var(--aci-border);
            border-radius: 15px;
            padding: 8px;
            min-width: 220px;
            box-shadow: 0 18px 40px rgba(25, 40, 75, .13);
            margin-top: 8px !important;
        }

        .aci-dropdown .dropdown-item {
            padding: 10px 12px;
            border-radius: 9px;
            color: #596477;
            font-size: 12px;
            font-weight: 650;
        }

        .aci-dropdown .dropdown-item:hover {
            background: #edf2ff;
            color: var(--aci-blue);
        }

        .aci-dropdown .dropdown-item i {
            width: 20px;
            margin-right: 5px;
        }

        .dropdown-title {
            padding: 7px 12px 5px;
            color: #9aa3b2;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        /* =====================================================
           USER AREA
        ===================================================== */

        .aci-user-area {
            display: flex;
            align-items: center;
            gap: 10px;
            padding-left: 15px;
            margin-left: 8px;
            border-left: 1px solid #e7ebf2;
        }

        .aci-user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 11px;
            background: linear-gradient(
                135deg,
                #e9efff,
                #dce7ff
            );
            color: var(--aci-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 800;
        }

        .aci-user-name {
            color: var(--aci-text);
            font-size: 11px;
            font-weight: 800;
            line-height: 1.2;
        }

        .aci-user-role {
            color: #929bad;
            font-size: 9px;
            margin-top: 2px;
        }

        .aci-logout {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--aci-red);
            background: #fff3f1;
            text-decoration: none;
            transition: all .2s ease;
        }

        .aci-logout:hover {
            background: var(--aci-red);
            color: #fff;
        }

        .navbar-toggler {
            border: 0;
            padding: 8px;
            color: var(--aci-blue);
            box-shadow: none !important;
        }

        @media (max-width: 991px) {

            .aci-admin-navbar {
                padding: 7px 0;
            }

            .aci-nav-link {
                margin-top: 3px;
            }

            .aci-user-area {
                border-left: 0;
                border-top: 1px solid #e7ebf2;
                margin: 10px 0 0;
                padding: 12px 0 0;
            }

        }

        /* =========================================================
           DASHBOARD
        ========================================================= */

        .admin-dashboard {
            background: #f4f7fc;
            min-height: calc(100vh - 76px);
            padding: 30px 0 60px;
        }

        /* =========================================================
           ALERTS
        ========================================================= */

        .payment-alert {
            border: 0;
            border-radius: 14px;
            padding: 16px 20px;
            box-shadow: 0 8px 25px rgba(25, 40, 75, .06);
        }

        .payment-alert-success {
            border-left: 5px solid #16a34a;
            background: #ecfdf5;
            color: #166534;
        }

        .payment-alert-error {
            border-left: 5px solid #dc2626;
            background: #fef2f2;
            color: #991b1b;
        }

        .alert-icon {
            width: 38px;
            height: 38px;
            min-width: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 18px;
            font-weight: 700;
        }

        .success-icon {
            background: #dcfce7;
            color: #16a34a;
        }

        .error-icon {
            background: #fee2e2;
            color: #dc2626;
        }

        /* =========================================================
           WELCOME
        ========================================================= */

        .dashboard-welcome {
            background:
                linear-gradient(
                    135deg,
                    #14295f 0%,
                    #1f3c88 55%,
                    #376bc8 100%
                );

            border-radius: 24px;
            padding: 34px;
            color: #fff;
            position: relative;
            overflow: hidden;
            box-shadow:
                0 18px 45px rgba(31,60,136,.18);
        }

        .dashboard-welcome::before {
            content: "";
            position: absolute;
            width: 330px;
            height: 330px;
            border-radius: 50%;
            right: -120px;
            top: -180px;
            background: rgba(255,255,255,.06);
        }

        .dashboard-welcome::after {
            content: "";
            position: absolute;
            width: 220px;
            height: 220px;
            border-radius: 50%;
            right: 180px;
            bottom: -180px;
            background: rgba(255,255,255,.04);
        }

        .welcome-content {
            position: relative;
            z-index: 2;
        }

        .welcome-label {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 13px;
            border-radius: 50px;
            background: rgba(255,255,255,.12);
            border: 1px solid rgba(255,255,255,.16);
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1px;
        }

        .welcome-title {
            font-size: 30px;
            font-weight: 800;
            margin: 15px 0 7px;
        }

        .welcome-text {
            color: rgba(255,255,255,.76);
            font-size: 13px;
            margin: 0;
        }

        .welcome-actions {
            position: relative;
            z-index: 3;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .welcome-button {
            border-radius: 11px;
            padding: 11px 17px;
            font-size: 12px;
            font-weight: 750;
        }

        /* =========================================================
           STAT CARDS
        ========================================================= */

        .dashboard-stat {
            background: #fff;
            border: 1px solid #e5eaf2;
            border-radius: 19px;
            padding: 22px;
            height: 100%;
            box-shadow: 0 6px 22px rgba(25,40,75,.045);
            transition: .25s ease;
            position: relative;
            overflow: hidden;
        }

        .dashboard-stat:hover {
            transform: translateY(-5px);
            box-shadow: 0 16px 34px rgba(25,40,75,.10);
        }

        .dashboard-stat::after {
            content: "";
            position: absolute;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            right: -60px;
            bottom: -60px;
            background: #f8faff;
        }

        .stat-icon {
            width: 52px;
            height: 52px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 20px;
            position: relative;
            z-index: 2;
        }

        .icon-blue {
            background: #eaf0ff;
            color: #1f3c88;
        }

        .icon-green {
            background: #eaf8ef;
            color: #16834b;
        }

        .icon-orange {
            background: #fff3df;
            color: #ae6800;
        }

        .icon-purple {
            background: #f1ecff;
            color: #6741c9;
        }

        .stat-title {
            color: #8b94a6;
            font-size: 10px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .7px;
            position: relative;
            z-index: 2;
        }

        .stat-value {
            color: #172033;
            font-size: 29px;
            line-height: 1;
            font-weight: 800;
            margin: 8px 0;
            position: relative;
            z-index: 2;
        }

        .stat-description {
            color: #8992a4;
            font-size: 11px;
            position: relative;
            z-index: 2;
        }

        /* =========================================================
           SECTION
        ========================================================= */

        .section-heading {
            margin: 35px 0 17px;
        }

        .section-heading h4 {
            color: #172033;
            font-size: 20px;
            font-weight: 800;
            margin: 0;
        }

        .section-heading p {
            color: #8992a4;
            font-size: 12px;
            margin: 5px 0 0;
        }

        /* =========================================================
           MANAGEMENT
        ========================================================= */

        .management-card {
            display: block;
            height: 100%;
            background: #fff;
            border: 1px solid #e5eaf2;
            border-radius: 18px;
            padding: 21px;
            text-decoration: none;
            color: inherit;
            box-shadow: 0 5px 18px rgba(25,40,75,.04);
            transition: .25s ease;
        }

        .management-card:hover {
            color: inherit;
            transform: translateY(-5px);
            border-color: #d7e0f5;
            box-shadow: 0 16px 32px rgba(25,40,75,.09);
        }

        .management-icon {
            width: 47px;
            height: 47px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            margin-bottom: 17px;
        }

        .management-card h5 {
            color: #172033;
            font-size: 14px;
            font-weight: 800;
            margin-bottom: 6px;
        }

        .management-card p {
            color: #8992a4;
            font-size: 11px;
            line-height: 1.6;
            margin: 0;
        }

        .management-arrow {
            margin-top: 15px;
            color: #1f3c88;
            font-size: 11px;
            font-weight: 800;
        }

        /* =========================================================
           SUMMARY
        ========================================================= */

        .summary-card {
            background: #fff;
            border: 1px solid #e5eaf2;
            border-radius: 16px;
            padding: 17px 19px;
            display: flex;
            align-items: center;
            gap: 13px;
            box-shadow: 0 5px 17px rgba(25,40,75,.04);
        }

        .summary-icon {
            width: 42px;
            height: 42px;
            border-radius: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .summary-number {
            display: block;
            color: #172033;
            font-size: 19px;
            font-weight: 800;
        }

        .summary-label {
            display: block;
            color: #8992a4;
            font-size: 11px;
        }

        /* =========================================================
           ENROLLMENTS
        ========================================================= */

        .enrollment-card {
            background: #fff;
            border: 1px solid #e5eaf2;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 7px 25px rgba(25,40,75,.055);
        }

        .enrollment-header {
            padding: 21px 23px;
            border-bottom: 1px solid #e9edf4;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .enrollment-title {
            color: #172033;
            font-size: 15px;
            font-weight: 800;
        }

        .enrollment-subtitle {
            color: #8992a4;
            font-size: 11px;
            margin-top: 3px;
        }

        .record-badge {
            background: #edf2ff;
            color: #1f3c88;
            padding: 7px 11px;
            border-radius: 30px;
            font-size: 10px;
            font-weight: 800;
        }

        /* =========================================================
           TABLE
        ========================================================= */

        .admin-table {
            margin: 0;
        }

        .admin-table thead th {
            background: #f8faff;
            color: #697386;
            border-bottom: 1px solid #e5eaf2;
            padding: 14px 17px;
            font-size: 9px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .65px;
            white-space: nowrap;
        }

        .admin-table tbody td {
            padding: 16px 17px;
            border-bottom: 1px solid #edf0f5;
            vertical-align: middle;
        }

        .admin-table tbody tr {
            transition: .2s ease;
        }

        .admin-table tbody tr:hover {
            background: #fafbff;
        }

        .admin-table tbody tr:last-child td {
            border-bottom: 0;
        }

        /* =========================================================
           STUDENT
        ========================================================= */

        .student-info {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 210px;
        }

        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 11px;
            background: linear-gradient(135deg,#e9efff,#dce7ff);
            color: #1f3c88;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 800;
        }

        .student-name {
            color: #172033;
            font-size: 12px;
            font-weight: 800;
        }

        .student-email {
            color: #929bad;
            font-size: 9px;
            margin-top: 3px;
        }

        .course-title {
            color: #283449;
            font-size: 12px;
            font-weight: 700;
            min-width: 140px;
        }

        .order-code {
            background: #f3f5f9;
            color: #596477;
            padding: 6px 8px;
            border-radius: 7px;
            font-family: monospace;
            font-size: 9px;
            white-space: nowrap;
        }

        .amount-value {
            color: #172033;
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }

        /* =========================================================
           PAYMENT PROOF
        ========================================================= */

        .payment-proof-wrapper {
            position: relative;
            display: inline-block;
        }

        .payment-proof-thumb {
            width: 58px;
            height: 58px;
            object-fit: cover;
            border-radius: 9px;
            border: 1px solid #dfe5ef;
            background: #f8faff;
            cursor: zoom-in;
            transition: all .2s ease;
            display: block;
        }

        .payment-proof-thumb:hover {
            transform: scale(1.08);
            box-shadow: 0 8px 22px rgba(25, 40, 75, .18);
        }

        .payment-proof-preview {
            position: fixed;
            display: none;
            z-index: 99999;
            width: 420px;
            max-width: 70vw;
            max-height: 80vh;
            object-fit: contain;
            background: #ffffff;
            padding: 8px;
            border: 1px solid #dce3ef;
            border-radius: 14px;
            box-shadow: 0 20px 60px rgba(15, 23, 42, .30);
            pointer-events: none;
        }

        .payment-proof-wrapper:hover .payment-proof-preview {
            display: block;
        }

        .no-payment-proof {
            color: #9aa3b2;
            font-size: 10px;
            font-weight: 700;
            white-space: nowrap;
        }

        /* =========================================================
           STATUS
        ========================================================= */

        .status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 50px;
            font-size: 9px;
            font-weight: 800;
            white-space: nowrap;
        }

        .status-dot {
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: currentColor;
        }

        .status-paid {
            color: #16834b;
            background: #eaf8ef;
        }

        .status-pending {
            color: #ae6800;
            background: #fff4df;
        }

        .status-active {
            color: #1f3c88;
            background: #eaf0ff;
        }

        .status-inactive {
            color: #697386;
            background: #f0f2f5;
        }

        .mark-paid {
            border-radius: 8px;
            padding: 7px 10px;
            font-size: 9px;
            font-weight: 800;
            white-space: nowrap;
        }

        .completed {
            color: #929bad;
            font-size: 10px;
            white-space: nowrap;
        }

        /* =========================================================
           EMPTY
        ========================================================= */

        .empty-state {
            text-align: center;
            padding: 65px 20px;
        }

        .empty-icon {
            width: 72px;
            height: 72px;
            margin: auto auto 16px;
            border-radius: 20px;
            background: #eef3ff;
            color: #1f3c88;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 27px;
        }

        .empty-state h5 {
            color: #172033;
            font-weight: 800;
        }

        .empty-state p {
            color: #8992a4;
            font-size: 12px;
        }

        @media (max-width: 767px) {

            .admin-dashboard {
                padding-top: 18px;
            }

            .dashboard-welcome {
                padding: 25px;
                border-radius: 19px;
            }

            .welcome-title {
                font-size: 24px;
            }

            .welcome-actions {
                justify-content: flex-start;
                flex-direction: column;
                margin-top: 23px;
            }

            .welcome-button {
                width: 100%;
            }

            .enrollment-header {
                align-items: flex-start;
                flex-direction: column;
                gap: 12px;
            }

        }

    </style>

</head>

<body>

<?php if ($isAdmin): ?>

    <!-- =====================================================
         ADMIN NAVBAR
    ====================================================== -->

    <nav class="navbar navbar-expand-lg aci-admin-navbar">

        <div class="container-fluid px-lg-4">

            <a
                href="<?= e(base_url('assan_computer_institute_admin/dashboard.php')) ?>"
                class="aci-brand">

                <div class="aci-brand-logo">

                    <?php if (file_exists(dirname(__DIR__) . '/images/logo.png')): ?>

                        <img
                            src="<?= e(base_url('images/logo.png')) ?>"
                            alt="Assan Computer Institute">

                    <?php else: ?>

                        <i class="fa-solid fa-graduation-cap"></i>

                    <?php endif; ?>

                </div>

                <div>

                    <div class="aci-brand-name">
                        Assan Computer Institute
                    </div>

                    <span class="aci-brand-subtitle">
                        Learning Management System
                    </span>

                </div>

            </a>

            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#adminNavbar">

                <i class="fa-solid fa-bars"></i>

            </button>

            <div
                class="collapse navbar-collapse"
                id="adminNavbar">

                <ul class="navbar-nav mx-auto align-items-lg-center gap-lg-1">

                    <li class="nav-item">

                        <a
                            href="<?= e(base_url('assan_computer_institute/admin/dashboard.php')) ?>"
                            class="nav-link aci-nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">

                            <i class="fa-solid fa-chart-pie"></i>
                            Dashboard

                        </a>

                    </li>

                    <li class="nav-item dropdown">

                        <a
                            href="#"
                            class="nav-link aci-nav-link dropdown-toggle"
                            data-bs-toggle="dropdown">

                            <i class="fa-solid fa-book-open"></i>
                            Courses

                        </a>

                        <ul class="dropdown-menu aci-dropdown">

                            <li class="dropdown-title">
                                Course Management
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/courses.php')) ?>">

                                    <i class="fa-solid fa-list"></i>
                                    View Courses

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/add_course.php')) ?>">

                                    <i class="fa-solid fa-plus"></i>
                                    Add Course

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/course_videos.php')) ?>">

                                    <i class="fa-solid fa-video"></i>
                                    Manage Videos

                                </a>
                            </li>

                        </ul>

                    </li>

                    <li class="nav-item dropdown">

                        <a
                            href="#"
                            class="nav-link aci-nav-link dropdown-toggle"
                            data-bs-toggle="dropdown">

                            <i class="fa-solid fa-users"></i>
                            Students

                        </a>

                        <ul class="dropdown-menu aci-dropdown">

                            <li class="dropdown-title">
                                Student Management
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/students.php')) ?>">

                                    <i class="fa-solid fa-users"></i>
                                    View Students

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/enrollments.php')) ?>">

                                    <i class="fa-solid fa-user-plus"></i>
                                    Enrollments

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/student_progress.php')) ?>">

                                    <i class="fa-solid fa-chart-line"></i>
                                    Student Progress

                                </a>
                            </li>

                        </ul>

                    </li>

                    <li class="nav-item dropdown">

                        <a
                            href="#"
                            class="nav-link aci-nav-link dropdown-toggle"
                            data-bs-toggle="dropdown">

                            <i class="fa-solid fa-file-circle-check"></i>
                            Exams

                        </a>

                        <ul class="dropdown-menu aci-dropdown">

                            <li class="dropdown-title">
                                Examination
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/exams.php')) ?>">

                                    <i class="fa-solid fa-list-check"></i>
                                    View Exams

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/exam_add.php')) ?>">

                                    <i class="fa-solid fa-plus"></i>
                                    Create Exam

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/exam_results.php')) ?>">

                                    <i class="fa-solid fa-square-poll-vertical"></i>
                                    Exam Results

                                </a>
                            </li>

                            <li>
                                <a
                                    class="dropdown-item"
                                    href="<?= e(base_url('assan_computer_institute/admin/marks.php')) ?>">

                                    <i class="fa-solid fa-ranking-star"></i>
                                    Student Marks

                                </a>
                            </li>

                        </ul>

                    </li>

                    <li class="nav-item">

                        <a
                            href="<?= e(base_url('assan_computer_institute/admin/certificates.php')) ?>"
                            class="nav-link aci-nav-link">

                            <i class="fa-solid fa-certificate"></i>
                            Certificates

                        </a>

                    </li>

                    <li class="nav-item">

                        <a
                            href="<?= e(base_url('assan_computer_institute/admin/enrollments.php')) ?>"
                            class="nav-link aci-nav-link">

                            <i class="fa-solid fa-money-bill-transfer"></i>
                            Payments

                        </a>

                    </li>

                </ul>

                <div class="aci-user-area">

                    <?php

                    $adminName = isset($navUser['full_name'])
                        ? $navUser['full_name']
                        : 'Administrator';

                    $adminInitial = strtoupper(
                        substr($adminName, 0, 1)
                    );

                    ?>

                    <div class="aci-user-avatar">
                        <?= e($adminInitial) ?>
                    </div>

                    <div class="d-none d-xl-block">

                        <div class="aci-user-name">
                            <?= e($adminName) ?>
                        </div>

                        <div class="aci-user-role">
                            Administrator
                        </div>

                    </div>

                    <a
                        href="<?= e(base_url('assan_computer_institute/index.php')) ?>"
                        class="aci-logout"
                        title="Logout">

                        <i class="fa-solid fa-right-from-bracket"></i>

                    </a>

                </div>

            </div>

        </div>

    </nav>

<?php else: ?>

    <nav class="navbar navbar-expand-lg bg-white shadow-sm">

        <div class="container">

            <a
                class="navbar-brand fw-bold text-primary"
                href="<?= e(base_url('assan_computer_institute/index.php')) ?>">

                <i class="fa-solid fa-graduation-cap me-2"></i>
                Assan Computer Institute

            </a>

            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#mainNavbar">

                <i class="fa-solid fa-bars"></i>

            </button>

            <div
                class="collapse navbar-collapse"
                id="mainNavbar">

                <ul class="navbar-nav ms-auto align-items-lg-center">

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="<?= e(base_url('assan_computer_institute/index.php')) ?>">
                            Home
                        </a>
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="<?= e(base_url('assan_computer_institute/index.php#courses')) ?>">
                            Courses
                        </a>
                    </li>

                    <?php if ($isStudent): ?>

                        <li class="nav-item">
                            <a
                                class="nav-link"
                                href="<?= e(base_url('assan_computer_institute/student/dashboard.php')) ?>">
                                Student Dashboard
                            </a>
                        </li>

                        <li class="nav-item">
                            <a
                                class="nav-link text-danger"
                                href="<?= e(base_url('assan_computer_institute/student/logout.php')) ?>">
                                Logout
                            </a>
                        </li>

                    <?php else: ?>

                        <li class="nav-item">
                            <a
                                class="nav-link"
                                href="<?= e(base_url('assan_computer_institute/student/login.php')) ?>">
                                Login
                            </a>
                        </li>

                        <li class="nav-item">
                            <a
                                class="btn btn-primary btn-sm px-3 ms-lg-2"
                                href="<?= e(base_url('assan_computer_institute/student/register.php')) ?>">
                                Register
                            </a>
                        </li>

                    <?php endif; ?>

                </ul>

            </div>

        </div>

    </nav>

<?php endif; ?>


<div class="admin-dashboard">

    <div class="container-fluid px-lg-5">

        <!-- =================================================
             FLASH SUCCESS
        ================================================== -->

        <?php if (!empty($flashSuccess)): ?>

            <div
                class="alert alert-dismissible fade show payment-alert payment-alert-success mb-4"
                role="alert">

                <div class="d-flex align-items-center">

                    <div class="alert-icon success-icon">
                        <i class="fa-solid fa-check"></i>
                    </div>

                    <div>

                        <strong>
                            Payment Verified Successfully
                        </strong>

                        <div class="mt-1">
                            <?= e($flashSuccess) ?>
                        </div>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close">
                </button>

            </div>

        <?php endif; ?>


        <!-- =================================================
             FLASH ERROR
        ================================================== -->

        <?php if (!empty($flashError)): ?>

            <div
                class="alert alert-dismissible fade show payment-alert payment-alert-error mb-4"
                role="alert">

                <div class="d-flex align-items-center">

                    <div class="alert-icon error-icon">
                        <i class="fa-solid fa-exclamation"></i>
                    </div>

                    <div>

                        <strong>
                            Payment Verification Error
                        </strong>

                        <div class="mt-1">
                            <?= e($flashError) ?>
                        </div>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close">
                </button>

            </div>

        <?php endif; ?>


        <!-- =================================================
             WELCOME
        ================================================== -->

        <div class="dashboard-welcome mb-4">

            <div class="row align-items-center">

                <div class="col-lg-8">

                    <div class="welcome-content">

                        <span class="welcome-label">

                            <i class="fa-solid fa-shield-halved"></i>

                            ADMINISTRATION PANEL

                        </span>

                        <h1 class="welcome-title">

                            Welcome,
                            <?= e($adminUser['full_name']) ?>

                        </h1>

                        <p class="welcome-text">

                            Manage your institute, courses, students,
                            self-paced learning content, exams and
                            certificates from one place.

                        </p>

                    </div>

                </div>

                <div class="col-lg-4">

                    <div class="welcome-actions">

                        <a
                            href="<?= e(base_url('assan_computer_institute/index.php')) ?>"
                            class="btn btn-light welcome-button">

                            <i class="fa-solid fa-globe me-1"></i>

                            View Website

                        </a>

                        <a
                            href="<?= e(base_url('assan_computer_institute/index.php')) ?>"
                            class="btn btn-outline-light welcome-button">

                            <i class="fa-solid fa-right-from-bracket me-1"></i>

                            Logout

                        </a>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             STATISTICS
        ================================================== -->

        <div class="row g-4">

            <div class="col-sm-6 col-xl-3">

                <div class="dashboard-stat">

                    <div class="stat-icon icon-blue">

                        <i class="fa-solid fa-users"></i>

                    </div>

                    <div class="stat-title">
                        Total Students
                    </div>

                    <div class="stat-value">
                        <?= $students ?>
                    </div>

                    <div class="stat-description">
                        Registered student accounts
                    </div>

                </div>

            </div>


            <div class="col-sm-6 col-xl-3">

                <div class="dashboard-stat">

                    <div class="stat-icon icon-green">

                        <i class="fa-solid fa-book-open"></i>

                    </div>

                    <div class="stat-title">
                        Active Courses
                    </div>

                    <div class="stat-value">
                        <?= $courses ?>
                    </div>

                    <div class="stat-description">
                        Courses currently available
                    </div>

                </div>

            </div>


            <div class="col-sm-6 col-xl-3">

                <div class="dashboard-stat">

                    <div class="stat-icon icon-orange">

                        <i class="fa-solid fa-user-plus"></i>

                    </div>

                    <div class="stat-title">
                        Enrollments
                    </div>

                    <div class="stat-value">
                        <?= $orders ?>
                    </div>

                    <div class="stat-description">
                        Total course enrollments
                    </div>

                </div>

            </div>


            <div class="col-sm-6 col-xl-3">

                <div class="dashboard-stat">

                    <div class="stat-icon icon-purple">

                        <i class="fa-solid fa-wallet"></i>

                    </div>

                    <div class="stat-title">
                        Paid Revenue
                    </div>

                    <div class="stat-value">
                        <?= money($paid) ?>
                    </div>

                    <div class="stat-description">
                        Confirmed payments
                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             LMS MANAGEMENT
        ================================================== -->

        <div class="section-heading">

            <h4>

                <i class="fa-solid fa-graduation-cap text-primary me-2"></i>

                Learning Management

            </h4>

            <p>
                Manage your complete self-paced learning system.
            </p>

        </div>


        <div class="row g-4">

            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/courses.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#eaf0ff;color:#1f3c88;">

                        <i class="fa-solid fa-book-open"></i>

                    </div>

                    <h5>
                        Course Management
                    </h5>

                    <p>
                        Add new courses, view courses, edit details,
                        prices and course status.
                    </p>

                    <div class="management-arrow">
                        Manage Courses
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/course_videos.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#fff0f3;color:#d6336c;">

                        <i class="fa-solid fa-video"></i>

                    </div>

                    <h5>
                        Course Videos
                    </h5>

                    <p>
                        Add, update, reorder or remove videos for
                        self-paced courses.
                    </p>

                    <div class="management-arrow">
                        Manage Videos
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/students.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#eaf8ef;color:#16834b;">

                        <i class="fa-solid fa-users"></i>

                    </div>

                    <h5>
                        Students
                    </h5>

                    <p>
                        View students, enrollments, course access
                        and learning progress.
                    </p>

                    <div class="management-arrow">
                        View Students
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/exams.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#f1ecff;color:#6741c9;">

                        <i class="fa-solid fa-file-circle-check"></i>

                    </div>

                    <h5>
                        Exams & Marks
                    </h5>

                    <p>
                        Create exams, check attempts, enter marks
                        and review student results.
                    </p>

                    <div class="management-arrow">
                        Manage Exams
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/certificates.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#fff8df;color:#b96b00;">

                        <i class="fa-solid fa-certificate"></i>

                    </div>

                    <h5>
                        Certificates
                    </h5>

                    <p>
                        Issue certificates to eligible students
                        after course completion.
                    </p>

                    <div class="management-arrow">
                        Manage Certificates
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/enrollments.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#e9f7ff;color:#087ea4;">

                        <i class="fa-solid fa-user-check"></i>

                    </div>

                    <h5>
                        Enrollments
                    </h5>

                    <p>
                        Review student enrollments, payment status
                        and course access.
                    </p>

                    <div class="management-arrow">
                        View Enrollments
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/marks.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#edf8f0;color:#16834b;">

                        <i class="fa-solid fa-ranking-star"></i>

                    </div>

                    <h5>
                        Student Marks
                    </h5>

                    <p>
                        Enter, update and review marks for student
                        examinations.
                    </p>

                    <div class="management-arrow">
                        Manage Marks
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>


            <div class="col-md-6 col-xl-3">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/enrollments.php')) ?>"
                    class="management-card">

                    <div
                        class="management-icon"
                        style="background:#fff0ed;color:#c0392b;">

                        <i class="fa-solid fa-money-bill-transfer"></i>

                    </div>

                    <h5>
                        Payments
                    </h5>

                    <p>
                        Check pending payments and confirm student
                        payment transactions.
                    </p>

                    <div class="management-arrow">
                        Check Payments
                        <i class="fa-solid fa-arrow-right ms-1"></i>
                    </div>

                </a>

            </div>

        </div>


        <!-- =================================================
             SYSTEM OVERVIEW
        ================================================== -->

        <div class="section-heading">

            <h4>

                <i class="fa-solid fa-chart-simple text-primary me-2"></i>

                System Overview

            </h4>

        </div>


        <div class="row g-3 mb-4">

            <div class="col-md-6">

                <div class="summary-card">

                    <div
                        class="summary-icon"
                        style="background:#fff4df;color:#ae6800;">

                        <i class="fa-solid fa-clock"></i>

                    </div>

                    <div>

                        <span class="summary-number">
                            <?= $pending ?>
                        </span>

                        <span class="summary-label">
                            Pending Payments
                        </span>

                    </div>

                </div>

            </div>


            <div class="col-md-6">

                <div class="summary-card">

                    <div
                        class="summary-icon"
                        style="background:#eaf0ff;color:#1f3c88;">

                        <i class="fa-solid fa-unlock"></i>

                    </div>

                    <div>

                        <span class="summary-number">
                            <?= $activeAccess ?>
                        </span>

                        <span class="summary-label">
                            Active Course Access
                        </span>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             RECENT ENROLLMENTS
        ================================================== -->

        <div class="section-heading">

            <h4>

                <i class="fa-solid fa-layer-group text-primary me-2"></i>

                Recent Enrollments

            </h4>

            <p>
                Review student registrations and confirm payments.
            </p>

        </div>


        <div class="enrollment-card">

            <div class="enrollment-header">

                <div>

                    <div class="enrollment-title">
                        Enrollment Management
                    </div>

                    <div class="enrollment-subtitle">
                        Latest 100 enrollment records
                    </div>

                </div>

                <span class="record-badge">

                    <i class="fa-solid fa-list-check me-1"></i>

                    <?= count($rows) ?> Records

                </span>

            </div>


            <div class="table-responsive">

                <table class="table admin-table align-middle">

                    <thead>

                        <tr>

                            <th>Student</th>
                            <th>Course</th>
                            <th>Order</th>
                            <th>Payment Method</th>
                            <th>Amount</th>
                            <th>Payment</th>
                            <th>Payment Proof</th>
                            <th>Access</th>
                            <th>Action</th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php foreach ($rows as $r): ?>

                        <?php

                        $paymentStatus = strtolower(
                            isset($r['payment_status'])
                                ? $r['payment_status']
                                : ''
                        );

                        $accessStatus = strtolower(
                            isset($r['access_status'])
                                ? $r['access_status']
                                : ''
                        );

                        $fullName = isset($r['full_name'])
                            ? $r['full_name']
                            : 'Student';

                        $studentInitial = strtoupper(
                            substr($fullName, 0, 1)
                        );

                        $method = strtolower(
                            isset($r['payment_method'])
                                ? $r['payment_method']
                                : ''
                        );

                        $enrollmentId = isset($r['id'])
                            ? (int) $r['id']
                            : 0;

                        /*
                        |--------------------------------------------------------------------------
                        | Payment Proof
                        |--------------------------------------------------------------------------
                        */

                        $paymentProof = isset($r['payment_proof'])
                            ? trim($r['payment_proof'])
                            : '';

                        $paymentProofUrl = '';

                        if ($paymentProof !== '') {

                            $paymentProofUrl = base_url(
                                'assan_computer_institute/' .
                                ltrim($paymentProof, '/')
                            );

                        }

                        ?>

                        <tr>

                            <!-- STUDENT -->

                            <td>

                                <div class="student-info">

                                    <div class="student-avatar">
                                        <?= e($studentInitial) ?>
                                    </div>

                                    <div>

                                        <div class="student-name">
                                            <?= e($fullName) ?>
                                        </div>

                                        <div class="student-email">
                                            <?= e($r['email']) ?>
                                        </div>

                                    </div>

                                </div>

                            </td>


                            <!-- COURSE -->

                            <td>

                                <div class="course-title">
                                    <?= e($r['title']) ?>
                                </div>

                            </td>


                            <!-- ORDER -->

                            <td>

                                <span class="order-code">
                                    <?= e($r['order_ref']) ?>
                                </span>

                            </td>


                            <!-- PAYMENT METHOD -->

                            <td>

                                <?php if ($method === 'easypaisa'): ?>

                                    <i class="fa-solid fa-mobile-screen-button text-success me-1"></i>

                                <?php elseif ($method === 'jazzcash'): ?>

                                    <i class="fa-solid fa-mobile-screen-button text-danger me-1"></i>

                                <?php elseif ($method === 'bank'): ?>

                                    <i class="fa-solid fa-building-columns text-primary me-1"></i>

                                <?php else: ?>

                                    <i class="fa-solid fa-wallet text-secondary me-1"></i>

                                <?php endif; ?>

                                <small class="fw-semibold">

                                    <?= e(
                                        ucfirst(
                                            isset($r['payment_method'])
                                                ? $r['payment_method']
                                                : 'Unknown'
                                        )
                                    ) ?>

                                </small>

                            </td>


                            <!-- AMOUNT -->

                            <td>

                                <span class="amount-value">
                                    <?= money($r['amount']) ?>
                                </span>

                            </td>


                            <!-- PAYMENT STATUS -->

                            <td>

                                <?php if ($paymentStatus === 'paid'): ?>

                                    <span class="status status-paid">

                                        <span class="status-dot"></span>

                                        Paid

                                    </span>

                                <?php else: ?>

                                    <span class="status status-pending">

                                        <span class="status-dot"></span>

                                        Pending

                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- PAYMENT PROOF -->

                            <td>

                                <?php if ($paymentProofUrl !== ''): ?>

                                    <div class="payment-proof-wrapper">

                                        <img
                                            src="<?= e($paymentProofUrl) ?>"
                                            alt="Payment Proof"
                                            class="payment-proof-thumb">

                                        <img
                                            src="<?= e($paymentProofUrl) ?>"
                                            alt="Full Payment Proof"
                                            class="payment-proof-preview">

                                    </div>

                                <?php else: ?>

                                    <span class="no-payment-proof">

                                        <i class="fa-regular fa-image me-1"></i>

                                        No Proof

                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- ACCESS STATUS -->

                            <td>

                                <?php if ($accessStatus === 'active'): ?>

                                    <span class="status status-active">

                                        <span class="status-dot"></span>

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="status status-inactive">

                                        <span class="status-dot"></span>

                                        <?= e(
                                            ucfirst($accessStatus)
                                        ) ?>

                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- ACTION -->

                            <td>

                                <?php if (
                                    $paymentStatus === 'pending'
                                    && $enrollmentId > 0
                                ): ?>

                                    <form
                                        method="post"
                                        action="<?= e(
                                            base_url(
                                                'assan_computer_institute/admin/mark_paid.php'
                                            )
                                        ) ?>">

                                        <?= csrf_field() ?>

                                        <!--
                                        IMPORTANT:
                                        Send BOTH names so mark_paid.php
                                        can work whether it expects
                                        "id" or "enrollment_id".
                                        -->

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= $enrollmentId ?>">

                                        <input
                                            type="hidden"
                                            name="enrollment_id"
                                            value="<?= $enrollmentId ?>">

                                        <button
                                            type="submit"
                                            class="btn btn-success mark-paid">

                                            <i class="fa-solid fa-check me-1"></i>

                                            Mark Paid

                                        </button>

                                    </form>

                                <?php elseif (
                                    $paymentStatus === 'pending'
                                    && $enrollmentId <= 0
                                ): ?>

                                    <span class="text-danger small fw-bold">

                                        Invalid ID

                                    </span>

                                <?php else: ?>

                                    <span class="completed">

                                        <i class="fa-solid fa-circle-check text-success me-1"></i>

                                        Completed

                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>


                    <?php if (!$rows): ?>

                        <tr>

                            <td colspan="9">

                                <div class="empty-state">

                                    <div class="empty-icon">

                                        <i class="fa-solid fa-inbox"></i>

                                    </div>

                                    <h5>
                                        No Enrollments Yet
                                    </h5>

                                    <p>
                                        Enrollment records will appear here
                                        when students register for courses.
                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>


<!-- Bootstrap JS -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>
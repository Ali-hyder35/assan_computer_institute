<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Add New Course';

$message = '';
$messageType = '';

$title = '';
$slug = '';
$description = '';
$price = '';
$duration = '';
$active = 1;


/*
|--------------------------------------------------------------------------
| Generate Slug
|--------------------------------------------------------------------------
*/
function generate_course_slug($text)
{
    $text = strtolower(trim($text));

    $text = preg_replace('/[^a-z0-9]+/', '-', $text);

    $text = trim($text, '-');

    return $text;
}


/*
|--------------------------------------------------------------------------
| Add Course
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $title = isset($_POST['title'])
            ? trim($_POST['title'])
            : '';

        $slug = isset($_POST['slug'])
            ? trim($_POST['slug'])
            : '';

        $description = isset($_POST['description'])
            ? trim($_POST['description'])
            : '';

        $price = isset($_POST['price'])
            ? trim($_POST['price'])
            : '';

        $duration = isset($_POST['duration'])
            ? trim($_POST['duration'])
            : '';

        $active = isset($_POST['active'])
            ? 1
            : 0;


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {
            throw new Exception('Course title is required.');
        }

        if (strlen($title) > 180) {
            throw new Exception('Course title cannot exceed 180 characters.');
        }

        if ($slug === '') {
            $slug = generate_course_slug($title);
        } else {
            $slug = generate_course_slug($slug);
        }

        if ($slug === '') {
            throw new Exception('Unable to generate a valid course slug.');
        }

        if (strlen($slug) > 190) {
            throw new Exception('Course slug cannot exceed 190 characters.');
        }

        if ($price === '' || !is_numeric($price)) {
            throw new Exception('Please enter a valid course price.');
        }

        $priceValue = (float) $price;

        if ($priceValue < 0) {
            throw new Exception('Course price cannot be negative.');
        }


        /*
        |--------------------------------------------------------------------------
        | Check Duplicate Slug
        |--------------------------------------------------------------------------
        */

        $check = $pdo->prepare("
            SELECT id
            FROM courses
            WHERE slug = ?
            LIMIT 1
        ");

        $check->execute(array($slug));

        if ($check->fetch()) {
            throw new Exception(
                'This course slug already exists. Please use another slug.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Insert Course
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            INSERT INTO courses
            (
                title,
                slug,
                description,
                price,
                duration,
                active
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ");

        $stmt->execute(array(
            $title,
            $slug,
            $description !== '' ? $description : null,
            $priceValue,
            $duration !== '' ? $duration : null,
            $active
        ));


        /*
        |--------------------------------------------------------------------------
        | Redirect
        |--------------------------------------------------------------------------
        */

        header(
            'Location: ' .
            base_url('assan_computer_institute/admin/courses.php?success=course_added')
        );

        exit;


    } catch (Exception $e) {

        $message = $e->getMessage();

        $messageType = 'danger';
    }
}

?>


<style>

/* =========================================================
   ASSAN LMS - ADD COURSE
   ========================================================= */

.acip-form-page {

    --primary: #0f2a5f;
    --primary-2: #1e4b8f;
    --blue: #2563eb;
    --blue-dark: #1d4ed8;

    --bg: #f5f7fb;
    --white: #ffffff;

    --text: #172033;
    --muted: #64748b;
    --border: #e2e8f0;

    width: 100%;
    color: var(--text);
}

.acip-form-container {

    width: 100%;
    max-width: 1000px;

    margin: 0 auto;

    padding: 28px 24px 40px;
}


/* Header */

.acip-form-header {

    padding: 25px 27px;

    margin-bottom: 22px;

    border-radius: 16px;

    background:
        linear-gradient(
            135deg,
            #0f2a5f,
            #173d7a,
            #2563eb
        );

    box-shadow:
        0 8px 25px rgba(15,42,95,.12);

    color: #fff;
}

.acip-form-header-inner {

    display: flex;

    align-items: center;

    gap: 15px;
}

.acip-form-header-icon {

    width: 50px;
    height: 50px;

    flex: 0 0 50px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: rgba(255,255,255,.12);

    border: 1px solid rgba(255,255,255,.15);

    font-size: 20px;
}

.acip-form-header h1 {

    margin: 0;

    font-size: 24px;

    font-weight: 700;
}

.acip-form-header p {

    margin: 5px 0 0;

    color: #dbeafe;

    font-size: 13px;
}


/* Alert */

.acip-form-alert {

    display: flex;

    gap: 10px;

    align-items: center;

    padding: 12px 15px;

    margin-bottom: 20px;

    border-radius: 10px;

    font-size: 13px;
}

.acip-form-alert-danger {

    color: #991b1b;

    background: #fef2f2;

    border: 1px solid #fecaca;
}


/* Card */

.acip-form-card {

    background: #fff;

    border: 1px solid var(--border);

    border-radius: 15px;

    box-shadow:
        0 5px 20px rgba(15,42,95,.06);

    overflow: hidden;
}

.acip-form-card-header {

    padding: 18px 22px;

    border-bottom: 1px solid var(--border);

    background: #f8fafc;
}

.acip-form-card-header h2 {

    margin: 0;

    color: var(--primary);

    font-size: 16px;

    font-weight: 700;
}

.acip-form-card-body {

    padding: 25px;
}


/* Form */

.acip-form-group {

    margin-bottom: 20px;
}

.acip-form-group label {

    display: block;

    margin-bottom: 7px;

    color: var(--text);

    font-size: 12px;

    font-weight: 600;
}

.acip-form-group label span {

    color: #dc2626;
}

.acip-form-control {

    width: 100%;

    min-height: 43px;

    padding: 10px 12px;

    border: 1px solid #cbd5e1;

    border-radius: 8px;

    background: #fff;

    color: var(--text);

    font-family: inherit;

    font-size: 13px;

    outline: none;

    transition:
        border-color .2s ease,
        box-shadow .2s ease;
}

.acip-form-control:focus {

    border-color: var(--blue);

    box-shadow:
        0 0 0 3px rgba(37,99,235,.10);
}

textarea.acip-form-control {

    min-height: 150px;

    resize: vertical;

    line-height: 1.6;
}


/* Grid */

.acip-form-row {

    display: grid;

    grid-template-columns:
        repeat(2, minmax(0,1fr));

    gap: 18px;
}


/* Checkbox */

.acip-checkbox {

    display: flex;

    align-items: center;

    gap: 9px;

    margin-top: 5px;

    color: var(--muted);

    font-size: 13px;
}

.acip-checkbox input {

    width: 17px;
    height: 17px;

    accent-color: var(--blue);
}


/* Actions */

.acip-form-actions {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 12px;

    margin-top: 10px;

    padding-top: 20px;

    border-top: 1px solid var(--border);
}

.acip-btn {

    min-height: 41px;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    padding: 9px 16px;

    border-radius: 8px;

    font-size: 12px;

    font-weight: 600;

    text-decoration: none;

    cursor: pointer;

    transition: all .2s ease;
}

.acip-btn-primary {

    border: 1px solid var(--blue);

    background: var(--blue);

    color: #fff;
}

.acip-btn-primary:hover {

    background: var(--blue-dark);

    border-color: var(--blue-dark);

    color: #fff;
}

.acip-btn-secondary {

    border: 1px solid #cbd5e1;

    background: #fff;

    color: #475569;
}

.acip-btn-secondary:hover {

    background: #f8fafc;

    color: var(--primary);
}


/* Mobile */

@media (max-width: 767px) {

    .acip-form-container {

        padding: 18px 15px 30px;
    }

    .acip-form-header {

        padding: 20px;
    }

    .acip-form-header h1 {

        font-size: 20px;
    }

    .acip-form-row {

        grid-template-columns: 1fr;

        gap: 0;
    }

    .acip-form-card-body {

        padding: 18px;
    }

    .acip-form-actions {

        flex-direction: column-reverse;

        align-items: stretch;
    }

    .acip-btn {

        width: 100%;
    }
}

</style>


<div class="acip-form-page">

    <div class="acip-form-container">


        <!-- Header -->

        <div class="acip-form-header">

            <div class="acip-form-header-inner">

                <div class="acip-form-header-icon">

                    <i class="fa-solid fa-plus"></i>

                </div>

                <div>

                    <h1>Add New Course</h1>

                    <p>
                        Create a new course for your learning management system.
                    </p>

                </div>

            </div>

        </div>


        <!-- Error -->

        <?php if ($message !== ''): ?>

            <div class="acip-form-alert acip-form-alert-danger">

                <i class="fa-solid fa-circle-exclamation"></i>

                <span>
                    <?php echo e($message); ?>
                </span>

            </div>

        <?php endif; ?>


        <!-- Form Card -->

        <div class="acip-form-card">

            <div class="acip-form-card-header">

                <h2>
                    <i class="fa-solid fa-book"></i>
                    Course Information
                </h2>

            </div>


            <div class="acip-form-card-body">

                <form method="post">

                    <?php echo csrf_field(); ?>


                    <!-- Course Title -->

                    <div class="acip-form-group">

                        <label>
                            Course Title <span>*</span>
                        </label>

                        <input
                            type="text"
                            name="title"
                            class="acip-form-control"
                            value="<?php echo e($title); ?>"
                            maxlength="180"
                            required
                            placeholder="e.g. Web Development"
                        >

                    </div>


                    <!-- Slug -->

                    <div class="acip-form-group">

                        <label>
                            Course Slug
                        </label>

                        <input
                            type="text"
                            name="slug"
                            class="acip-form-control"
                            value="<?php echo e($slug); ?>"
                            maxlength="190"
                            placeholder="web-development"
                        >

                    </div>


                    <!-- Price / Duration -->

                    <div class="acip-form-row">

                        <div class="acip-form-group">

                            <label>
                                Course Fee <span>*</span>
                            </label>

                            <input
                                type="number"
                                name="price"
                                class="acip-form-control"
                                value="<?php echo e($price); ?>"
                                min="0"
                                step="0.01"
                                required
                                placeholder="18000"
                            >

                        </div>


                        <div class="acip-form-group">

                            <label>
                                Duration
                            </label>

                            <input
                                type="text"
                                name="duration"
                                class="acip-form-control"
                                value="<?php echo e($duration); ?>"
                                maxlength="80"
                                placeholder="e.g. 3 Months"
                            >

                        </div>

                    </div>


                    <!-- Description -->

                    <div class="acip-form-group">

                        <label>
                            Course Description
                        </label>

                        <textarea
                            name="description"
                            class="acip-form-control"
                            placeholder="Write a professional description of the course..."
                        ><?php echo e($description); ?></textarea>

                    </div>


                    <!-- Status -->

                    <div class="acip-form-group">

                        <label class="acip-checkbox">

                            <input
                                type="checkbox"
                                name="active"
                                value="1"
                                <?php echo $active === 1 ? 'checked' : ''; ?>
                            >

                            <span>
                                Make this course active immediately
                            </span>

                        </label>

                    </div>


                    <!-- Actions -->

                    <div class="acip-form-actions">

                        <a
                            href="<?php echo e(base_url('assan_computer_institute/admin/courses.php')); ?>"
                            class="acip-btn acip-btn-secondary"
                        >

                            <i class="fa-solid fa-arrow-left"></i>

                            Back to Courses

                        </a>


                        <button
                            type="submit"
                            class="acip-btn acip-btn-primary"
                        >

                            <i class="fa-solid fa-plus"></i>

                            Create Course

                        </button>

                    </div>


                </form>

            </div>

        </div>


    </div>

</div>


<?php include dirname(__DIR__) . '/partials/footer.php'; ?>



<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Course Videos';

$courseId = isset($_GET['course_id'])
    ? (int) $_GET['course_id']
    : 0;

$course = null;
$courses = array();
$videos = array();
$totalVideos = 0;
$activeVideos = 0;
$courseError = '';

/*
|--------------------------------------------------------------------------
| Load Courses
|--------------------------------------------------------------------------
| Opening this page without course_id shows the course selection screen.
*/

if ($courseId <= 0) {

    $coursesStmt = $pdo->query("
        SELECT
            c.id,
            c.title,
            c.slug,
            c.duration,
            c.price,
            c.active,
            (
                SELECT COUNT(*)
                FROM course_videos cv
                WHERE cv.course_id = c.id
            ) AS video_count,
            (
                SELECT COUNT(*)
                FROM course_videos cv
                WHERE cv.course_id = c.id
                  AND cv.active = 1
            ) AS active_video_count
        FROM courses c
        ORDER BY c.title ASC
    ");

    $courses = $coursesStmt->fetchAll();

} else {

    /*
    |--------------------------------------------------------------------------
    | Get Selected Course
    |--------------------------------------------------------------------------
    */

    $courseStmt = $pdo->prepare("
        SELECT id, title, slug, duration, price, active
        FROM courses
        WHERE id = ?
        LIMIT 1
    ");

    $courseStmt->execute(array($courseId));
    $course = $courseStmt->fetch();

    if (!$course) {

        $courseError = 'The selected course does not exist. Please choose a valid course.';

        // Load courses so the administrator can select another course.
        $coursesStmt = $pdo->query("
            SELECT
                c.id,
                c.title,
                c.slug,
                c.duration,
                c.price,
                c.active,
                (
                    SELECT COUNT(*)
                    FROM course_videos cv
                    WHERE cv.course_id = c.id
                ) AS video_count,
                (
                    SELECT COUNT(*)
                    FROM course_videos cv
                    WHERE cv.course_id = c.id
                      AND cv.active = 1
                ) AS active_video_count
            FROM courses c
            ORDER BY c.title ASC
        ");

        $courses = $coursesStmt->fetchAll();

    } else {

        /*
        |--------------------------------------------------------------------------
        | Get Videos For Selected Course
        |--------------------------------------------------------------------------
        */

        $videoStmt = $pdo->prepare("
            SELECT
                id,
                course_id,
                title,
                description,
                video_url,
                lesson_no,
                duration,
                active,
                created_at,
                updated_at
            FROM course_videos
            WHERE course_id = ?
            ORDER BY lesson_no ASC, id ASC
        ");

        $videoStmt->execute(array($courseId));
        $videos = $videoStmt->fetchAll();

        $totalVideos = count($videos);

        foreach ($videos as $video) {
            if ((int) $video['active'] === 1) {
                $activeVideos++;
            }
        }
    }
}

include dirname(__DIR__) . '/partials/header.php';
?>

<style>
    .acip-video-page {
        background: #f5f7fb;
        min-height: calc(100vh - 80px);
        padding: 30px 0 50px;
    }

    .acip-page-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        border-radius: 18px;
        padding: 28px 30px;
        color: #fff;
        margin-bottom: 25px;
        box-shadow: 0 10px 30px rgba(15, 42, 95, 0.12);
    }

    .acip-page-header h2 {
        margin: 0;
        font-size: 25px;
        font-weight: 700;
    }

    .acip-page-header p {
        margin: 7px 0 0;
        color: rgba(255,255,255,.78);
    }

    .acip-header-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .acip-btn {
        border: 0;
        border-radius: 10px;
        padding: 10px 16px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        transition: .2s ease;
    }

    .acip-btn:hover {
        transform: translateY(-1px);
    }

    .acip-btn-light {
        background: #fff;
        color: #0f2a5f;
    }

    .acip-btn-light:hover {
        background: #eff6ff;
        color: #0f2a5f;
    }

    .acip-btn-primary {
        background: #2563eb;
        color: #fff;
    }

    .acip-btn-primary:hover {
        background: #1d4ed8;
        color: #fff;
    }

    .acip-course-summary {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 20px;
        margin-bottom: 25px;
        box-shadow: 0 5px 20px rgba(15,42,95,.05);
    }

    .acip-course-summary-title {
        font-size: 18px;
        font-weight: 700;
        color: #0f2a5f;
        margin-bottom: 5px;
    }

    .acip-course-summary-meta {
        color: #64748b;
        font-size: 14px;
    }

    .acip-stat {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 12px 16px;
        min-width: 120px;
        text-align: center;
    }

    .acip-stat strong {
        display: block;
        color: #0f2a5f;
        font-size: 20px;
    }

    .acip-stat span {
        color: #64748b;
        font-size: 12px;
    }

    .acip-video-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        margin-bottom: 15px;
        padding: 20px;
        box-shadow: 0 5px 18px rgba(15,42,95,.05);
        transition: .2s ease;
    }

    .acip-video-card:hover {
        border-color: #bfdbfe;
        box-shadow: 0 8px 25px rgba(15,42,95,.08);
    }

    .acip-lesson-number {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: #eff6ff;
        color: #2563eb;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 17px;
        flex-shrink: 0;
    }

    .acip-video-title {
        color: #0f2a5f;
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 5px;
    }

    .acip-video-description {
        color: #64748b;
        font-size: 13px;
        margin-bottom: 8px;
    }

    .acip-video-url {
        color: #64748b;
        font-size: 12px;
        word-break: break-all;
        max-width: 650px;
    }

    .acip-video-url i {
        color: #2563eb;
    }

    .acip-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 9px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .acip-badge-active {
        background: #dcfce7;
        color: #166534;
    }

    .acip-badge-inactive {
        background: #f1f5f9;
        color: #64748b;
    }

    .acip-duration {
        color: #64748b;
        font-size: 12px;
    }

    .acip-actions {
        display: flex;
        align-items: center;
        gap: 7px;
        flex-wrap: wrap;
    }

    .acip-action {
        border: 0;
        border-radius: 8px;
        padding: 8px 11px;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
    }

    .acip-edit {
        background: #eff6ff;
        color: #1d4ed8;
    }

    .acip-toggle {
        background: #f0fdf4;
        color: #15803d;
    }

    .acip-toggle-off {
        background: #fff7ed;
        color: #c2410c;
    }

    .acip-delete {
        background: #fef2f2;
        color: #dc2626;
    }

    .acip-empty {
        background: #fff;
        border: 1px dashed #cbd5e1;
        border-radius: 18px;
        padding: 55px 25px;
        text-align: center;
    }

    .acip-empty-icon {
        width: 70px;
        height: 70px;
        margin: 0 auto 15px;
        border-radius: 18px;
        background: #eff6ff;
        color: #2563eb;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
    }

    .acip-empty h4 {
        color: #0f2a5f;
        font-weight: 700;
    }

    .acip-empty p {
        color: #64748b;
    }

    /* Course selection screen */

    .acip-selection-intro {
        margin-bottom: 22px;
    }

    .acip-selection-intro h3 {
        color: #0f2a5f;
        font-size: 21px;
        font-weight: 750;
        margin-bottom: 6px;
    }

    .acip-selection-intro p {
        color: #64748b;
        margin-bottom: 0;
    }

    .acip-course-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 20px;
    }

    .acip-course-card {
        display: flex;
        flex-direction: column;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 22px;
        min-width: 0;
        box-shadow: 0 5px 20px rgba(15,42,95,.04);
        transition: .2s ease;
    }

    .acip-course-card:hover {
        transform: translateY(-3px);
        border-color: #bfdbfe;
        box-shadow: 0 12px 28px rgba(15,42,95,.09);
    }

    .acip-course-icon {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 13px;
        background: #eff6ff;
        color: #2563eb;
        font-size: 21px;
        margin-bottom: 17px;
    }

    .acip-course-card h4 {
        color: #0f2a5f;
        font-size: 17px;
        font-weight: 750;
        line-height: 1.45;
        margin-bottom: 10px;
        overflow-wrap: anywhere;
    }

    .acip-course-meta {
        color: #64748b;
        font-size: 13px;
        display: flex;
        flex-wrap: wrap;
        gap: 8px 14px;
        margin-bottom: 16px;
    }

    .acip-course-counts {
        display: flex;
        gap: 10px;
        margin-top: auto;
        margin-bottom: 18px;
    }

    .acip-course-count {
        flex: 1;
        padding: 11px 8px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        text-align: center;
    }

    .acip-course-count strong {
        display: block;
        font-size: 20px;
        color: #0f2a5f;
    }

    .acip-course-count span {
        color: #64748b;
        font-size: 11px;
    }

    .acip-course-open {
        width: 100%;
    }

    .acip-alert {
        padding: 14px 17px;
        border-radius: 12px;
        margin-bottom: 22px;
    }

    @media (max-width: 991px) {
        .acip-course-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 767px) {
        .acip-page-header {
            padding: 22px;
        }

        .acip-header-actions {
            margin-top: 18px;
        }

        .acip-video-card {
            padding: 16px;
        }

        .acip-actions {
            margin-top: 15px;
        }

        .acip-course-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="acip-video-page">
    <div class="container">

        <?php if (!$course || $courseId <= 0): ?>

            <!-- Course Selection Screen -->

            <div class="acip-page-header">
                <div class="row align-items-center g-3">
                    <div class="col-lg-8">
                        <h2>
                            <i class="fa-solid fa-circle-play me-2"></i>
                            Course Video Management
                        </h2>

                        <p>
                            Select a course to view and manage its lessons,
                            videos, and lesson availability.
                        </p>
                    </div>

                    <div class="col-lg-4">
                        <div class="acip-header-actions justify-content-lg-end">
                            <a href="<?= e(base_url('assan_computer_institute/admin/courses.php')) ?>"
                               class="acip-btn acip-btn-light">
                                <i class="fa-solid fa-arrow-left"></i>
                                Back to Courses
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($courseError !== ''): ?>
                <div class="alert alert-warning acip-alert" role="alert">
                    <i class="fa-solid fa-circle-exclamation me-2"></i>
                    <?= e($courseError) ?>
                </div>
            <?php endif; ?>

            <div class="acip-selection-intro">
                <h3>Select a Course</h3>
                <p>
                    Choose the course whose video lessons you want to manage.
                </p>
            </div>

            <?php if (empty($courses)): ?>

                <div class="acip-empty">
                    <div class="acip-empty-icon">
                        <i class="fa-solid fa-book-open"></i>
                    </div>

                    <h4>No Courses Found</h4>

                    <p class="mb-4">
                        Add a course before managing its video lessons.
                    </p>

                    <a href="<?= e(base_url('assan_computer_institute/admin/courses.php')) ?>"
                       class="acip-btn acip-btn-primary">
                        <i class="fa-solid fa-book"></i>
                        View Courses
                    </a>
                </div>

            <?php else: ?>

                <div class="acip-course-grid">

                    <?php foreach ($courses as $item): ?>

                        <div class="acip-course-card">

                            <div class="acip-course-icon">
                                <i class="fa-solid fa-graduation-cap"></i>
                            </div>

                            <h4><?= e($item['title']) ?></h4>

                            <div class="acip-course-meta">
                                <span>
                                    <i class="fa-solid fa-clock me-1"></i>
                                    <?= e($item['duration'] ?: 'Duration not specified') ?>
                                </span>

                                <span>
                                    <i class="fa-solid fa-tag me-1"></i>
                                    <?= money($item['price']) ?>
                                </span>
                            </div>

                            <div class="mb-3">
                                <?php if ((int) $item['active'] === 1): ?>
                                    <span class="acip-badge acip-badge-active">
                                        <i class="fa-solid fa-circle-check"></i>
                                        Course Active
                                    </span>
                                <?php else: ?>
                                    <span class="acip-badge acip-badge-inactive">
                                        <i class="fa-solid fa-circle-pause"></i>
                                        Course Inactive
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="acip-course-counts">
                                <div class="acip-course-count">
                                    <strong><?= (int) $item['video_count'] ?></strong>
                                    <span>Total Lessons</span>
                                </div>

                                <div class="acip-course-count">
                                    <strong><?= (int) $item['active_video_count'] ?></strong>
                                    <span>Active Lessons</span>
                                </div>
                            </div>

                            <a href="<?= e(base_url(
                                'assan_computer_institute/admin/course_videos.php?course_id=' .
                                (int) $item['id']
                            )) ?>"
                               class="acip-btn acip-btn-primary acip-course-open">
                                <i class="fa-solid fa-video"></i>
                                Manage Videos
                                <i class="fa-solid fa-arrow-right ms-auto"></i>
                            </a>

                        </div>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        <?php else: ?>

            <!-- Selected Course: Existing Video Management -->

            <div class="acip-page-header">
                <div class="row align-items-center g-3">
                    <div class="col-lg-8">
                        <h2>
                            <i class="fa-solid fa-circle-play me-2"></i>
                            Course Video Management
                        </h2>

                        <p>
                            Manage lessons and video content for
                            <strong><?= e($course['title']) ?></strong>
                        </p>
                    </div>

                    <div class="col-lg-4">
                        <div class="acip-header-actions justify-content-lg-end">

                            <a href="<?= e(base_url('assan_computer_institute/admin/course_videos.php')) ?>"
                               class="acip-btn acip-btn-light">
                                <i class="fa-solid fa-arrow-left"></i>
                                All Courses
                            </a>

                            <a href="<?= e(base_url(
                                'assan_computer_institute/admin/course_video_add.php?course_id=' .
                                $courseId
                            )) ?>"
                               class="acip-btn acip-btn-primary">
                                <i class="fa-solid fa-plus"></i>
                                Add Lesson
                            </a>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Course Summary -->

            <div class="acip-course-summary">
                <div class="row align-items-center g-3">

                    <div class="col-lg-7">
                        <div class="acip-course-summary-title">
                            <?= e($course['title']) ?>
                        </div>

                        <div class="acip-course-summary-meta">
                            <i class="fa-solid fa-clock me-1"></i>
                            <?= e($course['duration'] ?: 'Duration not specified') ?>

                            <span class="mx-2">•</span>

                            <i class="fa-solid fa-tag me-1"></i>
                            <?= money($course['price']) ?>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <div class="d-flex justify-content-lg-end gap-2 flex-wrap">

                            <div class="acip-stat">
                                <strong><?= $totalVideos ?></strong>
                                <span>Total Lessons</span>
                            </div>

                            <div class="acip-stat">
                                <strong><?= $activeVideos ?></strong>
                                <span>Active Lessons</span>
                            </div>

                            <div class="acip-stat">
                                <strong><?= $totalVideos - $activeVideos ?></strong>
                                <span>Inactive</span>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <!-- Videos -->

            <?php if (!$videos): ?>

                <div class="acip-empty">
                    <div class="acip-empty-icon">
                        <i class="fa-solid fa-video"></i>
                    </div>

                    <h4>No Lessons Added Yet</h4>

                    <p class="mb-4">
                        Start building this course by adding your first lesson or video.
                    </p>

                    <a href="<?= e(base_url(
                        'assan_computer_institute/admin/course_video_add.php?course_id=' .
                        $courseId
                    )) ?>"
                       class="acip-btn acip-btn-primary">
                        <i class="fa-solid fa-plus"></i>
                        Add First Lesson
                    </a>
                </div>

            <?php else: ?>

                <?php foreach ($videos as $video): ?>

                    <div class="acip-video-card">
                        <div class="row align-items-center g-3">

                            <div class="col-auto">
                                <div class="acip-lesson-number">
                                    <?= (int) $video['lesson_no'] ?>
                                </div>
                            </div>

                            <div class="col">
                                <div class="acip-video-title">
                                    Lesson <?= (int) $video['lesson_no'] ?>:
                                    <?= e($video['title']) ?>
                                </div>

                                <?php if (!empty($video['description'])): ?>
                                    <div class="acip-video-description">
                                        <?= e($video['description']) ?>
                                    </div>
                                <?php endif; ?>

                                <div class="acip-video-url">
                                    <i class="fa-solid fa-link me-1"></i>
                                    <?= e($video['video_url']) ?>
                                </div>

                                <div class="mt-2 d-flex align-items-center gap-2 flex-wrap">

                                    <?php if ((int) $video['active'] === 1): ?>
                                        <span class="acip-badge acip-badge-active">
                                            <i class="fa-solid fa-circle-check"></i>
                                            Active
                                        </span>
                                    <?php else: ?>
                                        <span class="acip-badge acip-badge-inactive">
                                            <i class="fa-solid fa-circle-pause"></i>
                                            Inactive
                                        </span>
                                    <?php endif; ?>

                                    <?php if (!empty($video['duration'])): ?>
                                        <span class="acip-duration">
                                            <i class="fa-regular fa-clock me-1"></i>
                                            <?= e($video['duration']) ?>
                                        </span>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="col-lg-auto">
                                <div class="acip-actions">

                                    <a href="<?= e(base_url(
                                        'assan_computer_institute/admin/course_video_edit.php?id=' .
                                        (int) $video['id'] .
                                        '&course_id=' .
                                        $courseId
                                    )) ?>"
                                       class="acip-action acip-edit">
                                        <i class="fa-solid fa-pen"></i>
                                        Edit
                                    </a>

                                    <form method="post"
                                          action="<?= e(base_url('assan_computer_institute/admin/course_video_toggle.php')) ?>"
                                          class="d-inline">

                                        <?= csrf_field() ?>

                                        <input type="hidden"
                                               name="id"
                                               value="<?= (int) $video['id'] ?>">

                                        <input type="hidden"
                                               name="course_id"
                                               value="<?= $courseId ?>">

                                        <button type="submit"
                                                class="acip-action <?= (int) $video['active'] === 1 ? 'acip-toggle-off' : 'acip-toggle' ?>">

                                            <?php if ((int) $video['active'] === 1): ?>
                                                <i class="fa-solid fa-pause"></i>
                                                Disable
                                            <?php else: ?>
                                                <i class="fa-solid fa-play"></i>
                                                Activate
                                            <?php endif; ?>

                                        </button>
                                    </form>

                                    <a href="<?= e(base_url(
                                        'assan_computer_institute/admin/course_video_delete.php?id=' .
                                        (int) $video['id'] .
                                        '&course_id=' .
                                        $courseId
                                    )) ?>"
                                       class="acip-action acip-delete"
                                       onclick="return confirm('Are you sure you want to delete this lesson?');">
                                        <i class="fa-solid fa-trash"></i>
                                        Delete
                                    </a>

                                </div>
                            </div>

                        </div>
                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        <?php endif; ?>

    </div>
</div>

<?php include dirname(__DIR__) . '/partials/footer.php'; ?>

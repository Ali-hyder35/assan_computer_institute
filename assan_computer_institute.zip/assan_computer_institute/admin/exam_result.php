<?php /* |-------------------------------------------------------------------------- | Assan Computer Institute | Admin - Student Exam Result Details |-------------------------------------------------------------------------- */ require_once dirname(__DIR__) . '/config/bootstrap.php';
require_admin();
$attemptId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($attemptId <= 0) {
    flash('error', 'Invalid exam result selected.');
    redirect(base_url('assan_computer_institute/admin/exam_results.php'));
} /* |-------------------------------------------------------------------------- | Load Attempt |-------------------------------------------------------------------------- */
$stmt = $pdo->prepare(" SELECT ea.*, e.title AS exam_title, e.description AS exam_description, e.duration_minutes, e.pass_marks, c.title AS course_title, u.id AS student_id, u.full_name, u.email, u.mobile FROM exam_attempts ea INNER JOIN exams e ON e.id = ea.exam_id INNER JOIN courses c ON c.id = e.course_id INNER JOIN users u ON u.id = ea.user_id WHERE ea.id = ? LIMIT 1 ");
$stmt->execute(array($attemptId));
$attempt = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$attempt) {
    flash('error', 'Exam result not found.');
    redirect(base_url('assan_computer_institute/admin/exam_results.php'));
} /* |-------------------------------------------------------------------------- | Load Answers |-------------------------------------------------------------------------- */
$stmt = $pdo->prepare(" SELECT ea.*, eq.question_text, eq.option_a, eq.option_b, eq.option_c, eq.option_d, eq.correct_option, eq.marks, eq.question_order FROM exam_answers ea INNER JOIN exam_questions eq ON eq.id = ea.question_id WHERE ea.attempt_id = ? ORDER BY eq.question_order ASC, eq.id ASC ");
$stmt->execute(array($attemptId));
$answers = $stmt->fetchAll(PDO::FETCH_ASSOC);
$totalQuestions = count($answers);
$correctCount = 0;
$wrongCount = 0;
$unansweredCount = 0;
foreach ($answers as $answer) {
    if (empty($answer['selected_option'])) {
        $unansweredCount++;
    }
    elseif ((int) $answer['is_correct'] === 1) {
        $correctCount++;
    }
    else {
        $wrongCount++;
    }
}
$pageTitle = 'Result - ' . $attempt['full_name'];
require_once dirname(__DIR__) . '/partials/header.php'; ?>
<style>
    body {
        background: #f5f7fb;
    }

    .result-page {
        padding: 30px 0 60px;
    }

    .page-header {
        background: linear-gradient(135deg, #0f2a5f, #1e4b8f);
        color: #fff;
        border-radius: 18px;
        padding: 28px;
        margin-bottom: 25px;
    }

    .student-card,
    .result-card,
    .review-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 23px;
        box-shadow: 0 8px 25px rgba(15, 42, 95, .08);
        margin-bottom: 20px;
    }

    .student-name {
        font-size: 21px;
        font-weight: 700;
        color: #1e293b;
    }

    .student-detail {
        color: #64748b;
        font-size: 13px;
        margin-top: 4px;
    }

    .score-box {
        text-align: center;
    }

    .score-number {
        font-size: 38px;
        font-weight: 800;
        color: #2563eb;
    }

    .result-badge {
        display: inline-block;
        padding: 7px 14px;
        border-radius: 20px;
        font-weight: 800;
        font-size: 12px;
    }

    .passed {
        background: #dcfce7;
        color: #166534;
    }

    .failed {
        background: #fee2e2;
        color: #991b1b;
    }

    .review-question {
        font-size: 16px;
        font-weight: 700;
        color: #1e293b;
        line-height: 1.6;
    }

    .answer-line {
        padding: 10px 13px;
        border-radius: 8px;
        margin-top: 8px;
    }

    .correct-line {
        background: #f0fdf4;
        color: #166534;
    }

    .wrong-line {
        background: #fef2f2;
        color: #991b1b;
    }

    .neutral-line {
        background: #f8fafc;
        color: #475569;
    }
</style>
<div class="container result-page">
    <div class="page-header">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h2 class="mb-1"> <i class="bi bi-person-check me-2"></i> Student Exam Result </h2>
                <p class="mb-0 text-white-50"> Detailed marks and answer analysis. </p>
            </div>
            <div> <a href="<?= e(base_url('assan_computer_institute/admin/exam_results.php')) ?>" class="btn btn-light">
                    <i class="bi bi-arrow-left me-1"></i> All Results </a> </div>
        </div>
    </div> <!-- STUDENT INFORMATION -->
    <div class="student-card">
        <div class="row align-items-center">
            <div class="col-md-8">
                <div class="student-name"> <?= e($attempt['full_name']) ?> </div>
                <div class="student-detail"> <i class="bi bi-envelope me-1"></i> <?= e($attempt['email']) ?> </div>
                <?php if (!empty($attempt['mobile'])): ?>
                    <div class="student-detail"> <i class="bi bi-phone me-1"></i> <?= e($attempt['mobile']) ?> </div>
                <?php endif; ?>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <div class="score-box">
                    <div class="score-number"> <?= number_format((float) $attempt['percentage'], 1) ?>% </div>

                    <?php
                    $resultStatus = strtolower(trim((string) $attempt['result']));
                    $attemptStatus = strtolower(trim((string) $attempt['status']));

                    if ($resultStatus === 'passed') {
                        $resultLabel = 'PASSED';
                        $resultClass = 'passed';
                    }
                    elseif ($resultStatus === 'failed') {
                        $resultLabel = 'FAILED';
                        $resultClass = 'failed';
                    }
                    else {
                        $resultLabel = 'PENDING';
                        $resultClass = 'neutral-line';
                    }
                    ?>

                    <span class="result-badge <?= e($resultClass) ?>">
                        <?= e($resultLabel) ?>
                    </span>


                </div>
            </div>
        </div>
    </div> <!-- EXAM SUMMARY -->
    <div class="result-card">
        <div class="row g-4">
            <div class="col-md-3"> <small class="text-muted"> Exam </small>
                <div class="fw-bold"> <?= e($attempt['exam_title']) ?> </div>
            </div>
            <div class="col-md-3"> <small class="text-muted"> Course </small>
                <div class="fw-bold"> <?= e($attempt['course_title']) ?> </div>
            </div>
            <div class="col-md-2"> <small class="text-muted"> Marks </small>
                <div class="fw-bold"> <?= e($attempt['score']) ?> / <?= e($attempt['total_marks']) ?> </div>
            </div>
            <div class="col-md-2"> <small class="text-muted"> Pass Marks </small>
                <div class="fw-bold"> <?= e($attempt['pass_marks']) ?> </div>
            </div>
            <div class="col-md-2"> <small class="text-muted"> Submitted </small>
                <div class="fw-bold small">
                    <?= e($attempt['submitted_at'] ? $attempt['submitted_at'] : $attempt['started_at']) ?>
                </div>
            </div>
        </div>
        <hr>
        <div class="row g-3">
            <div class="col-md-3">
                <div class="text-center">
                    <div class="fs-3 fw-bold text-primary"> <?= $totalQuestions ?> </div> <small class="text-muted">
                        Questions </small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <div class="fs-3 fw-bold text-success"> <?= $correctCount ?> </div> <small class="text-muted">
                        Correct </small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <div class="fs-3 fw-bold text-danger"> <?= $wrongCount ?> </div> <small class="text-muted"> Wrong
                    </small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <div class="fs-3 fw-bold text-warning"> <?= $unansweredCount ?> </div> <small class="text-muted">
                        Unanswered </small>
                </div>
            </div>
        </div>
    </div> <!-- ANSWER REVIEW -->
    <div class="review-card">
        <div class="mb-4">
            <h5 class="fw-bold mb-1"> Student Answer Review </h5> <small class="text-muted"> Complete
                question-by-question marks analysis. </small>
        </div> <?php if (empty($answers)): ?>
            <div class="alert alert-info"> No answer records found. </div> <?php else: ?>
            <?php foreach ($answers as $index => $answer): ?>
                <?php if (empty($answer['selected_option'])) {
                    $reviewClass = 'neutral-line';
                }
                elseif ((int) $answer['is_correct'] === 1) {
                    $reviewClass = 'correct-line';
                }
                else {
                    $reviewClass = 'wrong-line';
                }
                $selectedText = '';
                if ($answer['selected_option'] === 'A') {
                    $selectedText = $answer['option_a'];
                }
                elseif ($answer['selected_option'] === 'B') {
                    $selectedText = $answer['option_b'];
                }
                elseif ($answer['selected_option'] === 'C') {
                    $selectedText = $answer['option_c'];
                }
                elseif ($answer['selected_option'] === 'D') {
                    $selectedText = $answer['option_d'];
                }
                $correctText = '';
                if ($answer['correct_option'] === 'A') {
                    $correctText = $answer['option_a'];
                }
                elseif ($answer['correct_option'] === 'B') {
                    $correctText = $answer['option_b'];
                }
                elseif ($answer['correct_option'] === 'C') {
                    $correctText = $answer['option_c'];
                }
                elseif ($answer['correct_option'] === 'D') {
                    $correctText = $answer['option_d'];
                } ?>
                <div class="mb-4 pb-4 border-bottom">
                    <div class="review-question"> <span class="text-primary"> Q<?= $index + 1 ?>. </span>
                        <?= nl2br(e($answer['question_text'])) ?>
                    </div> <?php if (!empty($answer['selected_option'])): ?>
                        <div class="answer-line <?= $reviewClass ?>"> <strong> Student Answer: </strong>
                            <?= e($answer['selected_option']) ?>. <?= e($selectedText) ?>
                        </div> <?php else: ?>
                        <div class="answer-line neutral-line"> <strong> Student Answer: </strong> Not Answered </div>
                    <?php endif; ?>
                    <div class="answer-line correct-line"> <strong> Correct Answer: </strong>
                        <?= e($answer['correct_option']) ?>. <?= e($correctText) ?>
                    </div>
                    <div class="d-flex justify-content-between mt-2"> <small class="text-muted"> Question Marks:
                            <?= e($answer['marks']) ?> </small> <strong
                            class="<?= (float) $answer['marks_obtained'] > 0 ? 'text-success' : 'text-danger' ?>"> Obtained:
                            <?= e($answer['marks_obtained']) ?> </strong> </div>
                </div> <?php endforeach; ?> <?php endif; ?>
    </div>
</div> <?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
<?php

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

/*
|--------------------------------------------------------------------------
| Admin - Mark Payment as Paid
|--------------------------------------------------------------------------
| This page is used by the admin dashboard.
|
| IMPORTANT:
| After verification, the admin MUST be redirected back to:
| admin/dashboard.php
|
| The success/error message must NOT be sent to student/login.php.
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(
        base_url('assan_computer_institute/admin/dashboard.php')
    );
    exit;
}

try {

    /*
    |--------------------------------------------------------------------------
    | CSRF Protection
    |--------------------------------------------------------------------------
    */

    verify_csrf();

    /*
    |--------------------------------------------------------------------------
    | Get Enrollment ID
    |--------------------------------------------------------------------------
    */

    $enrollmentId = isset($_POST['enrollment_id'])
        ? (int) $_POST['enrollment_id']
        : 0;

    if ($enrollmentId <= 0) {

        flash(
            'error',
            'Invalid enrollment selected.'
        );

        redirect(
            base_url('assan_computer_institute/admin/dashboard.php')
        );

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Find Enrollment
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            user_id,
            student_name,
            email,
            course_id,
            course_name,
            amount,
            payment_method,
            payment_status,
            access_status,
            order_ref
        FROM enrollments
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute(array($enrollmentId));

    $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$enrollment) {

        flash(
            'error',
            'Enrollment record was not found.'
        );

        redirect(
            base_url('assan_computer_institute/admin/dashboard.php')
        );

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Check Current Status
    |--------------------------------------------------------------------------
    */

    if (
        $enrollment['payment_status'] === 'paid' &&
        $enrollment['access_status'] === 'active'
    ) {

        flash(
            'success',
            'This payment has already been verified and the student already has active course access.'
        );

        redirect(
            base_url('assan_computer_institute/admin/dashboard.php')
        );

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Mark Payment as Paid + Activate Course
    |--------------------------------------------------------------------------
    */

    $update = $pdo->prepare("
        UPDATE enrollments
        SET
            payment_status = 'paid',
            access_status = 'active',
            paid_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
        LIMIT 1
    ");

    $update->execute(array($enrollmentId));

    /*
    |--------------------------------------------------------------------------
    | Check Update
    |--------------------------------------------------------------------------
    */

    if ($update->rowCount() < 1) {

        /*
        | The row may already have the requested values.
        | Check it once more before reporting an error.
        */

        $check = $pdo->prepare("
            SELECT
                payment_status,
                access_status
            FROM enrollments
            WHERE id = ?
            LIMIT 1
        ");

        $check->execute(array($enrollmentId));

        $current = $check->fetch(PDO::FETCH_ASSOC);

        if (
            !$current ||
            $current['payment_status'] !== 'paid' ||
            $current['access_status'] !== 'active'
        ) {

            flash(
                'error',
                'Payment verification failed. The enrollment was not updated.'
            );

            redirect(
                base_url('assan_computer_institute/admin/dashboard.php')
            );

            exit;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Optional Audit Log
    |--------------------------------------------------------------------------
    */

    try {

        /*
        | Get currently logged-in admin.
        */

        $admin = current_user();

        if ($admin && isset($admin['id'])) {

            /*
            | Only insert if audit_logs table exists with the expected
            | basic structure. Errors here should not stop verification.
            */

            $audit = $pdo->prepare("
                INSERT INTO audit_logs
                (
                    user_id,
                    action,
                    details,
                    created_at
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    NOW()
                )
            ");

            $audit->execute(array(
                (int) $admin['id'],
                'payment_verified',
                'Payment verified for enrollment #' .
                $enrollmentId .
                ' - Course: ' .
                $enrollment['course_name'] .
                ' - Student: ' .
                $enrollment['student_name']
            ));
        }

    } catch (Exception $auditException) {

        /*
        | Audit logging must not break successful payment verification.
        */
    }

    /*
    |--------------------------------------------------------------------------
    | SUCCESS MESSAGE
    |--------------------------------------------------------------------------
    |
    | This message stays in the admin session and is consumed by
    | admin/dashboard.php.
    |
    | DO NOT redirect to student/login.php.
    |--------------------------------------------------------------------------
    */

    flash(
        'success',
        'Payment verified successfully. ' .
        $enrollment['student_name'] .
        ' now has active access to "' .
        $enrollment['course_name'] .
        '".'
    );

    /*
    |--------------------------------------------------------------------------
    | REDIRECT BACK TO ADMIN DASHBOARD
    |--------------------------------------------------------------------------
    */

    redirect(
        base_url('assan_computer_institute/admin/dashboard.php')
    );

    exit;

} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | Error Handling
    |--------------------------------------------------------------------------
    */

    flash(
        'error',
        'Payment verification failed. Please try again.'
    );

    redirect(
        base_url('assan_computer_institute/admin/dashboard.php')
    );

    exit;
}
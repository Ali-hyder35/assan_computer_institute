<?php

/*
|--------------------------------------------------------------------------
| Assan Computer Institute
| Admin - Create Exam
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_admin();

$pageTitle = 'Create Exam';

$errors = array();

$title = '';
$description = '';
$courseId = 0;
$durationMinutes = 30;
$totalMarks = 0;
$passMarks = 0;
$attemptsAllowed = 1;
$active = 1;

/*
|--------------------------------------------------------------------------
| Courses
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        id,
        title,
        active
    FROM courses
    ORDER BY title ASC
");

$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Create Exam
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        verify_csrf();

        $title =
            isset($_POST['title'])
                ? trim($_POST['title'])
                : '';

        $description =
            isset($_POST['description'])
                ? trim($_POST['description'])
                : '';

        $courseId =
            isset($_POST['course_id'])
                ? (int) $_POST['course_id']
                : 0;

        $durationMinutes =
            isset($_POST['duration_minutes'])
                ? (int) $_POST['duration_minutes']
                : 30;

        $totalMarks =
            isset($_POST['total_marks'])
                ? (float) $_POST['total_marks']
                : 0;

        $passMarks =
            isset($_POST['pass_marks'])
                ? (float) $_POST['pass_marks']
                : 0;

        $attemptsAllowed =
            isset($_POST['attempts_allowed'])
                ? (int) $_POST['attempts_allowed']
                : 1;

        $active =
            isset($_POST['active'])
                ? 1
                : 0;

        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {
            $errors[] = 'Exam title is required.';
        }

        if ($courseId <= 0) {
            $errors[] = 'Please select a course.';
        }

        if ($durationMinutes <= 0) {
            $errors[] = 'Duration must be greater than zero.';
        }

        if ($totalMarks < 0) {
            $errors[] = 'Total marks cannot be negative.';
        }

        if ($passMarks < 0) {
            $errors[] = 'Pass marks cannot be negative.';
        }

        if (
            $totalMarks > 0 &&
            $passMarks > $totalMarks
        ) {
            $errors[] =
                'Pass marks cannot be greater than total marks.';
        }

        if ($attemptsAllowed < 0) {
            $errors[] =
                'Attempts allowed cannot be negative.';
        }

        /*
        |--------------------------------------------------------------------------
        | Verify Course
        |--------------------------------------------------------------------------
        */

        if (empty($errors)) {

            $stmt = $pdo->prepare("
                SELECT id
                FROM courses
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute(array($courseId));

            if (!$stmt->fetchColumn()) {
                $errors[] = 'Selected course does not exist.';
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Insert
        |--------------------------------------------------------------------------
        */

        if (empty($errors)) {

            $stmt = $pdo->prepare("
                INSERT INTO exams
                (
                    course_id,
                    title,
                    description,
                    duration_minutes,
                    total_marks,
                    pass_marks,
                    attempts_allowed,
                    active
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?
                )
            ");

            $stmt->execute(array(
                $courseId,
                $title,
                $description !== '' ? $description : null,
                $durationMinutes,
                $totalMarks,
                $passMarks,
                $attemptsAllowed,
                $active
            ));

            $newExamId =
                (int) $pdo->lastInsertId();

            flash(
                'success',
                'Exam created successfully. Now add exam questions.'
            );

            redirect(
                base_url(
                    'assan_computer_institute/admin/exam_questions.php?id=' .
                    $newExamId
                )
            );
        }

    } catch (Exception $e) {

        $errors[] =
            $e->getMessage();
    }
}

require_once dirname(__DIR__) . '/partials/header.php';
?>

<style>
body {
    background: #f5f7fb;
}

.exam-form-page {
    padding: 30px 0 60px;
}

.form-header {
    background: linear-gradient(
        135deg,
        #0f2a5f,
        #1e4b8f
    );
    color: #fff;
    border-radius: 18px;
    padding: 28px;
    margin-bottom: 25px;
}

.form-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 28px;
    box-shadow: 0 8px 25px rgba(15,42,95,.08);
}

.form-label {
    color: #334155;
    font-weight: 600;
}

.form-control,
.form-select {
    border-color: #dbe3ef;
    border-radius: 10px;
    padding: 11px 13px;
}

.form-control:focus,
.form-select:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 .2rem rgba(37,99,235,.12);
}

.btn-save {
    background: #2563eb;
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 12px 22px;
    font-weight: 700;
}

.btn-save:hover {
    background: #1d4ed8;
    color: #fff;
}

.help-text {
    color: #64748b;
    font-size: 12px;
}
</style>

<div class="container exam-form-page">

    <div class="form-header">

        <h2 class="mb-1">
            <i class="bi bi-plus-circle me-2"></i>
            Create Exam
        </h2>

        <p class="mb-0 text-white-50">
            Create a new examination for one of your courses.
        </p>

    </div>

    <?php if (!empty($errors)): ?>

        <div class="alert alert-danger">

            <strong>
                Please correct the following:
            </strong>

            <ul class="mb-0 mt-2">

                <?php foreach ($errors as $error): ?>

                    <li><?= e($error) ?></li>

                <?php endforeach; ?>

            </ul>

        </div>

    <?php endif; ?>

    <div class="form-card">

        <form method="post">

            <?= csrf_field() ?>

            <div class="row g-4">

                <div class="col-md-8">

                    <label class="form-label">
                        Exam Title
                    </label>

                    <input
                        type="text"
                        name="title"
                        class="form-control"
                        value="<?= e($title) ?>"
                        placeholder="e.g. HTML Fundamentals Final Exam"
                        required
                    >

                </div>

                <div class="col-md-4">

                    <label class="form-label">
                        Course
                    </label>

                    <select
                        name="course_id"
                        class="form-select"
                        required
                    >

                        <option value="">
                            Select Course
                        </option>

                        <?php foreach ($courses as $course): ?>

                            <option
                                value="<?= (int) $course['id'] ?>"
                                <?= $courseId === (int) $course['id']
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= e($course['title']) ?>
                                <?= (int) $course['active'] !== 1
                                    ? ' (Inactive)'
                                    : '' ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="col-12">

                    <label class="form-label">
                        Description
                    </label>

                    <textarea
                        name="description"
                        class="form-control"
                        rows="4"
                        placeholder="Enter exam instructions or description..."
                    ><?= e($description) ?></textarea>

                </div>

                <div class="col-md-3">

                    <label class="form-label">
                        Duration
                    </label>

                    <div class="input-group">

                        <input
                            type="number"
                            name="duration_minutes"
                            class="form-control"
                            min="1"
                            value="<?= (int) $durationMinutes ?>"
                            required
                        >

                        <span class="input-group-text">
                            Minutes
                        </span>

                    </div>

                </div>

                <div class="col-md-3">

                    <label class="form-label">
                        Total Marks
                    </label>

                    <input
                        type="number"
                        name="total_marks"
                        class="form-control"
                        min="0"
                        step="0.01"
                        value="<?= e($totalMarks) ?>"
                    >

                    <div class="help-text mt-1">
                        Can be updated based on questions.
                    </div>

                </div>

                <div class="col-md-3">

                    <label class="form-label">
                        Pass Marks
                    </label>

                    <input
                        type="number"
                        name="pass_marks"
                        class="form-control"
                        min="0"
                        step="0.01"
                        value="<?= e($passMarks) ?>"
                    >

                </div>

                <div class="col-md-3">

                    <label class="form-label">
                        Attempts Allowed
                    </label>

                    <input
                        type="number"
                        name="attempts_allowed"
                        class="form-control"
                        min="0"
                        value="<?= (int) $attemptsAllowed ?>"
                    >

                    <div class="help-text mt-1">
                        0 = unlimited attempts.
                    </div>

                </div>

                <div class="col-12">

                    <div class="form-check">

                        <input
                            class="form-check-input"
                            type="checkbox"
                            name="active"
                            id="active"
                            <?= $active ? 'checked' : '' ?>
                        >

                        <label
                            class="form-check-label"
                            for="active"
                        >
                            Publish exam immediately
                        </label>

                    </div>

                </div>

            </div>

            <hr class="my-4">

            <div class="d-flex justify-content-between">

                <a
                    href="<?= e(base_url('assan_computer_institute/admin/exams.php')) ?>"
                    class="btn btn-outline-secondary"
                >
                    Cancel
                </a>

                <button
                    type="submit"
                    class="btn-save"
                >
                    <i class="bi bi-check-circle me-1"></i>
                    Create Exam
                </button>

            </div>

        </form>

    </div>

</div>

<?php require_once dirname(__DIR__) . '/partials/footer.php'; ?>
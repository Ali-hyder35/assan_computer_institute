# Assan Computer Institute - Professional PHP/MySQL Website

## Requirements
- XAMPP with PHP 7.4+ (PHP 8.1+ recommended)
- MySQL / MariaDB
- Composer is optional for the core website; required for PHPMailer email sending.

## Installation
1. Extract this folder into `C:\xampp\htdocs\assan_computer_institute`
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database/schema.sql`.
4. Copy `.env.example` to `.env`.
5. Keep `APP_URL=http://localhost/assan_computer_institute`.
6. Optional: run `composer install` from the project folder for PHPMailer.
7. Open `http://localhost/assan_computer_institute/`
8. Open `http://localhost/assan_computer_institute/setup_admin.php` once to create the first admin, then delete that file.

## Main URLs
- Home: `/`
- Courses: `/#courses`
- Register: `/student/register.php`
- Login: `/student/login.php`
- Student dashboard: `/student/dashboard.php`
- Admin login: `/admin/login.php`
- Admin dashboard: `/admin/dashboard.php`

## Payment
JazzCash/Easypaisa adapters are included as secure integration scaffolds. Enter the exact merchant credentials and current provider API/form fields supplied by your merchant account before enabling live payments. Bank transfer can be marked paid from the admin panel.

## Important
Do not publish `.env`, `setup_admin.php`, or merchant credentials to a public repository.

<?php
require_once __DIR__.'/config/bootstrap.php';
$exists=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$error='';
if($_SERVER['REQUEST_METHOD']==='POST' && !$exists){
 verify_csrf(); $name=trim(isset($_POST['name'])?$_POST['name']:''); $email=trim(isset($_POST['email'])?$_POST['email']:''); $pass=isset($_POST['password'])?$_POST['password']:'';
 if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<8){$error='Use a valid name/email and password of at least 8 characters.';}
 else {try{$s=$pdo->prepare("INSERT INTO users(full_name,email,mobile,password_hash,role) VALUES(?,?,?,?, 'admin')");$s->execute(array($name,$email,'',password_hash($pass,PASSWORD_DEFAULT)));$exists=1;}catch(Exception $e){$error='Unable to create admin.';}}
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup Admin</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="<?=e(base_url('assets/css/style.css'))?>" rel="stylesheet"></head><body><div class="auth-wrap"><div class="container"><div class="auth-card"><?php if($exists): ?><div class="alert alert-success"><h5>Admin already exists</h5><p class="mb-0">Delete <code>setup_admin.php</code> and use the admin login.</p></div><a class="btn btn-primary w-100" href="<?=e(base_url('admin/login.php'))?>">Go to Admin Login</a><?php else: ?><h2 class="section-title mb-3">Create First Administrator</h2><?php if($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?><form method="post"><?=csrf_field()?><div class="mb-3"><label class="form-label">Name</label><input class="form-control" name="name" required></div><div class="mb-3"><label class="form-label">Email</label><input class="form-control" name="email" type="email" required></div><div class="mb-4"><label class="form-label">Password</label><input class="form-control" name="password" type="password" minlength="8" required></div><button class="btn btn-primary w-100">Create Admin</button></form><?php endif; ?></div></div></div></body></html>
